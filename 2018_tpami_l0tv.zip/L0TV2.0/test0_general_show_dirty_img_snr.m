clc;clear all;close all;
randn('seed',0);rand('seed',0);
addpath('cimg','dimg','util','solvers')

lambdas =  [1 2];
[noiselevels,images,noisetypes,restorationtypes] = load_parameters;
delete(sprintf('%s.txt',mfilename))

result = {};
i_result= 1;

for mmm = 1:length(restorationtypes),
    for kkk = 1:length(images),
        for lll = 1:length(noisetypes),
            noisetype =noisetypes{lll};
            dlmwrite(sprintf('%s.txt',mfilename),datestr(now),'-append','delimiter','%s\t');
            mystr = sprintf('restorationtype:%s, noisetype:%s, image:%s',restorationtypes{mmm},noisetypes{lll},images{kkk});
            dlmwrite(sprintf('%s.txt',mfilename),mystr,'-append','delimiter','%s\t');
            psnrs = zeros(length(lambdas),length(noiselevels));
            psnrs1 = zeros(length(lambdas),length(noiselevels));
            psnrs2 = zeros(length(lambdas),length(noiselevels));
            times1 = zeros(length(lambdas),length(noiselevels));
            for jjj = 1:length(noiselevels),
                for iii = 1:length(lambdas),
                    lambda = lambdas(iii);
                    noiselevel = noiselevels(jjj);
                    B_Clean = double(imread(sprintf('%s.png',images{kkk})));
                    
                    corrupted_image_name = sprintf('%s_%s_%s_%d.png',restorationtypes{mmm},images{kkk},noisetype,noiselevel);
                    B_Corrupted =  double(imread(corrupted_image_name));
                    snr_l0(B_Corrupted, B_Clean)
                    
                    % Generate the mask matrix O
                    O = ones(size(B_Clean));
                    
                    if(strcmp(noisetype,'Salt-and-Pepper'))
                        O(B_Corrupted==255)=0;
                        O(B_Corrupted==0)=0;
                    end
                    
                    B_Clean = B_Clean/255;
                    B_Corrupted = B_Corrupted/255;
                    
                    p = 2;
                    P = GenBlurOper;
                    LargestEig = min(sqrt(sum(abs(P(:))>0)*sum(P(:).*P(:))), sum(abs(P(:))));% Largest Eigenvalue of A'A
                    
                    Amap = @(X)functionAX(P,X,restorationtypes{mmm});
                    Atmap = @(X)functionAX(P',X,restorationtypes{mmm});
                    
                    acc = 1/255;
                    
                    v0=snr_l0(B_Corrupted, B_Clean);
                    v1=snr_l1(B_Corrupted, B_Clean);
                    v2=snr_l2(B_Corrupted, B_Clean);
                    
                    fprintf('%s %d     %.2f/%.2f/%.2f\n',images{kkk},noiselevel, v0,v1,v2);
                    
                    
                    tic;
%                     [U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,B_Clean);
                    psnrs(iii,jjj)  = v0;
                    psnrs1(iii,jjj) = v1;
                    psnrs2(iii,jjj) = v2;
                    time111 = toc;
                    time111
                    times1(iii,jjj) = time111;
                    psnrs
                    psnrs1
                    psnrs2
                    %                     figure;
                    %                     subplot(1,3,1); imshow(B_Clean,[]);title('Original','fontsize',13);
                    %                     subplot(1,3,2); imshow(B_Corrupted,[]); title('Corrupted','fontsize',13);
                    %                     subplot(1,3,3); imshow(U,[]); title('Recovered','fontsize',13);
                end
            end
            
            Res = [];
            Res.psnr_l0 = psnrs;
            Res.psnr_l1 = psnrs1;
            Res.psnr_l2 = psnrs2;
            Res.times1 = times1;
            Res.noiselevels = noiselevels;
            Res.lambdas = lambdas;
            Res.noisetype = noisetypes{lll};
            Res.image = images{kkk};
            Res.restorationtype = restorationtypes{mmm};
            result{i_result} = Res;
            i_result=i_result+1;
            
            dlmwrite(sprintf('%s.txt',mfilename),psnrs,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs),'-append');
            
            dlmwrite(sprintf('%s.txt',mfilename),psnrs1,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs1),'-append');
   
            dlmwrite(sprintf('%s.txt',mfilename),psnrs2,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs2),'-append');
            
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            save(mfilename,'result');
        end
    end
end


save(mfilename,'result');




















