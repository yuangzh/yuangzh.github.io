function [xs] = GenerateAllStationaryPoint(A,b,k)
% Solve the following optimization problem:
% min_x ||Ax-b||_1, s.t. ||x||_0 = k
[m,n]=size(A);
P = combs([1:n],k);

for iter=1:size(P,1)
%    fprintf('%d %d\n',iter,size(P,1));
   p = P(iter,:);
   p1 = setdiff([1:n],p);
   cvx_begin quiet
   variable x(n)
   minimize( norm(A*x-b,1) )
   subject to
   x(p1) == 0
   cvx_end
   x_cur = x;
   xs{iter} = x_cur(:);
end

