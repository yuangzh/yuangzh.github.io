function test_nonconvex_prox_l1l2
clc;clear all;close all;
% 0.5 t^2 - beta t + lambda |x(i)+t| - lambda || x+tei ||_2

for iter = 1:100000000
    iter
    rand('seed',iter);
    randn('seed',iter);
    m = 10;
    beta = randn(1)*100*rand(1);
    x = randn(m,1)*100*rand(1);
    lambda = rand(1)*100*rand(1);
    i = randperm(m,1);
    
    
    
    HandleObj = @(t)ComputeObj(t,beta,lambda,x,i);
    x1 = fminsearch(HandleObj,0);
    x2 = nonconvex_prox_l1l2(beta,lambda,x,i);
    f1 = HandleObj(x1);
    f2 = HandleObj(x2);
    fprintf('iter:%f, fobj:%.5e %.5e\n',iter,f1,f2);
    
    if(f2>f1 + 1e-6*abs(mean([f1;f2])))
        f1
        f2
        x1
        x2
        dddd
    end
    
    
end

function [f] = ComputeObj(t,beta,lambda,x,i)
ei = 0*x;
ei(i) = 1;
f = 0.5*t^2 - beta*t + lambda*abs(x(i)+t) - lambda*norm(x+t*ei);













