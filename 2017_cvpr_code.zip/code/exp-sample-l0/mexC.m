clc;clear all;close all;
cd solver
mex l0_triangle_subproblem.c;
cd ..
