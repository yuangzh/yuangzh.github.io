% Implemented by Ganzhao Yuan
% South China Univ. of Technology
% email: yuanganzhao@gmail.com
% Ref:
% Zhifeng Hao, Ganzhao Yuan��Zhenjie Zhang, Bernard Ghanem. 
% BILGO: Bilateral Greedy Optimization for Large Scale Semidefinite Programming
% Submitted to Machine Learning Jounal

clc;clear all;close all;
randn('state',0); rand('state',0);
addpath('classify','mylib');

dat=[];
load optdigits;
ratio = 0.7;
[dat.x,dat.y,dat.tx,dat.ty]=CreateDataAppTest(x,y,ratio*length(y), unique(y));
dat.lambda=0.1;
dat.plot=1;
[L,ts]=kta(dat);
fprintf('result: test err rate:%f, time: %f, final rank:%d\n',...
    testAcc(L,dat.x,dat.y,dat.tx,dat.ty),ts,size(L,2));


% fprintf('please press any key to continue..\n');
% pause

 
dat=[];dat.lambda=0.1;dat.plot=1; 
load w1a_test; dat.x =x;  dat.y =y; clear x y;
load w1a_train ; dat.tx =x;  dat.ty =y; clear x y;
[L,ts]=kta(dat);
 fprintf('result: test err rate:%f, time: %f, final rank:%d\n',...
    testAcc(L,dat.x,dat.y,dat.tx,dat.ty),ts,size(L,2));


