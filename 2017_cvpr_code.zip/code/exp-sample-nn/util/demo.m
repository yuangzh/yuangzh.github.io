clc;clear all;close all;
m = 10;
n =15;
A = randn(m,n);
b = randn(m,1);
K = 4;
x = cosamp(A,b,K,0,1000);
err0 = norm(A*x-b);

% lp_re(A,b,0.1)
nnz(x)
lambda = 1;
for iter = 1:100,
[x] = MSM(A'*A,-A'*b,lambda,randn(n,1),1000);
err = norm(A*x-b);
if(err>err0)
    lambda = lambda *2;
else
    lambda = lambda /2;
end
fprintf('iter:%d, err:%f (%f), lambda:%f\n',iter,err,err0,lambda);

end
% norm(A*x-b,'fro') 
% nnz(x)