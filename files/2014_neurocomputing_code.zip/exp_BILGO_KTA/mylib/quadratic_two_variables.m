function [optimal_solution]=quadratic_two_variables (Q,p,u)
% Solve the following two variables box-constrained
% quadratic programming problem
% min 0.5 x'Qx + p'x
% s.t. 0 <= x <= u, x \in R^{2 x 1}
% Implemented by Ganzhao Yuan
% South China Univ. of Technology
% email: yuanganzhao@gmail.com
% Ref:
% Zhifeng Hao, Ganzhao Yuan��Zhenjie Zhang, Bernard Ghanem. 
% BILGO: Bilateral Greedy Optimization for Large Scale Semidefinite Programming
% Submitted to Machine Learning Jounal

X = zeros(2,9);
HandleObj=@(x)ObjFun (x,Q,p);
X(:,1) = [0;0];
X(:,2) = [0;u(2)];
X(:,3) = [0;min(max(0,-p(2)/Q(2,2)),u(2))];
X(:,4) = [u(1);0];
X(:,5) = [u(1);u(2)];
X(:,6) = [u(1);min(u(2),max(0,(-p(2)-Q(2,1)*u(1))/Q(2,2)))];
X(:,7) = [max(0,-p(1)/Q(1,1));0];
X(:,8) = [max(0,(-p(1)-u(2)*Q(1,2))/Q(1,1));u(2)];
X(:,9) = ([Q(2,2) -Q(1,2);-Q(2,1) Q(1,1)]/(Q(1,1)*Q(2,2) - Q(1,2)*Q(2,1))) * (-p);

optimal_solution=zeros(2,1);
FinalObj=0;
for i=1:9,
    x_cur=set2fea(X(:,i),u);
    if(IsField2(x_cur)==1)
        obj_cur=HandleObj(x_cur);
        if(obj_cur<FinalObj),
            FinalObj=obj_cur;
            optimal_solution=x_cur;
        end
    end
end

function [fobj,grad]=ObjFun(x,Q,p)
fobj = 0.5*x'*Q*x + p'*x;grad = Q*x + p;

function [x]=set2fea(x,u)
x(x<0)=0;x(1)=min(x(1),u(1));x(2)=min(x(2),u(2));

function [flag]=IsField2(x)
flag=0;if(IsField(x(1))==1 && IsField(x(2))==1)flag=1;end
function [flag]=IsField(x)
flag=0;if(isinf(x)==0 && isnan(x)==0 && isinf(x)==0 )flag=1;end;
