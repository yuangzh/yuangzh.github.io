function [obj_out,Wss_out,Hss_out] = OneRunN(X,r,timelimit,runs)
[m,n]=size(X);
objs = [];
for it = 1:runs,
    randn('seed',it); rand('seed',it);
    Winit = rand(m,r); Hinit = rand(r,n);
    fprintf('round %d begin\n',it);
    [Ws,Hs,obj_onerun] = OneRun(X,Winit,Hinit,timelimit);
    fprintf('round %d end\n\n',it);
    Wss_out{it} = Ws;
    Hss_out{it} = Hs;
    objs(:,it) = obj_onerun;
end

% Losses 6 x runs
e = ones(runs,1);
objs = objs * e; obj_out = objs/runs;

