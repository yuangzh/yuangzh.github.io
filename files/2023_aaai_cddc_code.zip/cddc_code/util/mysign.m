function [r] = mysign(x)
r = sign(x);
I = find(x==0);
r(I) = sign(randn(length(I),1));