function [fobj] = computeObj(X,A,B)
% 0.5 ||X-AB||_F^2, A>=0, B>=0
% X: m x n
% A: m x r
% B: r x n
A = max(A,0); B = max(B,0);
XBt = X*B'; AtA = A'*A; BBt = B*B'; %AtX = A'*X;
fobj = 0.5 * norm(X,'fro')^2 - mdot(A,XBt) + 0.5 * mdot(AtA,BBt);
% fobj = 0.5 * norm(X-A*B,'fro')^2;

function [r] = mdot(A,B)
r = sum(sum(A.*B));


