function [A,b,w] = GetAbw(C,f)

[m,n]=size(C);
I = eye(m);
w = [zeros(n,1);ones(m,1)];
A = [C -I;
    -C -I];
b = [f;-f];