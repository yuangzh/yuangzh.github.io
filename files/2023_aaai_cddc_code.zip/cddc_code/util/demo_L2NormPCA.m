function demo_L2NormPCA
% min_x 0.5 x'x - ||Ax||_2 
clc;clear all;close all;
addpath('util');
rand('seed',10);
randn('seed',10);

m = 12;
n = 15;
A = randn(m,n); 

HandleObj = @(x)0.5*x'*x - norm(A*x);

[x1] = cd(A);
[x2] = gradientdescent(A,1);
[x3] = ComputeExactSolution(A);

HandleObj(x1)
HandleObj(x2)
HandleObj(x3)

function [x] = ComputeExactSolution(A)
[V,D]=eig(A'*A);
x = V(:,end)*sqrt(D(end,end));



function [x] = cd(A)
% min_x 0.5 lambda x'x - ||Ax||_2 
[m,n] = size(A);
x = randn(n,1);
lambda = 1;
C= A'*A;
[m,n] = size(A);
his2 = [];
HandleObj = @(x)ComputeObj(x,A,lambda);
for iter = 1:100000
    [fobj,grad,hess] = HandleObj(x);

    
    his(iter) = fobj;
    H = sqrt(x'*C*x)*eye(n) - C + x*x';
    his2(iter) = min(eig(H));
%   if(~mod()
    [~,i] = max(abs(grad)); % iter:19596, fobj:-815363.631894, normG:9.906459e-06
%   i = randperm(n,1);

%   hhh = A'*A*x - sqrt(x'*A'*A*x)*x;
%   [~,i]= max(abs(hhh)); iter:11018, fobj:-922.021273, normG:9.945163e-06

    ei = zeros(n,1);
    ei(i) = 1;
    % min_t  f(x+tei)
    % min_t  0.5 lambda ||x+tei||_2^2 - ||A(x+tei)||_2 
    % min_t  0.5 lambda t*t + lambda x(i) - ||A(x+tei)||_2 
    % min_t  0.5 t*t + x(i) - 1 / lambda ||A(x+tei)||_2 
    cof_a = A*ei;
    cof_b = A*x;
    [t] = nonconvex_prox_l2(-x(i),1/lambda,cof_a,cof_b);
    x(i) = x(i) + t;
    fprintf('iter:%d, fobj:%f, normG:%e, hess:%f %f\n',iter,fobj,norm(grad),min(abs(eig(hess))),max(abs(eig(hess))));
    if(norm(grad)<1e-5)
        break;
    end
end







function [x] = gradientdescent(A,lambda)
% min_x 0.5 lambda x'x - ||Ax||_2 
[m,n] = size(A);
HandleObj = @(x)ComputeObj(x,A,lambda);
x = randn(n,1);
for iter = 1:100000
    [fobj,grad,hess]=HandleObj(x);
    x = x - grad/norm(hess);
    fprintf('iter:%d, fobj:%f, normG:%f\n',iter,fobj,norm(grad));
    if(norm(grad)<1e-5)
        break;
 end
end
 

 

function [fobj,grad,hess] = ComputeObj(x,A,lambda)
% min_x -||Ax||_2 + 0.5 lambda x'x
Ax = A*x;
fobj = -norm(Ax) + 0.5*lambda*x'*x;
grad = -A'*Ax/norm(Ax) + lambda*x;
n = length(x);
hhh = (A'*A*norm(Ax) - A'*Ax*(A'*Ax)' / norm(Ax)) / (norm(Ax)^2);
hess = -hhh + lambda*eye(n);





