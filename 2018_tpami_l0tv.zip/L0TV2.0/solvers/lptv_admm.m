function [U] = lptv_admm(B,O,Amap,Atmap,p,lambda,LargestEig,acc,B_Clean)

% min_{u}  lambda || Dxu Dyu ||_{p,1} + ||o.*(Ku-b)||_0
% min_{u}  lambda || r s ||_{p,1} + ||o.*z||_0,
% s.t. Dxu = r, Dyu = s, Ku - b = z

% L = lambda || r s ||_{p,1} + ||o.*z||_0 + <piz,Ku-b-z> + 0.5 alpha|Ku-b-z|_2^2
%                                      + <pir,Dxu-r>  + 0.5 beta |Dxu-r|_2^2
%                                      + <pis,Dyu-s>  + 0.5 beta |Dyu-s|_2^2

% When pen = 0, it is an Augmented Lagrangian method 
% When pen = 1, it is an penalty decomposition method


% Primal Variables
U = B;
dx = difX(U);
dy = difY(U);
Z = 1*randn(size(B));
R = dx;
S = dy;

% Multipliers
piz = 0.1*randn(size(B));
pir = 0.1*randn(size(B));
pis = 0.1*randn(size(B));

gamma = 0.5*(1+sqrt(5)); %  golden ratio



alpha = 10;
beta  = 10;
ratio = 5;
his = [];
for iter = 1:300,

    % Update RS
    % min_{R,S} lambda sum(sum((R.^p + S.^p).^(1/p))) + mdot(pir, -R) + 0.5*beta*fnorm(dx-R)^2 + mdot(pis, -S) + 0.5*beta*fnorm(dy-S)^2;
    R1 = - pir/beta -dx;    S1 = - pis/beta - dy;
    [R,S] = threadholding_RS(R1,S1,lambda,beta,p);
    
    % Update U
    g1 = Atmap(piz) + alpha*Atmap(Amap(U)-B-Z);
    g2 = divX(-pir+beta*R)  - beta*divX(dx);
    g3 = divY(-pis+beta*S) - beta*divY(dy);
    gradU =     g1 + g2 + g3;
    Lip = beta*4 + beta*4 + alpha*LargestEig;
    U   = boxproj(U - gradU/Lip);
    dx  = difX(U);    dy  = difY(U);
    
    % Update Z:
    D = Amap(U)-B;
    % min_{Z} ||o.*z||_0 + mdot(piz, Amap(U)-B-Z) + 0.5 * alpha*fnorm(D-Z)^2
    % min_{Z} ||o.*z||_0 + mdot(piz, -Z) + 0.5 * alpha*fnorm(D-Z)^2
    % min_{Z} ||o.*z||_0 + 0.5 * alpha*fnorm(Z-(D+piz/alpha))^2
    % min_{Z} 1/alpha||o.*z||_p^p + 0.5 * fnorm(Z-(D+piz/alpha))^2
    
    Z = prox_lp_vec(vec(D+piz/alpha),O(:),alpha);
    Z = reshape(Z,size(B));
 
    
    
    %     Lag = sum(sum((R.^p + S.^p).^(1/p))) + mdot(piz, Amap(U)-B-Z) + 0.5 * alpha*fnorm(Amap(U)-B-Z)^2 ...
    %         + mdot(pir, dx-R) + 0.5*beta*fnorm(dx-R)^2 + mdot(pis, dy-S) + 0.5*beta*fnorm(dy-S)^2;
    %     his = [his;Lag];
    
    
    
    r1 = fnorm(Amap(U) - B-Z);
    r2 = fnorm(dx-R)+ fnorm(dy-S);
    if(iter>10 && r1<acc && r2<acc),break;end
    
    PSNR   =  snr_l1(U, B_Clean);
    if(~mod(iter,30)),
       fprintf('iter:%d, nearness: (%.1e %.1e), penalty:(%f %f), psnr: %f\n',iter,r1,r2,alpha,beta,PSNR);
   end
    
    
    % Update Multipliers

    piz = piz + gamma*alpha*(Amap(U) - B-Z);
    pir = pir + gamma*beta*(dx-R);
    pis = pis + gamma*beta*(dy-S);

    
    if(~mod(iter,30)),
            alpha = alpha * ratio;
            beta = beta * ratio;
    end   
    
end



function x = prox_lp_vec(a,o,alpha)
% min_x 1/alpha||o.*x||_p^p + 0.5 * fnorm(x-a)^2
% min_x 2/alpha||o.*x||_p^p + fnorm(x-a)^2
% We assume that p = 0.5 and o \in {0,1}

ind = find(o==1);
ind2 = find(o==0);
x_ind = prox_lp_closed_form(a(ind),2/alpha);
x(ind) = x_ind;
x(ind2) = a(ind2);


function x = prox_lp_closed_form(a,lambda)
% min_x sum_i^n   lambda*|x(i)|^0.5 + |x(i)-a(i)|^2;
ths = (54^(1/3))/4 * (lambda)^(2/3);
fi =  acos((abs(a)/3).^(-1.5).*lambda./8);
fi = real(fi);
x = (2/3).*a.*(1+cos(2*pi/3-(2/3).*fi));
x(abs(a)<=ths)=0;

