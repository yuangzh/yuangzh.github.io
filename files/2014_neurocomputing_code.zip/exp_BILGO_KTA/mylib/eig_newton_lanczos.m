function [evector,evalue,stat] = eig_newton_lanczos(A,n,opt)
% computing the leading eigenvector
% Implemented by Ganzhao Yuan
% South China Univ. of Technology
% email: yuanganzhao@gmail.com
% A Lanczos-based Hessian-free Newton method to find leading eigenvector
% Ref:
% Zhifeng Hao, Ganzhao Yuan��Zhenjie Zhang, Bernard Ghanem. 
% BILGO: Bilateral Greedy Optimization for Large Scale Semidefinite Programming
% Submitted to Machine Learning Jounal


if(nargin<3),
    opt=[];
end
if ~isfield(opt,'MaxIter'),opt.MaxIter=1000;end
if ~isfield(opt,'LanMaxIter'),opt.LanMaxIter=20; end
if ~isfield(opt,'ObjCha'),opt.ObjCha=1e-13; end

global xx;
if(exist('xx'))
    if(length(xx)==n)
        x=xx;
    else
        x=rand(n,1);
    end
else
    x=rand(n,1);
end

 
Fobjs=[];
    
LanMaxIter=opt.LanMaxIter;
MaxIter=opt.MaxIter;
ObjCha=opt.ObjCha;


AllIter=0;
Iter=0;
tic;
last_Obj=inf;
while 1
    Iter=Iter+1;
    %%%%% Compute Gradient
    % Ax=A*x; % n x 1
    if isa(A,'function_handle')
        Ax=A(x);
    else
        Ax=A*x;
    end
    xx=x'*x; % 1
    G = xx*x - Ax;
    curr_Obj=xx*xx-2*x'*Ax;
    Fobjs=[Fobjs;curr_Obj];
    if(abs((curr_Obj-last_Obj)/last_Obj)<ObjCha),break;end
    last_Obj=curr_Obj;
    %%%%% Stopping Criterion
    if(Iter==MaxIter),
        break;
    end
    
    %%%% Lanczos CG computing the newton diretion
    [d,inner]=cgLanczos(A,-G,x,n, 1e-12,-G,LanMaxIter);
    AllIter=AllIter+inner+1;
    dd=d'*d;
    if(dd<1e-12),break;end
    
    xd=x'*d;
    %    Ad=A*d;
    if isa(A,'function_handle')
        Ad=A(d);
    else
        Ad=A*d;
    end
    
    c3 = dd*dd;
    c2 = 4*dd*xd;
    c1 = 2*xx*dd + 4* xd*xd - 2 * d'*Ad;
    c0 = 4*xx*xd - 4*x'*Ad;
    
    steps =roots([4*c3 3*c2 2*c1 c0]);
    steps_candidates=[];
    for i=1:length(steps),
        if(isreal(steps(i))),
            if(steps(i)>0),
                steps_candidates=[steps_candidates;steps(i)];
            end;
        end;
    end;
    nLen=length(steps_candidates);
    if(nLen==1),
        stepsize = steps_candidates(1);
    elseif(nLen==0)
        %          norm(G)
        %          fprintf('!\n');
        break;
    elseif(nLen>1)
        %          fprintf('* ');
        fffobj=inf;
        stepsize = 0;
        for il=1:nLen,
            x_t = x + steps_candidates(il)*d;
            xtxt=x_t'*x_t;
            %            A_xt=A*x_t;
            if isa(A,'function_handle')
                A_xt=A(x_t);
            else
                A_xt=A*x_t;
            end
            cur_obj = xtxt^2 - 2 * x_t'*A_xt;
            if(cur_obj<fffobj)
                fffobj=cur_obj;
                stepsize = steps_candidates(il);
            end
        end
    end
    x=x+stepsize*d;
end;
% stat.xAx=curr_Obj;
stat.iter=AllIter;
stat.time=toc;
nx=norm(x);
evector = x/nx;
evalue = - curr_Obj / (nx*nx);
%    plot(Fobjs);
%    pause;
xx=x;


function [ x, itn ] = cgLanczos (A, b,z,n, rtol,x,LanMaxIter )
% n      = length(b);
% show=0;
istop = 0;
itn   = 0;
D = zeros(n,1);


%------------------------------------------------------------------
% Set up the first Lanczos vector v.
%------------------------------------------------------------------
% done  = false;
beta1 = norm(b);
% if beta1==0
%   istop = 0;  done = true;  %show = true;     % b=0 exactly.  Stop with x = 0.
% else
v   = (1/beta1)*b;
% end


beta   = beta1;
Tnorm2 = 0;   Wnorm2 = 0;


%---------------------------------------------------------------------
% Main iteration loop.
% --------------------------------------------------------------------
% if ~done                        % k = itn = 1 first time through
while 1,
    itn = itn + 1;
    if(itn>LanMaxIter),break;end
    
    if isa(A,'function_handle')
        Av=A(v);
    else
        Av=A*v;
    end
    p =2*z*(z'*v)  +  (z'*z)*v - Av;
    
    if itn>1
        p = p - beta*v1;
    end
    
    alpha = v'*p;                        % alpha = v'Av in theory
    if alpha<=0, istop = 6;  break; end  % A is indefinite or singular
    p     = p - alpha*v;
    
    oldb  = beta;               % oldb = betak
    beta  = norm(p);            % beta = betak+1
    beta  = max(beta,eps);      % Prevent divide by zero
    v1    = v;
    v     = (1/beta)*p;
    
    if itn==1                   % Initialize a few things.
        delta  = sqrt(alpha);     % delta1 = sqrt(alpha1)
        gamma  = beta /delta;     % gamma2 = beta2/delta1
        zeta   = beta1/delta;     % zeta1  = beta1/delta1
        w      = v1   /delta;     % w1     = v1   /delta1
        x      = zeta*w;          % x1     = w1*zeta1  = v1*(beta1/alpha1)
        D      = w.^2;            % Initialize diagonals of Wk Wk'
        Tnorm2 = alpha^2 + beta^2;
    else                        % Normal case (itn>1)
        delta  = alpha - gamma^2;
        if delta<=0, istop = 6;  break; end  % Tk is indefinite or singular
        delta  = sqrt(delta);
        zeta   =     - gamma*zeta/delta;
        w      = (v1 - gamma*w  )/delta;
        x      = x + zeta*w;
        D      = D + w.^2;
        gamma  = beta /delta;
        Tnorm2 = Tnorm2 + alpha^2 + oldb^2 + beta^2;
    end
    
    %-----------------------------------------------------------------
    % Estimate various norms and test for convergence.
    %-----------------------------------------------------------------
    Wnorm2 = Wnorm2 + norm(w)^2;
    Anorm  = sqrt( Tnorm2 );
    %     Acond  = Anorm * sqrt(Wnorm2);
    xnorm  = norm(x);
    %     epsa   = Anorm * eps;
    rnorm  = abs(beta*zeta/delta);
    test1  = rnorm / (Anorm*xnorm);    %  ||r|| / (||A|| ||x||)
    
    % See if any of the stopping criteria are satisfied.
    
    %     if itn   >= itnlim , istop = 4; end
    %     if Acond >= 0.1/eps, istop = 3; end
    %     if test1 <= eps    , istop = 2; end
    if test1 <= rtol   , istop = 1; end
    
    if istop > 0, break; end
end % main loop
% end % if ~done early

% if(istop==2 || istop==3 || istop==4 || istop==5)
%     istop
%     error('df');
% end


% function y = LanczosxxxA (A,x,z)
%   if isa(A,'function_handle')
%    Ax=A(x);
%   else
%    Ax=A*x;
%   end
% y =2*z*(z'*x)  +  (z'*z)*x - Ax;

