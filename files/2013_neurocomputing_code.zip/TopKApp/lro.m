function [U,history]=lro(A,d,precision,method,verb)
% This program solves the following optimization:
% max_U  tr(U'AU)
% s.t. U'*U = I
% which can be formulated as the following unconstrained optimization problem:
% min_L |A-LL^T|_F^2

if(nargin<=4),verb = 0; end
if(nargin<=3),method =1;end
if(nargin<=2),precision = 1e-6;end
if(nargin<=1),d = 1;end
if(nargin<=0),error('please input a target matrix');end

iter=0;
last_F=inf;
n = size(A,1);
L=orth(randn(n,d));

history=[];
out_max_iter=100*(n*d);
in_max_iter = 20;

%    method = 1; % cg
%    method = 2; % lbfgs
%    method = 3; % newton-cg

while 1
    iter=iter+1;
    if(iter> out_max_iter),fprintf('max iter reach!\n');break;end;
    
    %%compute obj and grad
    LL=L'*L ;
    AL=A*L;
    G=4* L*LL - 4*AL;
    F=trace(LL*LL)-2*trace(L'*AL); % + norm(A,'fro')^2
    history=[history;F];
    stop=abs(F-last_F)/abs(last_F);
    if(stop<precision),
        if( verb==1),
            fprintf('obj dec too small, OK!\n');
        end;
        break;
    end;
    last_F=F;
    
    if(method==1)
        if(iter==1),
            D= - G ;
        else
            beta = trace(G'*(G-last_G))/trace(last_G'*last_G);
            beta(beta<0)=0;
            D= - G + beta *   D;
            % Restart if not a direction of sufficient descent
            % if(trace( direction'*g)>-1e-9),fprintf('*'); direction=-g;end;
        end;
        last_G = G;
    elseif(method==2)
        if(iter==1)
            D = -G;
            old_dirs = zeros(n,d,0);
            old_stps = zeros(n,d,0);
            Hdiag = 1;
        else
            [old_dirs,old_stps,Hdiag] = lbfgsUpdate(G-G_old,L-L_old,old_dirs,old_stps,Hdiag);
            D= lbfgs(-G,old_dirs,old_stps,Hdiag);
        end;
        G_old = G;
        L_old=L;
    elseif(method==3)
        % min 0.5*d'*Ad + g'*d
        D = zeros(n,d);
        R = - G;
        rho = sum(dot(R,R,1));
        rho_old = inf;
        k = 1;
        while ( k<in_max_iter),
            if(k==1)
                P = R ;
            else
                P = R + (rho/rho_old) * P;
            end
            % Ap =  Hv(V,P);
            PL = P'*L; Ap = (P*LL + L*(PL) + L*PL' - A*P)*4;
            pAp = sum(dot(Ap,P,1));
            if(pAp <= 0),
                if(k==1), D = R; end;
                break;
            end
            alpha = rho / pAp;
            D = D + alpha*P;
            R = R - alpha*Ap;
            rho_old = rho;
            rho = sum(dot(R,R,1));
            k = k+1;
        end
    end
    
    % print and stopping criterion
    nmg=norm(G,'fro');
    if( verb==1),fprintf('it=%d  f=%e, g=%e, diff:%e\n',iter,F,nmg, stop );end;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%% line search begin %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % compute the optimal step �� F( L + lambda * direction) = 0
    % make Gradient of F with respect to lambda equals to 0
    
    dd=D'*D;Ld=L'*D; dL=Ld';
    dAL=D'*AL;
    dLLd= dL+Ld;
    
    a3= trace (dd * dd);
    a2= 2 * trace (dd * dLLd);
    a1= 2 * trace (dd * LL) + trace (dLLd * dLLd) - 2 * trace (D' * A * D);
    a0= 4 * (  trace(dL*LL)  -    trace(dAL)  );
    
    % To find roots to the following cubic equation where a3, a2, a1, and a0 are real
    % min_x  {4*a3*x^3 + 3*a2*x^2 + 2*a1*x + a0}
    steps =roots([4*a3 3*a2 2*a1 1*a0]);
    
    steps_candidates=[];
    for i=1:length(steps),
        if(isreal(steps(i)) && steps(i)> 0)
            steps_candidates=[steps_candidates;steps(i)];
        end;
    end;
    
    len=length(steps_candidates);
    if(len==0)
        % no good step, OK!
        fprintf('!\n');
        break;
    elseif(len==1)
        % only one solution, the stepsize is optimal!
        t=steps_candidates(1);
    elseif(len>1)
        % multiple solutions, select the best one!
        fprintf('*'); 
        find_min = inf;
        find_ind = -1;
        for i=1:length(steps_candidates),
            L_test = L + steps_candidates(i)*D;
            LL=L_test'*L_test; AL=A*L_test;
            find_fobj = trace(LL*LL)-2*trace(L'*AL);
            if(find_fobj<find_min),
                find_min=find_fobj;
                find_ind = i;
            end
        end
        t = steps_candidates(find_ind);
    end;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%% line search end %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    L=L+t*D;
    
end;

if(verb)
    plot(history);
end

[V,D]=eig(L'*L);                         % solves a small-size eigenvalue system
D(D>0) = sqrt(1./D(D>0));                % ignores the zeros eigenvalue
U = L*V*D;                               % reconstruct the top-k eigenvector
Orthogonality = norm(L'*L-eye(d),'fro'); % L is linearly dependent, orthogonalize L by Gram Schmidt
if  (Orthogonality > 1e-13),
    U = GramSchmidt(U);
end
clear A LL AL G D last_G R Ap PL dd Ld dL dAL dLLd L_test AL L;

function [d] = lbfgs(g,s,y,Hdiag)
% BFGS Search Direction
%
% This function returns the (L-BFGS) approximate inverse Hessian,
% multiplied by the gradient
% inv(H)*grad
% If you pass in all previous directions/sizes, it will be the same as full BFGS
% If you truncate to the k most recent directions/sizes, it will be L-BFGS
%
% s - previous search directions (n by k)
% y - previous step sizes (n by k)
% g - gradient (n by 1)
% Hdiag - value of initial Hessian diagonal elements (scalar)

[n,d,k] = size(s);

for i = 1:k
    ro(i,1) = 1 / trace(y(:,:,i)'*s(:,:,i));
end

q = zeros(n,d,k+1);
r = zeros(n,d,k+1);
al =zeros(k,1);
be =zeros(k,1);

q(:,:,k+1) = g;

for i = k:-1:1
    al(i) = ro(i) * trace(s(:,:,i)'*q(:,:,i+1));
    q(:,:,i) = q(:,:,i+1) - al(i)*y(:,:,i);
end

% Multiply by Initial Hessian
r(:,:,1) = Hdiag*q(:,:,1);

for i = 1:k
    be(i) = ro(i)*trace(y(:,:,i)'*r(:,:,i));
    r(:,:,i+1) = r(:,:,i) + s(:,:,i)*(al(i)-be(i));
end
d=r(:,:,k+1);

function [old_dirs,old_stps,Hdiag] = lbfgsUpdate(y,s,old_dirs,old_stps,Hdiag)
corrections=10;
debug=0;


ys = trace(y'*s);
if ys > 1e-10,
    numCorrections = size(old_dirs,3);%���ж�����
    if numCorrections < corrections
        % Full Update
        old_dirs(:,:,numCorrections+1) = s;
        old_stps(:,:,numCorrections+1) = y;
    else
        % Limited-Memory Update
        
        for i=1:corrections-1,
            old_dirs(:,:,i)=old_dirs(:,:,i+1);
            old_stps(:,:,i)=old_stps(:,:,i+1);
            
        end;
        old_dirs(:,:,corrections)=s;
        old_stps(:,:,corrections)=y;
    end
    
    % Update scale of initial Hessian approximation
    Hdiag = ys/trace(y'*y);
else
    if(debug)
        fprintf('Skipping Update\n');
    end
    
end



function U =  GramSchmidt(U)
[k] = size(U,2);
for i = 1:k
    for j = 1:i-1
        U(:,i) = U(:,i) - projection(U(:,j), U(:,i));
    end
    U(:,i) = U(:,i) / norm(U(:,i));
end

function v = projection(u,v)
v = (dot(v,u)/dot(u,u))*u;

