function [P] = GenBlurOper
BlurRadius = 3;
[x,y] = meshgrid(-BlurRadius:BlurRadius,-BlurRadius:BlurRadius);
K = double(x.^2 + y.^2 <= BlurRadius^2);
P = K/sum(K(:));



