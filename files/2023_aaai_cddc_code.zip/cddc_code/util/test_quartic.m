function test_quartic

while 1
a = randn(1)*100;
b = randn(1)*100;
c = randn(1)*100;
d = randn(1)*100;
e = randn(1)*100;
root11 = solveQuartic(a,b,c,d,e);
root22 = roots([a,b,c,d,e]);

root1 = sort(real(root11));
root2 = sort(real(root22));

if(norm(root1 - root2)>1e-1)
    norm(root1 - root2)
    root1
    root2
    a
    b
    c
    d
    e
    root11
    root22
    ddd
end


end
function [root] = solveQuartic(a,b,c,d,e)
% buggy!!!!!!!!!
% https://en.wikipedia.org/wiki/Quartic_function
A = - b/(4*a);
delta0 = c*c - 3*b*d + 12*a*e;
delta1 = 2*c^3 - 9*b*c*d + 27*b*b*e + 27*a*d*d - 72*a*c*e;
Q = (   (   delta1 + sqrt(delta1*delta1 - 4*delta0^3)    )/2  )^(1/3);
p = (8*a*c - 3*b*b) / (8*a*a);
q = (b*b*b - 4*a*b*c + 8*a*a*d) / (8*a*a*a);
S = 0.5*sqrt(-2*p/3 + (Q+delta0/Q)/(3*a));
B = 0.5*sqrt(-4*S*S-2*p+q/S);
C = 0.5*sqrt(-4*S*S-2*p-q/S);
x1 = A - S + B; 
x2 = A - S - B;
x3 = A + S + C;
x4 = A + S - C;
root = [x1;x2;x3;x4];

'results'
if(norm(a*root.^4 + b*root.^3 + c*root.^2 + d*root.^1 + e*root.^0)>1e-3)
    a*root.^4 + b*root.^3 + c*root.^2 + d*root.^1 + e*root.^0
    dddd
end
