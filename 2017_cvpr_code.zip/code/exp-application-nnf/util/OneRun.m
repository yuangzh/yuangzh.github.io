function [Ws,Hs,fobjs] = OneRun(X,Winit,Hinit,timelimit)
r = size(Winit,2);

initt = clock;
[W1,H1]=nmf_msm(X,Winit,Hinit,timelimit,100000,1);
fprintf('method 1, time spent:%d (s)\n',round(etime(clock,initt)));

initt = clock;
[W2 H2] = NMF_GCD(X,r,1e10,Winit,Hinit,0,timelimit);
fprintf('method 2, time spent:%d (s)\n',round(etime(clock,initt)));

initt = clock;
[W3,H3]=NeNMF(X,r,'verbose',0,'W_INIT',Winit,'H_INIT',Hinit,'MAX_TIME',timelimit);
fprintf('method 3, time spent:%d (s)\n',round(etime(clock,initt)));

initt = clock;
[W4,H4]=nmf_lin(X,Winit,Hinit,0,timelimit,1000);
fprintf('method 4, time spent:%d (s)\n',round(etime(clock,initt)));

initt = clock;
[W5,H5]=nmf_kim(X,r,'NNLS_SOLVER','bp','type','plain','tol',0,'W_INIT',Winit,'H_INIT',Hinit,'MAX_TIME',timelimit,'max_iter',1e12);
fprintf('method 5, time spent:%d (s)\n',round(etime(clock,initt)));

initt = clock;
[W6,H6]=nmf_kim(X,r,'NNLS_SOLVER','as','type','plain','tol',0,'W_INIT',Winit,'H_INIT',Hinit,'MAX_TIME',timelimit,'max_iter',1e12);
fprintf('method 6, time spent:%d (s)\n',round(etime(clock,initt)));

Ws{1} = W1; Ws{2} = W2; Ws{3} = W3; Ws{4} = W4; Ws{5} = W5; Ws{6} = W6; 
Hs{1} = H1; Hs{2} = H2; Hs{3} = H3; Hs{4} = H4; Hs{5} = H5; Hs{6} = H6; 

fobjs = zeros(length(Ws),1);
for imethod =1:length(Ws),
% Losses{imethod} = 0.5*norm(X-Ws{imethod}*Hs{imethod},'fro')^2;
fobjs(imethod) = computeObj(X,Ws{imethod},Hs{imethod});
end
