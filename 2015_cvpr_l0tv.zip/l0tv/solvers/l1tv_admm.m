function [sol] = l1tv_admm(Init,B,V,Amap,Atmap,p,lambda,LargestEig,acc,Clean_B)
% min_{U} lambda * sum(sum((Dx.^p + Dy.^p).^(1/p))) + ||V.*(Amap(U)-B)||_1
% L(U,R,S,Z) = lambda * sum(sum((R.^p + S.^p).^(1/p))) + ||V.*Z||_1,
% s.t. Dx = R, Dy = S, Au - B = Z;
% L(U,R,S,Z) = lambda * sum(sum((R.^p + S.^p).^(1/p))) + ||V.*Z||_1
% + <piz,Amap(U)-B-Z> + 0.5 alpha || Amap(U)-B-Z ||^2
% + <pir,Dx-R> + 0.5 beta || Dx-R ||^2
% + <pis,Dy-S> + 0.5 beta || Dy-S ||^2


% Primal Variables
if(isempty(Init))
U = B;
Z = ones(size(B));
R = difX(B);
S = difY(B);
piz = zeros(size(B));
pir = zeros(size(B));
pis = zeros(size(B));
else
U = Init.U;
Z = Init.Z;
R = Init.R;
S = Init.S;
piz = Init.piz;
pir = Init.pir;
pis = Init.pis;
end



% iii = 1;
gamma = 1.5;
his = [];

beta  = 50;
alpha = 50;

[Dx] = difX(U);
[Dy] = difY(U);
AuB=Amap(U) - B;

for isub = 1:200,
    % Update Z
    % ||V.*Z||_1 + 0.5 alpha || piz/alpha+Amap(U)-B-Z ||^2
    % ||V.*Z||_1/alpha + 0.5 || piz/alpha+Amap(U)-B-Z ||^2
    C = AuB;
    Z = threadholding_l1_w(C+piz/alpha, V/alpha);
    
    % Update RS
    %     Dx = difX(U);
    %     Dy = difY(U);
    % Update RS
    R1 = - pir/beta - Dx;
    S1 = - pis/beta - Dy;
    if(p==2)
        normRS = sqrt(R1.^2 + S1.^2);
        Weight = (max(0,normRS-(lambda/beta))./normRS);
        Weight(normRS==0)=1;
        R = -R1.*Weight;
        S = -S1.*Weight;
    else
        R = - sign(R1).*max(0,abs(R1)-(lambda/beta));
        S = - sign(S1).*max(0,abs(S1)-(lambda/beta));
    end
    
    % Update U
    %     HandleAll = @(U) ComputeObj(U,V,R,S,Z,piz,pir,pis,alpha,beta,lambda,Amap,Atmap,B,p);
    
    %        [U]=SpectralGradient_NonMonotone(U,HandleAll,HandlePro,[]);
    %         [U]=smoothopt(U,HandleAll,20);
    last_U = U;
    Lip = beta*4 + beta * 4 + alpha * LargestEig;
    
    
    diff1 = AuB-Z;
    g1 = Atmap(piz) + alpha*Atmap(diff1);
    g2 = divX(-pir+beta*R)  - beta*divX(Dx);
    g3 = divY(-pis+beta*S) - beta*divY(Dy);
    grad =     g1 + g2 + g3;
    
    
    U = boxproj(U - grad/Lip);
    
    
    [Dx] = difX(U);
    [Dy] = difY(U);
    AuB  = Amap(U)-B;
    
    
    stop = max(max(abs(last_U - U)));
    
    
    %     fprintf('%d %f\n',isub,stop);
    if(isub > 15 && stop < acc),
        break;
    end
    
    %        fname2 = sprintf('%s\\result\\%d-%d.png',pwd,iter,isub);
    %        imwrite(U,fname2);
    
    %     fname2 = sprintf('%s\\result\\%d.png',pwd,iii);
    %     imwrite(U,fname2);
    %     iii = iii+1;
    diff1 = AuB-Z;
    diff2 = Dx-R;
    diff3 = Dy-S;

    nearness = maxnorm(diff2)+ maxnorm(diff3) + maxnorm(diff1);
    if(nearness<1/255),break;end
    
    %     [fobj,gradU] = ComputeObj(U,V,R,S,Z,piz,pir,pis,alpha,beta,lambda,Amap,Atmap,B,p);
    %         fprintf('iter:%d, fobj:%e, alpha:%f, beta:%f, rho:%f, nearness:%.1e (%.1e %.1e %.1e)\n',...
    %             isub,fobj,alpha,beta,rho,nearness,fnorm(Dx-R)+fnorm(Dy-S),fnorm(Amap(U) - B-Z),mdot(V,abs(Z)));
    
    pir = pir + gamma*beta*diff2;
    pis = pis + gamma*beta*diff3;
    piz = piz + gamma*alpha*diff1;
    %        his = [his;ComputeTrue(U,Amap,B,lambda,p)];
    %                 if(~mod(isub,10)),
    %                     if(min(fnorm(Dx-R),fnorm(Dy-S)) > fnorm(Amap(U) - B-Z)),
    %                         beta = (beta * 2);
    %                     else
    %                         alpha = (alpha *2);
    %                     end
    %                 end
    
end

sol=[];
sol.U = U;
sol.Z = Z;
sol.R = R;
sol.S = S;
sol.piz = piz;
sol.pir = pir;
sol.pis = pis;

function [fobj,gradU] = ComputeObj(U,V,R,S,Z,piz,pir,pis,alpha,beta,lambda,Amap,Atmap,B,p)
% [Dx] = difX(U);
% [Dy] = difY(U);
% f0 = lambda * sum(sum((R.^p + S.^p).^(1/p))) + mdot(V,abs(Z));
% f1 = mdot(piz, Amap(U)-B-Z) + 0.5*alpha*fnorm(Amap(U)-B-Z)^2;
% f2 = mdot(pir, Dx-R) + 0.5*beta*fnorm(Dx-R)^2;
% f3 = mdot(pis, Dy-S) + 0.5*beta*fnorm(Dy-S)^2;
% g1 = Atmap(piz) + alpha*Atmap(Amap(U)-B-Z);
% g2 = divX(-pir+beta*R)  - beta*divX(Dx);
% g3 = divY(-pis+beta*S ) - beta*divY(Dy);
% fobj1 = f0 + f1 + f2 + f3;
% gradU1 =     g1 + g2 + g3;

[Dx] = difX(U);
[Dy] = difY(U);
diff1 = Amap(U)-B-Z;
diff2 = Dx-R;
diff3 = Dy-S;
f1 = mdot(piz+diff1*0.5*alpha,diff1);
f2 = mdot(pir+diff2*0.5*beta,diff2);
f3 = mdot(pis+diff3*0.5*beta,diff3);
g1 = Atmap(piz) + alpha*Atmap(diff1);
g2 = divX(-pir+beta*R)  - beta*divX(Dx);
g3 = divY(-pis+beta*S) - beta*divY(Dy);
fobj = f1 + f2 + f3;
gradU =     g1 + g2 + g3;


function [x] = threadholding_l1_w(a,b)
% This program solves the following OP:
% min_{x} 0.5*x'*x - a'*x + <b,abs(x)>
% Here we assume b>=0

x = sign(a) .* max(0,abs(a)-b);

