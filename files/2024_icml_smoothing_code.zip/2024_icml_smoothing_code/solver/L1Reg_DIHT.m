function [x,his] = L1Reg_DIHT(A,b,lambda,k,x0)
% min_x lambda*0.5*x'*x + ||Ax-b||_1, s.t. ||x||_0 <= k
% max_y min_x lambda*0.5*x'*x + <y,Ax-b>, s.t. -1<=y<=1, ||x||_0 <= k
% max_y min_x lambda*0.5*x'*x + <y,Ax-b> - 0.5 theta ||y-y^t||^2 + 0.5 beta ||Ax-Axt||_^2, s.t. -1<=y<=1, ||x||_0 <= k

[m,n]=size(A);
x = x0;
y = A*x-b;
y = randn(size(y));
beta = 1;
theta = 1;
HandleObj = @(x)lambda*0.5*x'*x + norm(A*proj_l0(x,k)-b,1);
his = [];
for iter = 1:11000,
    
    % max_y min_x <y,Ax-b> - 0.5 theta ||y-y^t||^2 + 0.5 beta ||Ax-Axt||_^2, s.t. -1<=y<=1, ||x||_0 <= k
    % max_y <y,Ax-b> - 0.5 theta ||y-y^t||^2, s.t. -1<=y<=1
    % min_y -<y,Ax-b> + 0.5 theta ||y-y^t||^2, s.t. -1<=y<=1
    % min_y 0.5 theta ||y-y^t - (Ax-b)/theta ||^2, s.t. -1<=y<=1
    
    
    y = y + (A*x-b)/theta;
    y = max(y,-1);
    y = min(y,1);
    
    % min_x lambda*0.5*x'*x + <y,Ax-b> + 0.5 beta ||x-xt||_^2, s.t. ||x||_0 <= k
    % min_x lambda*0.5*x'*x + <y,Ax> + 0.5 beta ||x-xt||_^2, s.t. ||x||_0 <= k
    % min_x lambda*0.5*x'*x + 0.5 beta ||x-xt + A'y/beta||_^2, s.t. ||x||_0 <= k
    
    temp = (A'*y-beta*x)/(lambda+beta);
    x = proj_l0(-temp,k);
    
%     x = proj_l0(x - A'*y/beta,k);
    
    
    %     fprintf('iter:%d, fobj:%f\n',iter,HandleObj(x));
    
    if (~mod(iter,50))
        beta = beta*2;
    end
    
    
end
