clc;clear all;close all;
addpath('util','solver');
% 0.5 || AX-B||_F^2, s.t. X>=0

randn('seed',0); rand('seed',0);

n = 200; d = 1000;
A1 = rand(n,d);
B1 = rand(n,1);
X0 = rand(d,1);

A = A1'*A1;
b = -A1'*B1;
timelimit = 1;
HandleObj = @(x)0.5*norm(A1*x-B1,'fro')^2 ;
lambda = 0;
maxiter = 100;

const = 0.5*norm(B1,'fro')^2;
L = max(eig(A));
HandleObjSmooth =  @(x)computeObj(x,A1,B1);
HandleObjNonSmooth = @(x)0;
HandleProx = @(theta,a)computeprox(theta,a,lambda);

[x1,his1]=ProximalGradient_Contant_Stepsize(X0,HandleObjSmooth,HandleObjNonSmooth,HandleProx,maxiter,L);
[x2,his2]=ProximalGradient(X0,HandleObjSmooth,HandleObjNonSmooth,HandleProx,maxiter,L);
[x3,his3]=AccerlatedProximalGradient_Constant_Stepsize(X0,HandleObjSmooth,HandleObjNonSmooth,HandleProx,maxiter,L);
[x4,his4]=AccerlatedProximalGradient(X0,HandleObjSmooth,HandleObjNonSmooth,HandleProx,maxiter,L);
[x5,his5] = MSM (A1'*A1,-A1'*B1,const,lambda,X0,maxiter,timelimit,1);
semilogy([1:length(his1)],his1,[1:length(his2)],his2,[1:length(his3)],his3,[1:length(his4)],his4,[1:length(his5)],his5,'LineWidth',2);

legend('Classical PPA (constant)',...
    'Classical PPA (line search)',...
    'Accerlated PPA (constant)',...
    'Accerlated PPA (line search)',...
    'Proposed Matrix Splitting Method')
axis([1 50 0 500])
fprintf('Method1: %f\n',min(his1));
fprintf('Method2: %f\n',min(his2));
fprintf('Method3: %f\n',min(his3));
fprintf('Method4: %f\n',min(his4));

print(sprintf('%s.eps',mfilename), '-dpsc');
print( sprintf('%s.png',mfilename),'-dpng');

