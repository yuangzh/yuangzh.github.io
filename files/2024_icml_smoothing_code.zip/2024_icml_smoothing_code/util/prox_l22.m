function [x] = prox_l222(a,lambda)
% solving the following OP:
% min_{x} 0.5||x-a||^2 + lambda * ||x||_2^2
% grad = x - a + 2 * lambda x = 0
% (1+2lambda)x = a
x = a / (1+2*lambda);
