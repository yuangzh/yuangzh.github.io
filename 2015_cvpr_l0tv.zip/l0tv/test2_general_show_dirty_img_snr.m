clc;clear all;close all;


% clc;clear all;close all;

randn('seed',0);rand('seed',0);
addpath('cimg','dimg','util','solvers')

noiselevels=[10 30 50 70];
images = {'walkbridge','pepper','mandrill','lenna','lake','jetplane','blonde','cameraman','barbara','boat','pirate','livingroom','house'};
% noisetypes = {'Random-Valued','Salt-and-Pepper'};
% restorationtypes = {'denoising','deblurring'};
noisetypes = {'Salt-and-Pepper'};
restorationtypes = {'deblurring'};
% delete(sprintf('%s.txt',mfilename))
% result = {};
sol =[];
i_result= 1;
for mmm = 1:length(restorationtypes),
    for kkk = 1:length(images),
        for lll = 1:length(noisetypes),
            noisetype =noisetypes{lll};

            for jjj = 1:length(noiselevels),
                    noiselevel = noiselevels(jjj);
                    B_Clean = double(imread(sprintf('%s.png',images{kkk})));
                    
                    corrupted_image_name = sprintf('%s_%s_%s_%d.png',restorationtypes{mmm},images{kkk},noisetype,noiselevel);
                    B_Corrupted =  double(imread(corrupted_image_name));
                    
                    % Generate the mask matrix O
                    O = ones(size(B_Clean));
                    
                    %                     if(strcmp(noisetype,'Salt-and-Pepper'))
                    %                         O(B_Corrupted==max(abs(B_Corrupted(:))))=0;
                    %                         O(B_Corrupted==min(abs(B_Corrupted(:))))=0;
                    %                     end
                    
                    B_Clean = B_Clean/max(abs(B_Clean(:)));
                    B_Corrupted = B_Corrupted/max(abs(B_Corrupted(:)));
                    
 
                    
                    
 
                    v0=snr_l0(B_Corrupted, B_Clean);
                    v1=snr_l1(B_Corrupted, B_Clean);
                    v2=snr_l2(B_Corrupted, B_Clean);
                    
                    fprintf('%s %d     %.2f/%.2f/%.2f\n',images{kkk},noiselevel, v0,v1,v2);
 
            end
            

            

        end
    end
end

