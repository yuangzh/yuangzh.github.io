clc;clear all;close all;
cd util
mex nonconvex_prox_l1_mex.c
cd ..
