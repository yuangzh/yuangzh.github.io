function [R] = difY(X)
R = X([2:end end],:,:)-X;
