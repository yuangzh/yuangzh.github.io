function demo_write_latex_denoising
clc
clear all;
close all;

AAA{1} = load('test_l1tv.mat');
AAA{2} = load('test_amf.mat');
AAA{3} = load('test_aop_l02tv.mat');
AAA{4} = load('test_pd_l0tv.mat');
AAA{5} = load('test_mpec_padmm_l0tv.mat');

% noisetypes = {'Random-Valued','Salt-and-Pepper'};
% restorationtypes = {'denoising','deblurring'};

sel_noisetype = 'Random-Valued';
sel_restorationtype = 'denoising';

noiselevels_index=[1 2 3 4 5 6 7];

for i=1:26,
    for xx = 1:5,
        resultx{xx} = AAA{xx}.result{i};
    end

    if(~strcmp(resultx{1}.noisetype,sel_noisetype)),continue;end
    if(~strcmp(resultx{1}.restorationtype,sel_restorationtype)),continue;end

    for j = 1:length(noiselevels_index),
        cur_noise_ratio = resultx{1}.noiselevels(noiselevels_index(j));
        sss = sprintf('%s+%d',resultx{1}.image,cur_noise_ratio);fprintf(sss);fprintf('\\%%');fprintf('  &  ');
        for jj = 1:5,
        psnr0_optimal(jj) = max(resultx{jj}.psnr_l0(:,noiselevels_index(j)));
        psnr1_optimal(jj) = max(resultx{jj}.psnr_l1(:,noiselevels_index(j)));
        psnr2_optimal(jj) = max(resultx{jj}.psnr_l2(:,noiselevels_index(j)));

        psnr0_optimal_s{jj} = sprintf('%.2f',psnr0_optimal(jj));
        psnr1_optimal_s{jj} = sprintf('%.2f',psnr1_optimal(jj));
        psnr2_optimal_s{jj} = sprintf('%.2f',psnr2_optimal(jj));
        
        psnr0_optimal(jj) = str2num(psnr0_optimal_s{jj});
        psnr1_optimal(jj) = str2num(psnr1_optimal_s{jj});
        psnr2_optimal(jj) = str2num(psnr2_optimal_s{jj});
        end

        [nouse,Index_max0]=max(psnr0_optimal); 
        [nouse,Index_max1]=max(psnr1_optimal); 
        [nouse,Index_max2]=max(psnr2_optimal);
        for jj = 1:5,
            if(psnr0_optimal(jj) == psnr0_optimal(Index_max0))
                psnr0_optimal_s{jj} = sprintf('\\\\red{\\\\textbf{%s}}',psnr0_optimal_s{jj});
            end
            if(psnr1_optimal(jj) == psnr1_optimal(Index_max1))
                psnr1_optimal_s{jj} = sprintf('\\\\red{\\\\textbf{%s}}',psnr1_optimal_s{jj});
            end
            if(psnr2_optimal(jj) == psnr2_optimal(Index_max2))
                psnr2_optimal_s{jj} = sprintf('\\\\red{\\\\textbf{%s}}',psnr2_optimal_s{jj});
            end
        end
%         psnr1_optimal_s{Index_max} = sprintf('\\\\red{\\\\textbf{%s}}',psnr1_optimal_s{Index_max});
%         psnr2_optimal_s{Index_max} = sprintf('\\\\red{\\\\textbf{%s}}',psnr2_optimal_s{Index_max});
 

      

        for jj = 1:5,
        sss = sprintf('%s/%s/%s',psnr0_optimal_s{jj},psnr1_optimal_s{jj},psnr2_optimal_s{jj});fprintf(sss);
        if(jj~=5),fprintf('  &  ');else fprintf('  \\\\ ');end
        end
        
        fprintf('\n');

    end
         fprintf('\\hline\n');
        
end
