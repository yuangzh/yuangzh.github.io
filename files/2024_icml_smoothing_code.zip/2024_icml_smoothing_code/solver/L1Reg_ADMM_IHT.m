function [x,his] = L1Reg_ADMM_IHT(A,b,lambda,k,x0)
% min_x 0.5*lambda*x'*x + ||Ax-b||_1, s.t. ||x||_0 <= k 
% min_{x,y} 0.5*lambda*x'*x + ||y||_1, s.t. Ax-b = y, ||x||_0 <= k 
% L(x,y;pi) 0.5*lambda*x'*x + ||y||_1 + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k

[m,n]=size(A);
x = x0;

y = randn(m,1);

beta = 0.01;
HandleObj = @(x)0.5*lambda*x'*x + norm(A*proj_l0(x,k)-b,1);

HandleObj1 = @(x,y,beta)0.5*lambda*x'*x + norm(y,1) + 0.5*beta*norm(A*x-b-y)^2;

stop_accuracy = 1e-5;
last_k = 50;

last_k_out = 30;
changes = ones(last_k_out,1);
fobj_old = 1e10;
stop_accuracy_out = 1e-5;

last_k_tobj = 30;
changes_tobj = ones(last_k_tobj,1);
fobj_old_tobj = 1e10;
stop_accuracy_tobj = 1e-5;
normA2 = ComputeLagEigFromA(A);

for iter = 1:1000
% update x
% L(x,y;pi) = 0.5*lambda*x'*x + 1/m*||y||_1 + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
% L(x,y;pi) = 0.5*lambda*x'*x + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
L = beta*normA2 + lambda;
grad = lambda*x + beta * A'*(A*x-b-y);
x = x - grad / L;
% for in = 1:10
x = proj_l0(x,k);
% end



% update y
% L(x,y;pi) 1/m*||y||_1 + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2 , s.t. ||x||_0 <= k
% L(x,y;pi) 1/m*||y||_1 + 0.5 beta ||Ax-b-y + pi/beta||_2^2, s.t. ||x||_0 <= k
% L(x,y;pi) 1/m*||y||_1 + 0.5 beta ||Ax-b+pi/beta -y||_2^2, s.t. ||x||_0 <= k
% L(x,y;pi) 1/(m*beta)||y||_1 + 0.5 ||Ax-b+pi/beta -y||_2^2, s.t. ||x||_0 <= k
y = prox_l1(A*x-b,1/(beta));

fobj = HandleObj1(x,y,beta);
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    
    
diff = A*x - b - y;
% pi = pi + beta * diff;
dist = norm(diff);

tfobj = HandleObj(x);
his(iter) = tfobj;


 
    rel_change = abs((tfobj - fobj_old_tobj)/max(1,fobj_old_tobj));
    changes_tobj = [changes_tobj(2:end);rel_change];
    fobj_old_tobj = tfobj;
    
% HandleObj1(x,y,pi,beta)-HandleObj1(x,y,pi,beta/1.1)
%    beta = (iter)^0.5;

%  if(mean(changes)<stop_accuracy_out),
   if(~mod(iter,20))

 beta = beta*2;

%  changes = ones(last_k_out,1);
%  fobj_old = 1e10;
  end

if(mean(changes_tobj)<stop_accuracy_tobj && dist < 0.01),
break;
end





%    if (~mod(iter,30))
%        fprintf('iter:%d, dist:%f, fobj:%f, beta:%f, pen fobj:%f\n',iter,dist,HandleObj(x),beta,fobj); 
%     end


end

