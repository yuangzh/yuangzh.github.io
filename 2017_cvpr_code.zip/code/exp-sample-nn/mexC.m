clc;clear all;close all;
cd solver
mex linf_triangle_subproblem.c;
cd ..