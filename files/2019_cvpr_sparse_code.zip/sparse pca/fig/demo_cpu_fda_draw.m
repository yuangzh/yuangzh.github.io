
clc;clear all;close all;
addpath('util','cpu_result');
randn('seed',0);
rand('seed',0);


load('demo_cpu_fda');

for iter = 1:2,
    
x1 = result{iter}.x1; x2 = result{iter}.x2; x3 = result{iter}.x3; x4 = result{iter}.x4; x5 = result{iter}.x5; x6 = result{iter}.x6; x7 = result{iter}.x7; x8 = result{iter}.x8; 
his1 = result{iter}.his1; his2 = result{iter}.his2; his3 = result{iter}.his3; his4 = result{iter}.his4; his5 = result{iter}.his5; his6 = result{iter}.his6; his7 = result{iter}.his7; his8 = result{iter}.his8; 
tt1 = result{iter}.tt1; tt2 = result{iter}.tt2; tt3 = result{iter}.tt3; tt4 = result{iter}.tt4; tt5 = result{iter}.tt5; tt6 = result{iter}.tt6; tt7 = result{iter}.tt7; tt8 = result{iter}.tt8; 
 
%% color
pcolor=[];

pcolor.red      = [255,66,14]/256;    pcolor.red2     = [255,113,31]/256;   pcolor.red3     = [236,42,45]/256;
pcolor.blue     = [0,149,201]/256;    pcolor.blue2    = [114,214,238]/256;  pcolor.blue3    = [0,183,240]/256;  pcolor.blue4    = [0,192,192]/256;   pcolor.blue5    = [65,146,228]/256;
pcolor.green    = [0,170,77]/256;     pcolor.green2   = [81,157,28]/256;    pcolor.green3   = [36,178,76]/256;  pcolor.green4   = [192,192,0]/256;   pcolor.green5   = [76,181,60]/256;
pcolor.purple   = [143,76,178]/256;   pcolor.purple2  = [125,66,210]/256; pcolor.purple3  = [0,0,255]/256;
pcolor.crimson  = [192,52,148]/256;   pcolor.crimson2 = [245,147,202]/256; pcolor.crimson3  = [212,22,118]/256;
pcolor.orange   = [254,181,89]/256;   pcolor.orange2  = [255,129,0]/256;    pcolor.orange3  = [219,130,1]/256;
pcolor.gray     = [128,128,127]/256;
pcolor.yellow   = [255,204,51]/256;   pcolor.yellow2  = [248,235,46]/256;
pcolor.pink     = [255,130,160]/256; pcolor.pink2 = [255,0,255]/255;
pcolor.def      = [256,256,230]/256;
pcolor.darkred = [191/256 79/256 75/256];
colors  = [];

figure('color','w')
%     plot([1:length(his1)],his1,'--*','LineWidth',5,'MarkerSize',22,'color', pcolor.crimson ); hold on;
%     plot([1:length(his2)],his2,'-o','LineWidth',5,'MarkerSize',22,'color',  pcolor.blue ); hold on;
%     plot([1:length(his3)],his3,'-.x','LineWidth',5,'MarkerSize',22,'color', pcolor.gray); hold on;
%     plot([1:length(his4)],his4,'--^','LineWidth',5,'MarkerSize',22,'color', pcolor.darkred,'MarkerEdgeColor',pcolor.green3,'MarkerFaceColor', pcolor.yellow); hold on;
%     plot([1:length(his5)],his5,'LineWidth',5,'MarkerSize',22,'color', pcolor.yellow); hold on;
%     plot([1:length(his6)],his6,'LineWidth',5,'MarkerSize',22,'color', pcolor.purple,'MarkerEdgeColor',pcolor.pink,'MarkerFaceColor', pcolor.blue4); hold on;
%     plot([1:length(his7)],his7,'-s','LineWidth',5,'MarkerSize',22,'color', pcolor.orange3); hold on;


Handle = @plot;


Handle(tt1,his1,'-','LineWidth',5,'MarkerSize',22,'color', pcolor.crimson ); hold on;
Handle(tt2,his2,'-','LineWidth',5,'MarkerSize',22,'color',  pcolor.blue ); hold on;
Handle(tt3,his3,'-','LineWidth',5,'MarkerSize',22,'color', pcolor.gray); hold on;
Handle(tt4,his4,'-','LineWidth',5,'MarkerSize',22,'color', pcolor.darkred); hold on;
Handle(tt5,his5,'-','LineWidth',5,'MarkerSize',22,'color', pcolor.yellow); hold on;
Handle(tt6,his6,'-','LineWidth',5,'MarkerSize',22,'color', pcolor.purple); hold on;
Handle(tt7,his7,'-','LineWidth',5,'MarkerSize',22,'color', pcolor.orange3); hold on;
Handle(tt8,his8,'-','LineWidth',5,'MarkerSize',22,'color', pcolor.green); hold on;
% loglog(tt9,his9,'-','LineWidth',5,'MarkerSize',22,'color', pcolor.red); hold on;

 hleg=legend('TRF','DEC-B(R6S0)','DEC-B(R10S0)','DEC-B(R0S6)','DEC-B(R0S10)','DEC-B(R4S4)','DEC-B(R6S6)','DEC-B(R8S8)') ;

        set(hleg,'Fontsize',16);
    x = [tt1(:);tt2(:);tt3(:);tt4(:);tt5(:);tt6(:);tt7(:);tt8(:)];
    y = [his1(:);his2(:);his3(:);his4(:);his5(:);his6(:);his7(:);his8(:)];

       ylabel('Objective','FontSize',25)
    xlabel('Time(s)','FontSize',25)
    set(gca,   'Fontsize', 22);
    

     if(iter==1)
    axis([min(x) 4 min(y) max(y)]);
 else
    axis([min(x) 4 min(y) max(y)]);
 end
% fprintf('%.5f\n',HandleObj(x1));
% fprintf('%.5f\n',HandleObj(x2));
% fprintf('%.5f\n',HandleObj(x3));
% fprintf('%.5f\n',HandleObj(x4));
% fprintf('%.5f\n',HandleObj(x5));
% fprintf('%.5f\n',HandleObj(x6));
% fprintf('%.5f\n',HandleObj(x7));
% fprintf('%.5f\n',HandleObj(x8));
% fprintf('%.5f\n',HandleObj(x9));
grid on;


   set(gcf,'paperpositionmode','auto')
    print(sprintf('%s_%d.eps',mfilename,iter),'-depsc2','-loose');
    print(sprintf('%s_%d.png',mfilename,iter),'-dpng');
    
    
end

