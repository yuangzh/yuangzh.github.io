function x = prox_lp(a,lambda)
% min_x  lambda*|x(i)|^0.5 + 0.5|x(i)-a(i)|^2
x = prox_lp_xu(a,lambda*2);



function x = prox_lp_xu(a,lambda)
% min_x  sum_i^n   lambda*|x(i)|^0.5 + |x(i)-a(i)|^2

ths = (54^(1/3))/4 * (lambda)^(2/3);
fi =  acos((abs(a)/3).^(-1.5).*lambda./8);
fi = real(fi);
x = (2/3).*a.*(1+cos(2*pi/3-(2/3).*fi));
x(abs(a)<=ths)=0;

