function x = norm_one(x)
x =  x / norm(x);