clc;
warning off;
addpath('PROPACK');

n = 1000;
A = randn(n);
A = A+A';
tic;
[vector,value]=largest(A,0.5);
toc;
