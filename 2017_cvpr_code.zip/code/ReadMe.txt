README File
=================================================
1. Running the Code
To reproduce the experiments in [1], you need to perform two steps: (i) run mexC.m (ii) run demo.m

2. REFERENCES:
[1] Ganzhao Yuan, Wei-Shi Zheng, Bernard Ghanem. A Matrix Splitting Method for Composite Function Minimization, IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2017.