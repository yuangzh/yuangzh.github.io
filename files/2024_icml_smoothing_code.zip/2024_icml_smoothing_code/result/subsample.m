function [x,y] = subsampleing(x,y)
n1 = length(x);
n2 = length(y);
if(n1~=n2),
    error('not equal!');
end
I = randperm(n1,100);
I = sort(I);
x=x(I);
y=y(I);
