function best_t = nonconvex_prox_l1topk(beta,lambda,x,i,k)
% min_t 0.5 t^2 - beta t + lambda ||x+tei||_1 - lambda || x+tei ||_{top-k}

% case 1: x(i)+ t ����top-k set
% t - beta  = 0  => t = beta
% case 2: x(i)+ t ������top-k set
% t - beta + lambda sign(x(i)+t) = 0
% x(i)+t = 0 =>  t = -x(i)
% t - beta + lambda = 0   =>   t = beta - lambda
% t - beta - lambda = 0   =>   t = beta + lambda

ts = [-x(i);beta;beta+lambda;beta-lambda];
HandleObj = @(t)ComputeObj(t,beta,lambda,x,i,k);
best_fobj = inf;
for i = 1:length(ts)
    test_obj = HandleObj(ts(i));
    if(test_obj<best_fobj)
        best_fobj = test_obj;
        best_t = ts(i);
    end
end



function [f] = ComputeObj(t,beta,lambda,x,i,k)
r = x;
r(i) = r(i) + t;
val = sort(abs(r),'descend');
f = 0.5*t^2 - beta*t + lambda*abs(x(i)+t) - lambda*sum(val(1:k));
% g =  t - beta + lambda*sign(x(i)+t) - lambda* 

