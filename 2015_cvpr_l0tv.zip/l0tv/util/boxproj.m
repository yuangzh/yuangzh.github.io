function [x] = boxproj(x)
% x=max(x,0);
% x=min(x,1);
x(x<0)=0;
x(x>1)=1;
