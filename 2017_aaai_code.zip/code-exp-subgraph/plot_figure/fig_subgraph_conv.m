clc;clear all;close all;
addpath('util');


load('result_demo_box.mat');   box = result;
load('result_demo_feige.mat'); feige = result;
load('result_demo_ravi.mat');  ravi = result;
load('result_demo_tpm.mat');   tpm = result;
load('result_demo_mpec_epm.mat');   epm = result;
load('result_demo_mpec_adm.mat');   adm = result;
load('result_demo_l2box_admm.mat');   diadm = result;

jj_sel = [2:7];


for ii=4:4,
    for jjj=1:length(jj_sel),
        idata = ii;
        iX = jj_sel(jjj);

        yData{1} = box{idata,iX}.his; yData{1}(1) = yData{1}(2);
        yData{2} = tpm{idata,iX}.his; yData{2}(1) = yData{2}(2);
        yData{3} = diadm{idata,iX}.his;
        yData{4} = epm{idata,iX}.his;
        for i=1:length(yData),
            xData{i} = [1:length(yData{i})];
        end

        options=loadopt2;
        h = figure;
        for i=1:length(yData),
            plot(xData{i},yData{i},'color',options.colors{i},'LineWidth',5); hold on
        end
        xlabel('Iteration','FontSize',18);
        ylabel('Objective','FontSize',18);
        print( '-dpsc',sprintf('%s_%d_%d.eps',mfilename,idata,iX));
%       print( '-dpng',sprintf('%s_%d_%d.png',mfilename,idata,iX));
        
        
        set(h, 'Position', [0 0 1000 500])
        h1 = legend('LP','TPM','L2box-ADMM','MPEC-EPM');
        set(h1,'FontSize',18,'FontWeight','normal');
        set(h1,'Location','NorthEast');
        % set(h1,'box','off')
        set(h1,'Location','northoutside','Orientation','horizontal');
        axis off
        h2 = findobj(gca,'Type','line');
        set(h2, 'visible', 'off');
        namestr = sprintf('%s_legend.png',mfilename);
        print( '-dpng',namestr);
        close all;

 
    end
end