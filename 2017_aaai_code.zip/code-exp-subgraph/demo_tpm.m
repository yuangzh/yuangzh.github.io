clc;clear all;clear all;randn('seed',0); rand('seed',0);warning off;
addpath('util','solver','PROPACK',genpath('bvgraph'));

read_dataset_and_k;
result= [];

for i=1:length(datasets),
    
    namedata = datasets{i};
    fprintf('data: %s, #:%d\n',namedata,i);
    W = sparse(bvgraph(sprintf('data\\%s',namedata)));
    
    for j=1:length(ks),
    
        randn('seed',0); rand('seed',0); k = ks(j);

        options = [];
        options.OptTol = 1e-6;
        options.cardinality = k;
        options.MaxIter = 500;
        options.verbose = 0;
        options.initType = 2;
        
        HandleObj = @(x)computeobj(x,W,k);
        options.HandleObj = HandleObj;
        t1=clock;[x,~,his] = dsf_tpm(W,options);t2 = clock; cpu = etime(t2,t1);
        obj = HandleObj(x);
        fprintf('method:%s. k: %d, cpu: %f, fobj: %f\n',mfilename,k,cpu,obj);
        
        one=[];  one.cpu = cpu; one.obj = obj; one.his = his; result{i,j} =  one;
        save(sprintf('result_%s',mfilename),'result')
        
    end
    
end



