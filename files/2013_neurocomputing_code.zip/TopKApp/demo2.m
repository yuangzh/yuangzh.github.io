% This is a demo of solving the following optimization:
% max_U  tr(U'AU)
% s.t. U'*U = I

clc;clear all;close all;
randn('state',  10);
rand('state',  10);   

% set size of the problem
n =  2000;

% generate A
A = randn(n,3); A=A*A';

% set r
r = 10 ;
 
% run lro
tic; [U1]=lro(A,r); t1=toc;
fprintf('\n lro solver: objective:%e, orthogonality:%e, time:%e\n',trace(U1'*A*U1),norm(U1'*U1-eye(r),'fro'),t1);

% run eigs
tic;[U2,non]=eigs(A,r,'la'); t2=toc;
fprintf('eigs solver: objective:%e, orthogonality:%e, time:%e\n',trace(U2'*A*U2),norm(U2'*U2-eye(r),'fro'),t2);
 
% run eig
tic; [U3,non]=eig(A); U3 = U3(:,(n-r+1):n); t3=toc;
fprintf(' eig solver: objective:%e, orthogonality:%e, time:%e\n',trace(U3'*A*U3),norm(U3'*U3-eye(r),'fro'),t3);
 
