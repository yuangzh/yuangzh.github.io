function [x] = prox_linf(a,lambda)
% solving the following OP:
% min_{x} 0.5 ||x-a||^2 + lambda * ||x||_inf
% max_{y} min_{x} 0.5||x-a||^2 + lambda * <y,x>, s.t. ||y||_1<=1
% grad_x = x-a+lambda y=0
% x = a-lambda y
% max_{y} 0.5||a-lambda y-a||^2 + lambda * <y,a-lambda y>, s.t. ||y||_1<=1
% max_{y} -0.5||lambda y||^2 + lambda * <y,a>, s.t. ||y||_1<=1
% max_{y} -0.5lambda|| y||^2 + <y,a>, s.t. ||y||_1<=1
% min_{y} 0.5lambda|| y||^2 - <y,a>, s.t. ||y||_1<=1
% min_{y} 0.5 lambda || y - a/lambda ||^2, s.t. ||y||_1<=1
y = proj_l1(a/lambda,1);
x = a - lambda * y;


