clc;clear all;clear all;
addpath('util','solver','PROPACK',genpath('bvgraph'));
read_dataset_and_k;

for i=1:length(datasets),
    namedata = datasets{i};
    W = sparse(bvgraph(sprintf('data\\%s',namedata)));
    fprintf(' %s & %d & %d & %.2f \\\\ \n',namedata,size(W,1),full(nnz(W)),full(mean(sum(W,2))));
end
