function demo_acc_DCBinaryOpt
% min_x 0.5 ||Ax-b||_2^2  + lambda (sqrt(n) - ||x||_2), s.t. -1 <= x <= 1

clc;clear all;close all;
addpath('util');
rand('seed',0);
randn('seed',0);

id_data = [11 12 13 14 21 22 23 24 31 32 33 34 41 42 43 44];
times = 10;


result = [];
for idat = 1:length(id_data)
    
    avg_his1 = [];
    avg_his2 = [];
    avg_his3 = [];
    avg_his4 = [];
    avg_his5 = [];
    for it = 1:times,
        % Main Algorithms
        G = getdata_pca(id_data(idat));
        y = generate_y_DCBinaryOpt(G);
        x0 = 1*randn(size(G,2),1);
        lambda = 5;
        MaxTime = 100;
        [x1,his1,ts1] = MSCR(G,y,x0,lambda,MaxTime);
        [x2,his2,ts2] = Linearized_MSCR(G,y,x0,lambda,MaxTime);
        [x3,his3,ts3] = SubGradient(G,y,x0,lambda,MaxTime);
        [x4,his4,ts4] = CD_SCA(G,y,x0,lambda,MaxTime);
        [x5,his5,ts5] = CD_SNCA(G,y,x0,lambda,MaxTime);
        
        % Scale the objectives if they are negative
%         CCC = min([his1(:);his2(:);his3(:);his4(:);his5(:)])+eps;
%         CCC = min(0,CCC); his1=his1+CCC; his2=his2+CCC; his3=his3+CCC; his4=his4+CCC; his5=his5+CCC;
        
        avg_his1(it) = min(his1); avg_his2(it) = min(his2); avg_his3(it) = min(his3); avg_his4(it) = min(his4); avg_his5(it) = min(his5);
    end
    
    One = [];
    One.his1 = [mean(avg_his1);std(avg_his1)];
    One.his2 = [mean(avg_his2);std(avg_his2)];
    One.his3 = [mean(avg_his3);std(avg_his3)];
    One.his4 = [mean(avg_his4);std(avg_his4)];
    One.his5 = [mean(avg_his5);std(avg_his5)];
    result{idat} = One; save(mfilename,'result')
    
    % Print
%     fprintf('result:\n');
%     fprintf('Alg 1: %f %f\n',mean(avg_his1),std(avg_his1));
%     fprintf('Alg 2: %f %f\n',mean(avg_his2),std(avg_his2));
%     fprintf('Alg 3: %f %f\n',mean(avg_his3),std(avg_his3));
%     fprintf('Alg 4: %f %f\n',mean(avg_his4),std(avg_his4));
%     fprintf('Alg 5: %f %f\n',mean(avg_his5),std(avg_his5));
    
    fprintf('%s & ',GetDataStr(idat));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his1),std(avg_his1));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his2),std(avg_his2));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his3),std(avg_his3));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his4),std(avg_his4));
    fprintf('%.3f $\\pm$ %.3f  ',mean(avg_his5),std(avg_his5));
    fprintf('\\\\');
    fprintf('\n');
end

function [x,his,ts] = SubGradient(A,b,x0,lambda,MaxTime)
% min_x 0.5 ||Ax-b||_2^2  + lambda (sqrt(n) - ||x||_2), s.t. -1 <= x <= 1
initt = clock;
x = x0;
his = [];ts = [];
n = length(x0);
x = max(-1,min(x,1));
fobj = ComputeObj(x,A,b,lambda,n);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;

for iter = 1:10000
    fobj = ComputeObj(x,A,b,lambda,n);
    grad = A'*(A*x-b) - lambda*x/norm(x);
    step = 1/sqrt(iter);
    x = x - step*grad;
    x = max(-1,min(x,1));
    %   fprintf('iter:%d, fobj:%f, normG:%f\n',iter,fobj,norm(grad));
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end
% plot(his)
% ddd

function [x,his,ts] = CD_SCA(G,y,x0,lambda,MaxTime)
% min_x 0.5 ||Gx-y||_2^2  + lambda (sqrt(n) - ||x||_2), s.t. -1 <= x <= 1
initt = clock;
x = x0;
his = []; ts = [];
n = length(x0);
x = max(-1,min(x,1));
gg = sum(G.*G,1)'+1e-8;
Gy = G'*y;
Gx = G*x;
xx = x'*x;
const = 0.5*y'*y + lambda*sqrt(n);

fobj = Gx'*(0.5*Gx-y) + const - lambda*sqrt(xx);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter = 1:1e10
    %   i = randperm(n,1);
    i = mod(iter,n)+1;
    %     ei = zeros(n,1);
    %     ei(i)=1;
    sub_grad_i = x(i)/sqrt(xx);
    % min_t 0.5 ||G(x+tei)-y||_2^2  - lambda <sub_grad,tei>, s.t. -1 <= x+tei <= 1
    %     d = G*ei;
    d = G(:,i);
    %         c = G*x - y;
    cd = Gx'*d - Gy(i);
    % min_t 0.5 ||c + t d ||_2^2  - lambda <sub_grad,tei>, s.t. -1 <= x+tei <= 1
    % min_t 0.5 d'd t^2 + <c,d> t  - lambda <sub_grad,tei>, s.t. -1 <= x+tei <= 1
    % min_t 0.5 t^2 + <c,d>/d'd t  - lambda <sub_grad,tei>, s.t. -1 <= x+tei <= 1
    % min_t 0.5 t^2 + <c,d>/d'd t - lambda / d'd <sub_grad,tei>, s.t. -1-x(i) <= t <= 1-x(i)
    t = ( -cd + lambda*sub_grad_i) / gg(i);
    t = max(-1-x(i),min(1-x(i),t));
    x(i) = x(i)+t;
    Gx = Gx + t*G(:,i);
    xx = xx + 2*t*x(i) - t*t;
    % fobj = ComputeObj(x,G,y,lambda,n);
    % x = max(-1,min(1,x));
    % fobj = 0.5*norm(G*x-y)^2  + lambda*(sqrt(n) - norm(x));
    
    fobj = Gx'*(0.5*Gx-y) + const - lambda*sqrt(xx);
    % fprintf('iter:%d, fobj:%f \n',iter,fobj);
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end

function [x,his,ts] = CD_SNCA(G,y,x0,lambda,MaxTime)
% min_x 0.5 ||Gx-y||_2^2  + lambda (sqrt(n) - ||x||_2), s.t. -1 <= x <= 1
% min_x 0.5 x'G'Gx - <Gx,y> + 0.5y'y + lambda (sqrt(n) - ||x||_2), s.t. -1 <= x <= 1
initt = clock;
x = x0;
his = []; ts = [];
n = length(x0);
x = max(-1,min(x,1));

gg = sum(G.*G,1)'+1e-8;
Gy = G'*y;
Gx = G*x;
xx = x'*x;
const = 0.5*y'*y + lambda*sqrt(n);
fobj = Gx'*(0.5*Gx-y) + const - lambda*sqrt(xx);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-14;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter = 1:1e10
    %   i = randperm(n,1);
    i = mod(iter,n)+1;
    %     ei = zeros(n,1);
    %     ei(i)=1;
    
    % min_t 0.5 ||A(x+tei)-b||_2^2  + lambda (sqrt(n) - ||x+tei||_2), s.t. -1 <= x+tei <= 1
    %     d = A*ei;
    d = G(:,i);
    cd = Gx'*d - Gy(i);
    
    
    
    % min_t 0.5 ||c + t d ||_2^2  + lambda (sqrt(n) - ||x+tei||_2), s.t. -1 <= x+tei <= 1
    % min_t 0.5 d'd t^2 + <c,d> t  + lambda (sqrt(n) - ||x+tei||_2), s.t. -1 <= x+tei <= 1
    % min_t 0.5 t^2 + <c,d>/d'd t  - lambda/(d'd)  ||x+tei||_2, s.t. -1 <= x+tei <= 1
    % min_t 0.5 t^2 + <c,d>/d'd t  - lambda/(d'd)  ||x+tei||_2, s.t. -1-x(i) <= t <= 1-x(i)
    
    t = nonconvex_prox_linfl2(-cd/gg(i),lambda/gg(i),x,i,-1-x(i),1-x(i));
    x(i) = x(i)+t;
    
    % reconstruct Gx in linear time
    %     iter:300, fobj:0.274678
    Gx = Gx + t*G(:,i);
    xx = xx + 2*t*x(i) - t*t;
    % fobj = ComputeObj(x,G,y,lambda,n);
    % x = max(-1,min(1,x));
    % fobj = 0.5*norm(G*x-y)^2  + lambda*(sqrt(n) - norm(x));
    
    fobj = Gx'*(0.5*Gx-y) + const - lambda*sqrt(xx);
    % fprintf('iter:%d, fobj:%f \n',iter,fobj);
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
    
end
%  plot(his)
%  ddd
function [x,his,ts] = Linearized_MSCR(A,b,x0,lambda,MaxTime)
% min_x 0.5 ||Ax-b||_2^2  + lambda (sqrt(n) - ||x||_2), s.t. -1 <= x <= 1
% min_x min_y 0.5 ||Ax-b||_2^2  + lambda (sqrt(n) - <x,y>), s.t. -1 <= x <= 1, ||y||_2^2 \leq n
initt = clock;
[m,n] = size(A);
x = x0;
x = max(-1,min(x,1));
his = []; ts = [];
fobj = ComputeObj(x,A,b,lambda,n);
his  = [his;fobj];
ts = [ts;etime(clock,initt)];
 

L = SpectralNorm(A);

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;

for iter = 1:1e10
    y = x / norm(x) * sqrt(n);
    c = -lambda*y;
    % min_x 0.5 ||Ax-b||_2^2  + <x,c>, s.t. -1 <= x <= 1
    
    % min_x 0.5 ||Ax-b||_2^2  + <x,c>, s.t. -1 <= x <= 1
    
    
    grad = A'*(A*x-b)+c;
    x = min(1,max(x - grad/L,-1));
    
    
    fobj = ComputeObj(x,A,b,lambda,n);
    %     fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his  = [his;fobj];
    
    
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end

function [x,his,ts] = MSCR(A,b,x0,lambda,MaxTime)
% min_x 0.5 ||Ax-b||_2^2  + lambda (sqrt(n) - ||x||_2), s.t. -1 <= x <= 1
% min_x min_y 0.5 ||Ax-b||_2^2  + lambda (sqrt(n) - <x,y>), s.t. -1 <= x <= 1, ||y||_2^2 \leq n
initt = clock;
[m,n] = size(A);
x = x0;
x = max(-1,min(x,1));
his = [];ts = [];
fobj = ComputeObj(x,A,b,lambda,n);
his  = [his;fobj];
ts = [ts;etime(clock,initt)];

% L = norm(A)^2;

L = SpectralNorm(A);


last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter = 1:1e10
    y = x / norm(x) * sqrt(n);
    c = -lambda*y;
    % min_x 0.5 ||Ax-b||_2^2  + <x,c>, s.t. -1 <= x <= 1
    
    % min_x 0.5 ||Ax-b||_2^2  + <x,c>, s.t. -1 <= x <= 1
    
    for in = 1:10
        grad = A'*(A*x-b)+c;
        x = min(1,max(x - grad/L,-1));
    end
    
    fobj = ComputeObj(x,A,b,lambda,n);
    %     fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his  = [his;fobj];
    
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end

function [fobj] = ComputeObj(x,G,y,lambda,n)
x = max(-1,min(1,x));
fobj = 0.5* norm(G*x-y)^2  + lambda*(sqrt(n) - norm(x));


 

