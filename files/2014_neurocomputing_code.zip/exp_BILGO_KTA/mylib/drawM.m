function drawM(M)
figure;
% r=100;
% c=100;
% M=randn(r,c);
[r,c]=size(M);



     %# Get the matrix size
imagesc((1:c)+0.5,(1:r)+0.5,M);            %# Plot the image
% colormap( [255/255,160/255,160/255; 134/255,206/255,255/255])
% colormap( [255/255,160/255,160/255; 134/255,206/255,255/255])
%    colormap( [255/255,160/255,160/255; 134/255,206/255,255/255])
%   colormap( [134/255,206/255,255/255; 255/255,255/255,255/255])
%   colormap( [ 255/255,255/255,255/255; 134/255,206/255,255/255])
%    colormap( [255/255,160/255,160/255; 255/255,160/255,160/255])
 

axis equal                                   %# Make axes grid sizes equal
set(gca,'XTick',1:(c+1),'YTick',1:(r+1),...  %# Change some axes properties
        'XLim',[1 c+1],'YLim',[1 r+1],...
        'GridLineStyle','-','XGrid','on','YGrid','on');
    
    set(gcf,'position', [300 200 500 500]);
 ylabel(' ','FontSize',15) 
xlabel(' ','FontSize',15)

    set(gca,'yTickLabel','')
set(gca,'xTickLabel',{[];[]; []; []; [];[];[];[];[];[]});
set(gcf,'color','w');
