clc;clear all;close all;
randn('seed',0);rand('seed',0);
addpath('cimg','dimg','util','solvers')


%        images = {'lenna'};lambda = 70;
%        images = {'cameraman'};lambda = 100;
     images = {'pirate'}; lambda = 25;






B_Clean = double(imread(sprintf('%s.png',images{1})));
corrupted_image_name = sprintf('%s2.png',images{1});
B_Corrupted =  double(imread(corrupted_image_name));

% Generate the mask matrix O
O = ones(size(B_Clean));
B_Clean = B_Clean/max(abs(B_Clean(:)));
B_Corrupted = B_Corrupted/max(abs(B_Corrupted(:)));
% B_Corrupted - B_Clean
% dd


p = 2;
P = GenBlurOper;
LargestEig = min(sqrt(sum(abs(P(:))>0)*sum(P(:).*P(:))), sum(abs(P(:))));% Largest Eigenvalue of A'A

Amap = @(X)functionAX(P,X,'denoising');
Atmap = @(X)functionAX(P',X,'denoising');

acc = 1/2555;
[U] = l0tv_proj_reg(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,B_Clean);

S=ones(size(U)) - abs(B_Corrupted-U);
PSNR   =  snr_l0(U, B_Clean);
PSNR

figure;
subplot(1,4,1); imshow(B_Clean,[]);title('Original','fontsize',13);
subplot(1,4,2); imshow(B_Corrupted,[]); title('Corrupted','fontsize',13);
subplot(1,4,3); imshow(U,[]); title('Recovered','fontsize',13);
subplot(1,4,4); imshow(S,[]); title('Recovered2','fontsize',13);

imwrite(U,sprintf('show_recover1_%s_l0tv_pda.png',images{1}));
imwrite(S,sprintf('show_recover2_%s_l0tv_pda.png',images{1}));


% fprintf('SNR0:%.2f, SNR1:%.2f, SNR2:%.2f\n',snr_l0(B_Corrupted, B_Clean),snr_l1(B_Corrupted, B_Clean),snr_l2(B_Corrupted, B_Clean));
% fprintf('SNR0:%.2f, SNR1:%.2f, SNR2:%.2f\n',snr_l0(U, B_Clean),snr_l1(U, B_Clean),snr_l2(U, B_Clean));

