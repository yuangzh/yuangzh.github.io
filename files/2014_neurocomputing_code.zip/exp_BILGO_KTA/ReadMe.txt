BILGO-KTA README File
=================================================

1. Using the code
(1) Please run "mex_file.m" to build MEX functions.
(2) To test the code, we have provided a demo Matlab script "demo.m", 
    which runs BILGO-KTA over some real world data.

2. Main files
(1) kta.m ------------------------ Implementation of Kernel Target Alignment Metric Learning.
(2) eig_newton_lanczos.m --------- A Lanczos-based Hessian-free Newton method to find leading eigenvector
(3) quadratic_two_variables.m ---- two variables box-constrained quadratic programming solver
 
3. REFERENCES:
[1] Zhifeng Hao, Ganzhao Yuan, Zhenjie Zhang, Bernard Ghanem. 
    BILGO: Bilateral Greedy Optimization for Large Scale Semidefinite Programming
    Submitted to Machine Learning Jounal
