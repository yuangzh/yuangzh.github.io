clc;clear all;close all;
randn('seed',0);
rand('seed',0);

% delete *.png
addpath('cimg','util')
ns=[10:20:90];

images = {'walkbridge','pepper','mandrill','lenna','lake','jetplane','blonde','cameraman','barbara','boat','pirate','livingroom','house'};
dirty_image_direetory = 'dimg';

fprintf('denoising Salt-and-Pepper begin\n');
for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        B_Corrupted = impulsenoise(B_Clean,ns(i)/100,0);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s//denoising_%s_%s_%d.png',dirty_image_direetory,images{j},'Salt-and-Pepper',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end
fprintf('\ndenoising Salt-and-Pepper end\n\n');

fprintf('denoising Random-Valued begin\n');
for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        B_Corrupted = impulsenoise(B_Clean,ns(i)/100,1);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s//denoising_%s_%s_%d.png',dirty_image_direetory,images{j},'Random-Valued',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end
fprintf('\ndenoising Random-Valued end\n\n');


fprintf('denoising mixed noise begin\n');
for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        mm = size(B_Clean,1);
        nn = size(B_Clean,2);
        seq = randperm(mm*nn);
        interval = mm*nn/2;
        seq1 = seq(1:interval);
        seq2 = seq((interval+1):end);
        B_Corrupted = B_Clean;
        B_Corrupted(seq1) = impulsenoise(B_Corrupted(seq1),ns(i)/100,0);
        B_Corrupted(seq2) = impulsenoise(B_Corrupted(seq2),ns(i)/100,1);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s//denoising_%s_%s_%d.png',dirty_image_direetory,images{j},'Mixed',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end
fprintf('\ndenoising mixed noise end\n\n');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('deblurring Salt-and-Pepper begin\n');

for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        P = GenBlurOper;
        Amap = @(X)functionAX(P,X,'deblurring');
        B_Corrupted = impulsenoise(Amap(B_Clean),ns(i)/100,0);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s//deblurring_%s_%s_%d.png',dirty_image_direetory,images{j},'Salt-and-Pepper',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end
fprintf('\ndeblurring Salt-and-Pepper end\n\n');

fprintf('deblurring Random-Valued begin\n');
for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        P = GenBlurOper;
        Amap = @(X)functionAX(P,X,'deblurring');
        B_Corrupted = impulsenoise(Amap(B_Clean),ns(i)/100,1);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s//deblurring_%s_%s_%d.png',dirty_image_direetory,images{j},'Random-Valued',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end

fprintf('\ndeblurring Random-Valued end\n\n');


fprintf('deblurring Mixed begin\n');
for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        P = GenBlurOper;
        Amap = @(X)functionAX(P,X,'deblurring');      
        AX_Clean = Amap(B_Clean);   
        mm = size(AX_Clean,1);
        nn = size(AX_Clean,2);
        seq = randperm(mm*nn);
        interval = mm*nn/2;
        seq1 = seq(1:interval);
        seq2 = seq((interval+1):end);
        B_Corrupted = AX_Clean;
        B_Corrupted(seq1) = impulsenoise(B_Corrupted(seq1),ns(i)/100,0);
        B_Corrupted(seq2) = impulsenoise(B_Corrupted(seq2),ns(i)/100,1);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s//deblurring_%s_%s_%d.png',dirty_image_direetory,images{j},'Mixed',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end

fprintf('\ndeblurring Mixed end\n\n');


