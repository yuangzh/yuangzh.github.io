function [f,ind] = topksum(x,k)
absx = abs(x);
[sort_absx,ind]=sort(absx,'descend');
% f = sum(absx(ind(1:k)));
f = sum(sort_absx(1:k));
ind = ind(1:k);


