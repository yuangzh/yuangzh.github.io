function value = ComputeLagEigFromA(A)
[m,n]=size(A);
if(m>n)
[vector,value] = laneig(A'*A,1,'AL');
else
[vector,value] = laneig(A*A',1,'AL');
end

