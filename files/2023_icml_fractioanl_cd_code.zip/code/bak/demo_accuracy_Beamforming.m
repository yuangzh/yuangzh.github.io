

% min_x x'x / ( lambda x'x + min(|Ax|)^2  )
clc;clear all;close all;
addpath('util','data','solver');
rand('seed',1);
randn('seed',1);

id_data = [11 12 13 14 21 22 23 24 31 32 33 34 41 42 43 44];


times = 8;
result = [];

for idat = 1:length(id_data)
    avg_his1 = [];
    avg_his2 = [];
    avg_his3 = [];
    
    for it = 1:times,
        fprintf('%d %d\n',it,idat);
%         randn('seed',it);
        G = getdata_ica(id_data(idat));
%         G = randn(size(G));
     
%     for i=1:size(G,2)
%     vvv(i) = norm(G(:,i))^2;
%     end
%     lambda = max(vvv);
 
lambda = max(sum(G.*G,1));
 

        x0 =  randn(size(G,2),1);
        MaxTime = 60;
        accuracy = 1e-10;
        speak = 1;
 
        [x1,his1] = Beamforming_PGSA(G,lambda,x0,speak,accuracy,MaxTime);
 
        plot(his1)
        dd
        [x2,his2] = Beamforming_PowerMethod(G,x0,speak,accuracy,MaxTime);
        [x3,his3] = Beamforming_FractionalCD(G,x0,speak,accuracy,MaxTime);
        
        avg_his1(it) = min(his1); avg_his2(it) = min(his2); avg_his3(it) = min(his3);
    end
    
    One = [];
    One.his1 = [mean(avg_his1);std(avg_his1)];
    One.his2 = [mean(avg_his2);std(avg_his2)];
    One.his3 = [mean(avg_his3);std(avg_his3)];
    result{idat} = One; save(mfilename,'result')
    
    fprintf('%s & ',GetDataStr2(idat));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his1),std(avg_his1));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his2),std(avg_his2));
    fprintf('%.3f $\\pm$ %.3f  ',mean(avg_his3),std(avg_his3));
    fprintf('\\\\');
    fprintf('\n');
    
end

 