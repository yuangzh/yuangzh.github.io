function [x] = proj_01k(a,k)
% min_{x} ||x-a||_2^2, s.t. x \in {0,1}, sum(x) = k
x = zeros(length(a), 1);
[val, idx] = sort(abs(a), 'descend');
x(idx(1:k)) = 1;