function [x,his] = block_K_ADMM_exactpenalty(A,b,k)
% min_x ||Ax-b||_1, s.t. ||x||_0 <= k
% min_{x,y} ||y||_1, s.t. Ax-b = y, ||x||_0 <= k
% min_{x,y} ||y||_1 + rho ||Ax-b-y||_2 + rho ||Ax-b-y||_2^2, s.t.  ||x||_0 <= k
L = norm(A)^2;
[m,n]=size(A);
x = randn(n,1);
y = randn(m,1);

HandleObj = @(x)norm(A*proj_l0(x,k)-b,1);
rho = 1;
addpath('G:\cvx');
HandleObj_xy = @(x,y) norm(y,1) + rho*norm(A*x-b-y) + rho*norm(A*x-b-y)^2;

for iter = 1:1000
    % update y
    % min_{y} ||y||_1 + rho ||Ax-b-y||_2 + rho ||Ax-b-y||_2^2, s.t.  ||x||_0 <= k
    e = A*x-b;
    % min_{y} ||y||_1 + rho ||e-y||_2 + rho ||e-y||_2^2
    
    cvx_begin quiet
    variable y(m)
    minimize( norm(y,1) + rho * norm(e-y,2) + rho * (e-y)'*(e-y) )
    cvx_end
    
    % update x
    c = b+y;
    % min_{x} 0.5||Ax-c||_2 + 0.5||Ax-c||_2^2 , s.t.  ||x||_0 <= k
    % z = arg min_x <x-xt,grad_xt> + 0.5 (x-xt)'H_xt(x-xt)
    diff = A*x-c;
    % grad = A'*diff;
    % hess = A'*A;
    % grad = 0.5*A'*(diff) / norm(diff) + A'*diff;
    % hess = 0.5*A'*A/norm(diff) - 0.5 * A'*A*x*x'*A'*A/norm(diff)^3 + A'*A;
    %
    % hess = (hess + hess')/2;
    
    cvx_begin quiet
    variable x(n,1)
    minimize( 0.5*norm(A*x-c) + 0.5*(A*x-c)'*(A*x-c) )
    cvx_end
    
    % z = arg min_x <x,grad_xt> + 0.5 x'H_xt x  - <x, H_xt xt>
    % z = arg min_x <x,grad_xt-H_xt xt> + 0.5 x'H_xt x
    
    % x = BlockDecAlgQuadratic_c(x,hess,grad-hess*x,k,[10;2]);
    
    diff = A*x - b - y;
    fff = HandleObj(x);
    fff2 = HandleObj_xy(x,y);
    fprintf('iter:%d, dist:%f, fobj:%f, fobj2:%f\n',iter,norm(diff),fff,fff2);
    his(iter) = fff;
    
end
dddd
