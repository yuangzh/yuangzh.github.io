function flag = checkdec(a)
last=inf;flag=1;
for i=1:length(a),
    if(a(i)>last && abs(a(i)-last)>1e-6 && abs(a(i)-last)>0.1 )
        fprintf('diff: %e\n',a(i)-last);
        flag=0;
error('NonDec');
        return;
    end
    last=a(i);
end