function demo_acc_OneNN
% min_x || max(Gx,0) - |y| ||_2^2 + 0.5 lambda x'x
clc;clear all;close all;
rand('seed',0); randn('seed',0);
addpath('util');


id_data = [11 12 13 14 21 22 23 24 31 32 33 34 41 42 43 44];



times = 10;


result = [];
for idat = 1:length(id_data)
    
    avg_his1 = [];
    avg_his2 = [];
    avg_his3 = [];
    avg_his4 = [];
    avg_his5 = [];
    for it = 1:times
        
        % Main Algorithms
        G = getdata_pca(id_data(idat));
        y = generate_y_OneNN(G);
        x0 = randn(size(G,2),1);
        lambda = 0;
        MaxTime = 100;

       [x1,his1,ts1] = MSCR(x0,G,y,lambda,MaxTime);
       [x2,his2,ts2] = LinearizedMSCR(x0,G,y,lambda,MaxTime);
       [x3,his3,ts3] = SubGradient(x0,G,y,lambda,MaxTime);
       [x4,his4,ts4] = CD_SCA(x0,G,y,lambda,MaxTime);
       [x5,his5,ts5] = CD_SNCA(x0,G,y,lambda,MaxTime);
        
        % Scale the objectives if they are negative
%         CCC = min([his1(:);his2(:);his3(:);his4(:);his5(:)])+eps; CCC = min(0,CCC);his1=his1+CCC; his2=his2+CCC; his3=his3+CCC; his4=his4+CCC; his5=his5+CCC;
        
        avg_his1(it) = min(his1); avg_his2(it) = min(his2); avg_his3(it) = min(his3); avg_his4(it) = min(his4); avg_his5(it) = min(his5);
    end
    
    
    One = [];
    One.his1 = [mean(avg_his1);std(avg_his1)];
    One.his2 = [mean(avg_his2);std(avg_his2)];
    One.his3 = [mean(avg_his3);std(avg_his3)];
    One.his4 = [mean(avg_his4);std(avg_his4)];
    One.his5 = [mean(avg_his5);std(avg_his5)];
    result{idat} = One; save(mfilename,'result')
    
    
    % Print
%     fprintf('result:\n');
%     fprintf('Alg 1: %f %f\n',mean(avg_his1),std(avg_his1));
%     fprintf('Alg 2: %f %f\n',mean(avg_his2),std(avg_his2));
%     fprintf('Alg 3: %f %f\n',mean(avg_his3),std(avg_his3));
%     fprintf('Alg 4: %f %f\n',mean(avg_his4),std(avg_his4));
%     fprintf('Alg 5: %f %f\n',mean(avg_his5),std(avg_his5));
    

    fprintf('%s & ',GetDataStr(idat));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his1),std(avg_his1));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his2),std(avg_his2));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his3),std(avg_his3));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his4),std(avg_his4));
    fprintf('%.3f $\\pm$ %.3f  ',mean(avg_his5),std(avg_his5));
    fprintf('\\\\');
    fprintf('\n');
     
end


function [x,his,ts] = LinearizedMSCR(x,G,y,lambda,MaxTime)
% min_x 0.5||max(Gx,0) - |y| ||_2^2 + 0.5 lambda x'x
% min_x 0.5||max(Gx,0)||_2^2  + 0.5 y'y + 0.5 lambda x'x - <max(Gx,0),|y|>
initt = clock;

A = diag(y)*G;
% L = norm(G)^2 + lambda;
L = SpectralNorm(G) + lambda;
HandleObj = @(x)computeTrueObj(x,G,y,lambda);

his = []; ts =[];
fobj = HandleObj(x);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;

for iter = 1:10000
    
    Ax = A*x;
    Index = find(Ax>0);
    eeee = ones(length(Index),1);
    subgrad_g = A(Index,:)'*eeee;
    
    % min_x 0.5||max(Gx,0)||_2^2  + 0.5 y'y + 0.5 lambda x'x - <x,subgrad_g>
    
    grad = G'*max(G*x,0) + lambda*x - subgrad_g;
    x = x - grad/L;
    
    
    fobj = HandleObj(x);
    
    %     fprintf('iter:%d, fobj:%f, normG:%f\n',iter,fobj, norm(grad));
    
    
    his(iter) = fobj;
    ts(iter) = etime(clock,initt);
    
    
    
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end

function [x,his,ts] = MSCR(x,G,y,lambda,MaxTime)
% min_x 0.5||max(Gx,0) - |y| ||_2^2 + 0.5 lambda x'x
% min_x 0.5||max(Gx,0)||_2^2  + 0.5 y'y + 0.5 lambda x'x - <max(Gx,0),|y|>
initt = clock;

A = diag(y)*G;
L = SpectralNorm(G) + lambda;
HandleObj = @(x)computeTrueObj(x,G,y,lambda);


his = []; ts =[];
fobj = HandleObj(x);
his = [his;fobj];
ts = [ts;etime(clock,initt)];



last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;


for iter = 1:10000
    
    Ax = A*x;
    Index = find(Ax>0);
    eeee = ones(length(Index),1);
    subgrad_g = A(Index,:)'*eeee;
    
    % min_x 0.5||max(Gx,0)||_2^2  + 0.5 y'y + 0.5 lambda x'x - <x,subgrad_g>
    for it = 1:10
        grad = G'*max(G*x,0) + lambda*x - subgrad_g;
        x = x - grad/L;
    end
    
    fobj = HandleObj(x);
    %     fprintf('iter:%d, fobj:%f, normG:%f\n',iter,fobj, norm(grad));
    his(iter) = fobj;
    ts(iter) = etime(clock,initt);
    
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
    
end

function [x,his,ts] = SubGradient(x,G,y,lambda,MaxTime)
% min_x 0.5||max(Gx,0) - |y| ||_2^2 + 0.5 lambda x'x
HandleObj = @(x)ComputeObjSubGrad(x,G,y,lambda);
initt = clock;

his = []; ts =[];
fobj = HandleObj(x);
his = [his;fobj];
ts = [ts;etime(clock,initt)];


last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;


for iter = 1:10000
    [fobj,grad] = HandleObj(x);
    step = 1/sqrt(iter);
    x = x - step*grad;
    his(iter) = fobj;
    ts(iter) = etime(clock,initt);
    %     fprintf('iter:%d, fobj:%f\n',iter,fobj);
    
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end

function [f,g] = ComputeObjSubGrad(x,G,y,lambda)
Gx = G*x;
Gx1 = max(0,Gx);
f = 0.5*norm(Gx1 - abs(y) )^2 + 0.5 * lambda*x'*x;
g =  G'*(Gx1 - abs(y)) + lambda*x;


function [x,his,ts] = CD_SNCA(x,G,y,lambda,MaxTime)
% min_x 0.5||max(Gx,0) - |y| ||_2^2
% min_x 0.5||max(Gx,0)||_2^2 - <max(Gx,0), |y|> + 0.5y'y
% min_x 0.5||max(Gx,0)||_2^2 - <max(Gx,0), |y|> + 0.5y'y
% min_x 0.5||max(Gx,0)||_2^2 - <max(diag(y)Gx,0), 1> + 0.5y'y
% min_x 0.5||max(Gx,0)||_2^2 - ||max(Ax,0)||_1 + 0.5y'y
initt = clock;


[m,n] = size(G);
HandleObj = @(x)computeTrueObj(x,G,y,lambda);

A = diag(y)*G;


% c = diag(G'*G)+lambda;
c = sum(G.*G,1)' + lambda + 1e-10;
absy = abs(y);

Gx = G*x;
Ax = A*x;
Gxplus = max(0,Gx);

his = []; ts =[];
fobj = HandleObj(x);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-14;
changes = ones(last_k,1)*inf;
fobj_old = fobj;

for iter =1:10000
    
    
    i = mod(iter,n)+1;
    %   i = randperm(n,1);
    %   ei = zeros(n,1);
    %   ei(i) = 1;
    
    
    % 0.5 c t^2 + grad_f_i t - ||max(A(x+tei),0)||_1
    % 0.5 t^2 + grad_f_i/c t - 1/c ||max(A(x+tei),0)||_1
    %     grad_f = G'*max(Gx,0) + lambda*x;
    %     grad_f_i = grad_f(i);
    grad_f_i = Gxplus'*G(:,i) + lambda*x(i);
    
    cof_a = A(:,i);
    cof_b = Ax;
    cof_beta = -grad_f_i/c(i);
    
    t = nonconvex_prox_relu(cof_beta,1/c(i),cof_a,cof_b,m);
    
    x(i) = x(i) + t;
    
    % reconstrct Ax and Gx in linear time
    Ax = Ax + t*A(:,i);
    Gx = Gx + t*G(:,i);
    Gxplus = max(Gx,0);
    
    fobj = 0.5*norm(Gxplus-absy)^2 + 0.5*lambda*x'*x;
    
    
%         Index = find(Ax>0);
%         eeee = ones(length(Index),1);
%         subgrad_g = A(Index,:)'*eeee;
%         grad =  G'*max(G*x,0) + lambda * x - subgrad_g;
    
    
    %     [~,i] = max(abs(grad));
%        fprintf('iter:%d, fobj:%f, normG:%f\n',iter,fobj, norm(grad));
%       fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his(iter) = fobj;
    ts(iter) = etime(clock,initt);
    
    if etime(clock,initt) > MaxTime,
        break;
    end

    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
 
end


% plot(his)
% ddd
function [x,his,ts] = CD_SCA(x,G,y,lambda,MaxTime)
% min_x 0.5||max(Gx,0) - |y| ||_2^2
% min_x 0.5||max(Gx,0)||_2^2 - <max(Gx,0), |y|> + 0.5y'y
% min_x 0.5||max(Gx,0)||_2^2 - <max(Gx,0), |y|> + 0.5y'y
% min_x 0.5||max(Gx,0)||_2^2 - <max(diag(y)Gx,0), 1> + 0.5y'y
% min_x 0.5||max(Gx,0)||_2^2 - ||max(Ax,0)||_1 + 0.5y'y
initt = clock;
his = [];
[m,n] = size(G);
HandleObj = @(x)computeTrueObj(x,G,y,lambda);

absy = abs(y);
A = diag(absy)*G;
% c = diag(G'*G) + lambda;
c = sum(G.*G,1)' + lambda + 1e-10;

 

Gx = G*x;
Ax = A*x;
Gxplus = max(0,Gx);

his = []; ts =[];
fobj = HandleObj(x);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;

for iter =1:10000
    
    %     subgrad_g = A'*max(A*x,0);
    i = mod(iter,n)+1;
    
    % min_alpha 0.5 c(i) alpha^2 + alpha (grad_f (i) - subgrad_g(i))
    % min_alpha 0.5 alpha^2 + alpha [grad_f(i)-subgrad_g(i)] / c(i)
    
    %     Index = find(Ax>0);subgrad_g_i = sum(A(Index,i));
    subgrad_g_i = sum(A(Ax>0,i));
    grad_f_i = Gxplus'*G(:,i)  + lambda*x(i);
    t = - (grad_f_i - subgrad_g_i) / c(i);
    x(i) = x(i) + t;
    
    Ax = Ax + t*A(:,i);
    Gx = Gx + t*G(:,i);
    Gxplus = max(Gx,0);
    
    %     fobj = HandleObj(x);
    fobj = 0.5*norm(Gxplus-absy)^2 + 0.5*lambda*x'*x;
    %     grad = grad_f  - subgrad_g;
    %     normG = norm(grad);
    
    %     [~,i] = max(abs(grad));
    
    %     fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his(iter) = fobj;
    ts(iter) = etime(clock,initt);
    
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end
%     plot(his)
%     iter:5000, fobj:43.667415
function f = computeTrueObj(x,G,y,lambda)
Gx = G*x;
Gx1 = max(0,Gx);
f = 0.5*norm(Gx1 - abs(y) )^2 + 0.5*lambda*x'*x;

