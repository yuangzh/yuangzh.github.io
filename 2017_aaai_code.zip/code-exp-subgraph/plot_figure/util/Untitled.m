clear all; close all;
figure;
p1 = plot([1:10], [1:10], '+-');
hold on;
p2 = plot([1:10], [1:10]+2, 'o--');

% legend('text1', 'text2');

% 
% set(p1, 'visible', 'off');
% set(p2, 'visible', 'off');
% set(gca, 'visible', 'off');

plot(0,0,'k',0,0,'.r') %make dummy plot with the right linestyle
axis([10,11,10,11]) %move dummy points out of view
legend('black line','red dot')
axis off %hide axis

