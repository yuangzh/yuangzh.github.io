clc;clear all;close all;
addpath('util','solver');
randn('seed',0); rand('seed',0);
% 0.5 || AX-B||_F^2 + lambda ||X||_0

n = 200; d = 1000;
A1 = rand(n,d);
B1 = rand(n,1);
lambda = 1; 
% lambda = 2; 
X0 = randn(d,1); max_iter = 200;
const = 0.5 * norm(B1,'fro')^2;

HandleObjSmooth    = @(X)computeObj(X,A1,B1);
HandleObjNonSmooth = @(X)lambda*nnz(X(:));
HandleProx = @(theta,a)computeprox(theta,a,lambda);
[X1, his1]= ProximalGradient_Constant_Stepsize(X0,HandleObjSmooth,HandleObjNonSmooth,HandleProx,max_iter,norm(A1'*A1));
[X2, his2]= ProximalGradientLinearSearch(X0,HandleObjSmooth,HandleObjNonSmooth,HandleProx,max_iter,norm(A1'*A1));
[X3, his3]= AccerlatedProximalGradient_Constant_Stepsize(X0,HandleObjSmooth,HandleObjNonSmooth,HandleProx,max_iter,norm(A1'*A1));
[X4, his4]= AccerlatedProximalGradient(X0,HandleObjSmooth,HandleObjNonSmooth,HandleProx,max_iter);
[X5, his5] = MSM(A1'*A1,-A1'*B1,lambda,const,X0,max_iter,0.7);

figure;
semilogy([1:length(his1)],his1,[1:length(his2)],his2,[1:length(his3)],his3,[1:length(his4)],his4,[1:length(his5)],his5,'LineWidth',2);
legend('Classical PPA (constant stepsize)',...
    'Classical PPA (line search)',...
    'Accerlated PPA (constant stepsize)',...
    'Accerlated PPA (line search)',...
    'Proposed Matrix Splitting Method')
axis([1 max_iter 0 20000])

fprintf('Method1: %f\n',min(his1));
fprintf('Method2: %f\n',min(his2));
fprintf('Method3: %f\n',min(his3));
fprintf('Method4: %f\n',min(his4));
fprintf('Method5: %f\n',min(his5));


print(sprintf('%s.eps',mfilename), '-dpsc');
print( sprintf('%s.png',mfilename),'-dpng');


