function [x,his] = block_K_ADMM(A,b,k)
% min_x ||Ax-b||_1, s.t. ||x||_0 <= k
% min_{x,y} ||y||_1, s.t. Ax-b = y, ||x||_0 <= k
% L(x,y;pi) ||y||_1 + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k

L = norm(A)^2;
[m,n]=size(A);
x = randn(n,1)*0.01;
y = randn(m,1)*0.01;
pi = randn(m,1)*0.01;
beta = 0.1;
HandleObj = @(x)norm(A*proj_l0(x,k)-b,1);

HandleObj1 = @(x,y,pi,beta) norm(y,1) + (A*x-b-y)'*pi + 0.5*beta*norm(A*x-b-y)^2;



for iter = 1:1000,
    % update x
    % L(x,y;pi) = ||y||_1 + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
    % min_x  <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
    % min_x 0.5 beta ||Ax-b-y + pi/beta||_2^2, s.t. ||x||_0 <= k
    % min_x 0.5 ||Ax-b-y + pi/beta||_2^2, s.t. ||x||_0 <= k
    c = b + y - pi/beta;
    % min_x 0.5 ||Ax-c||_2^2, s.t. ||x||_0 <= k
    % grad = A'*(A*x-c);
    % x = x - grad / L;
    % x = proj_l0(x,k);
    
    [x] = BlockDecAlg_c(x+1e-12,A,c,k,[12;2],0,20);
    % iter:326, dist:0.074740, fobj:17017.875459
    % update y
    % L(x,y;pi) ||y||_1 + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2 , s.t. ||x||_0 <= k
    % L(x,y;pi) ||y||_1 + 0.5 beta ||Ax-b-y + pi/beta||_2^2, s.t. ||x||_0 <= k
    % L(x,y;pi) ||y||_1 + 0.5 beta ||Ax-b+pi/beta -y||_2^2, s.t. ||x||_0 <= k
    % L(x,y;pi) 1/beta||y||_1 + 0.5 ||Ax-b+pi/beta -y||_2^2, s.t. ||x||_0 <= k
    a = A*x - b + pi/beta;
    y = prox_l1(a,1/beta);
    
    diff = A*x - b - y;
    pi = pi + beta * diff;
    
    fprintf('iter:%d, dist:%f, fobj:%f\n',iter,norm(diff),HandleObj(x));
    his(iter) = HandleObj(x);
    
    % HandleObj1(x,y,pi,beta)-HandleObj1(x,y,pi,beta/1.1)
    
    % beta/1.1 - beta
    if (~mod(iter,50))
        beta = beta*2;
    end
    
    
end
