function test
clc;clear all;close all;
while 1
    n = 10;
A = randn(n);
b = randn(n,1);
mu =  0.001;
x1 = randn(n,1); x2 = randn(n,1);
sigma = min(eig(A'*A));


[f1,g1] = ComputeObj(x1,A,b,mu);
[f2,g2] = ComputeObj(x2,A,b,mu);
f2 - f1 - (x2-x1)'*g1 - 0.5*norm(x1-x2)^2*sigma/mu

end

function [fobj,grad] = ComputeObj(x,A,b,mu)
% lambda ||y||_1 + 0.5 / mu ||Ax-b-y||_2^2
lambda = 1.567;
y = prox_l1(A*x-b,lambda*mu);
fobj = lambda * norm(y,1) + 0.5/mu * norm(A*x-b-y)^2;
grad = 1/mu*A'*(A*x-b-y);

