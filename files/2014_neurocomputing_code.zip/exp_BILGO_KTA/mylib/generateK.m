function K=generateK(x,y,k_n_n)
[n]=length(y);
K_dist=zeros(n,n);
for i=1:n,
for j=1:n,
    K_dist(i,j)=norm(x(i,:)-x(j,:));
end;
end;

K=zeros(n,n);
 for i=1:n,
     [B,IX] =sort(K_dist(i,:));
     
     k=0;
     for j=1:n,
     ind=IX(j);
     if(y(i)==y(ind)),K(i,ind)=1;k=k+1;if(k==k_n_n),break;end;end;
     end;
     
     k=0;
     for j=n:-1:1,
     ind=IX(j);
     if(y(i)~=y(ind)),K(i,ind)=-1;k=k+1;if(k==k_n_n),break;end;end;
     end;     
 end;
 K=(K+K')/2.0;
