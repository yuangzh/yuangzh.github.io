clc;clear all;close all;
addpath('util');

load('result_demo_box.mat');   box = result;
load('result_demo_feige.mat'); feige = result;
load('result_demo_ravi.mat');  ravi = result;
load('result_demo_tpm.mat');   tpm = result;
load('result_demo_mpec_epm.mat');   epm = result;
load('result_demo_mpec_adm.mat');   adm = result;
load('result_demo_l2box_admm.mat');   diadm = result;


for ii=1:8,
    box_time = [];
    diadm_time = [];
    epm_time = [];
    adm_time = [];
    for jj=1:7,
        box_time= [box_time;box{ii,jj}.cpu];
        diadm_time= [diadm_time;diadm{ii,jj}.cpu];
        epm_time= [epm_time;epm{ii,jj}.cpu];
        adm_time= [adm_time;adm{ii,jj}.cpu];
    end
    
    fprintf('%f %f %f %f\n',mean(box_time),mean(diadm_time),mean(epm_time),mean(adm_time));
    
end