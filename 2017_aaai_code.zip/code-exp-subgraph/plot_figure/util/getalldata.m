function [y] = getalldata(yData)

y = [];
for i=1:length(yData),
    o = yData{i};
    y = [y;o(:)];
end
y = y(:);
