#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <mex.h>
#include <math.h>
#include "matrix.h"

#define  abs1(a)         ((a) < 0.0 ? -(a) : (a))
#define  sign1(a)        ((a)==0) ? 0 : (((a)>0.0)?1:(-1))
#define  max1(a,b)       ((a) > (b) ? (a) : (b))
#define  min1(a,b)       ((a) < (b) ? (a) : (b))


/* 
 *
 * The program solves the following nonlinear 
 * system using a Gaussian elimination method
 *       Qx + p + subgrad h(x) = 0
 * where Q is a triangle matrix
 *
 */


/*
 double linf_one_dime(double a, double b,double lambda)
 {
  0.5 a x'x + b'x, s.t. x>=0 
	return min1(10000,max1(0,-b/a));
  	return max1(0,-b/a);
 }
 */


void solve(double *x, const double*Q, const double*p,double lambda,int n, int d)
{
    int i,j,k,i1,i2,i3,i4; double subsum;
    for (k=1;k<=d;k++)
    {
        for (i=1;i<=n;i++)
        {
            for (subsum=0,j=1;j<=(i-1);j++)
            {
                i1 = n*(j-1)+i-1; i2 = n*(k-1)+j-1;
                subsum = subsum + Q[i1]*x[i2];
            }
            i3 = n*(k-1)+i-1; i4 = n*(i-1)+i-1;
/*            x[i3] = linf_one_dime (Q[i4],subsum + p[i3],lambda);*/
            x[i3] = max1(0,-(subsum + p[i3])/Q[i4]);
        }
    }
}


void mexFunction (int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
    /*set up input arguments */
    double* Q=            mxGetPr(prhs[0]);
    double* p=            mxGetPr(prhs[1]);
    double lambda =      mxGetScalar(prhs[2]);
    int n =         mxGetScalar(prhs[3]);
    int d =         mxGetScalar(prhs[4]);
    double *out_x;
    
    plhs[0] = mxCreateDoubleMatrix(n,d,mxREAL);
    out_x = mxGetPr(plhs[0]);
    solve(out_x, Q, p, lambda,n,d);
}

