function [x1,y1,x2,y2] = findcoo(A)
[m,n] = size(A);
flag  =0;
for i=1:1:m,
    for j=1:1:n,
        if(A(i,j)~=255)
            x1 = i;
            y1 = j;
            flag  =1;
            break;
        end
    end
if(flag==1),break;end
end

flag = 0;
for i=m:-1:1,
    for j=n:-1:1,
        if(A(i,j)~=255)
            x2 = i;
            y2 = j;
            flag  =1;
            break;
        end
    end
if(flag==1),break;end
end

