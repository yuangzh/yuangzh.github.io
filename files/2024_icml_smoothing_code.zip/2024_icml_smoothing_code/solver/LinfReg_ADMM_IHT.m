function [x,his] = LinfReg_ADMM_IHT(A,b,lambda,k,x0)
% min_x 0.5*lambda*x'*x +  ||Ax-b||_inf, s.t. ||x||_0 <= k 
% min_{x,y} 0.5*lambda*x'*x + ||y||_inf, s.t. Ax-b = y, ||x||_0 <= k 
% L(x,y;pi) 0.5*lambda*x'*x + ||y||_inf + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
HandleObj = @(x)norm(A*proj_l0(x,k)-b,inf);

A2 = ComputeLagEigFromA(A);


[m,n]=size(A);
x = x0;
y = A*x-b;y = randn(m,1);
pi = randn(m,1)*0.0;
beta = 1;
for iter = 1:1000,
% update x
% L(x,y;pi) = 0.5*lambda*x'*x + ||y||_1 + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
% min_x  <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
% min_x 0.5 beta ||Ax-b-y + pi/beta||_2^2, s.t. ||x||_0 <= k
% min_x 0.5 ||Ax-b-y + pi/beta||_2^2, s.t. ||x||_0 <= k
L = lambda + beta * A2;
c = b + y - pi/beta;
% min_x 0.5 ||Ax-c||_2^2, s.t. ||x||_0 <= k
grad = lambda*x + beta * A'*(A*x-c);
x = proj_l0(x - grad / L,k);


% update y
% L(x,y;pi) ||y||_1 + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
% L(x,y;pi) ||y||_1 + 0.5 beta ||Ax-b-y + pi/beta||_2^2, s.t. ||x||_0 <= k
% L(x,y;pi) ||y||_1 + 0.5 beta ||Ax-b+pi/beta -y||_2^2, s.t. ||x||_0 <= k
% L(x,y;pi) 1/beta||y||_1 + 0.5 ||Ax-b+pi/beta -y||_2^2, s.t. ||x||_0 <= k
a = A*x - b + pi/beta;
y = prox_linf(a,1/beta);


diff = A*x - b - y;
pi = pi + beta * diff;

% fprintf('iter:%d, dist:%f, fobj:%f\n',iter,norm(diff),HandleObj(x));
his(iter) = HandleObj(x);
if(~mod(iter,150))
    beta = beta * 2;
end

end
