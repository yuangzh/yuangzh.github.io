function best_t = nonconvex_prox_linfl2(beta,lambda,x,i,lb,ub)
% min_t 0.5 t^2 - beta t - lambda || x+tei ||_2
% s.t. lb <= t <= ub

n = length(x);
ei = zeros(n,1);
ei(i) = 1;
tt = nonconvex_prox_l2(beta,lambda,ei,x);
tt = max(lb,min(tt,ub));
ts = [lb;ub;tt];
HandleObj = @(t)ComputeObj(t,beta,lambda,x,i,lb,ub);

for i=1:length(ts)
    fs(i) = HandleObj(ts(i));
end
[~,ind] = min(fs);
best_t = ts(ind);





function [f] = ComputeObj(t,beta,lambda,x,i,lb,ub)
% min_t 0.5 t^2 - beta t - lambda || x+tei ||_2
% s.t. lb <= t <= ub
t = max(lb,min(t,ub));
x1 = x;
x1(i) = x1(i) + t;
f = 0.5*t^2 - beta*t - lambda*norm(x1);




function [ts1] = nonconvex_prox_l2(beta,lambda,a,b)
% 0.5 t^2 - beta t - lambda || t a + b||_2
% 0.5 (t-beta)^2 - lambda || t a + b||_2
% grad = t-beta - lambda * <a, (t*a+b) / norm(t*a+b)>
% letting grad = 0, we have:
% lambda* <a,t*a+b> = (t-beta) norm(t*a+b)
aa = a'*a;
ab = a'*b;
bb = b'*b;
c = lambda*aa;
d = lambda*ab;
% lambda* <a,t*a+b> = (t-beta) norm(t*a+b)
% c t + d = (t-beta) norm(t*a+b)
% c*c*t*t + d*d + 2*c*d*t = (t-beta)^2 norm(t*a+b)^2
% c*c*t*t + d*d + 2*c*d*t = (t*t + beta*beta - 2*beta*t) ( a'*a*t*t + b'*b + 2*a'*b*t )  
% c*c*t*t + d*d + 2*c*d*t =   t*t*a'*a*t*t + t*t*b'*b + 2*t*t*a'*b*t
%                           + beta*beta*a'*a*t*t  + beta*beta*b'*b  +  beta*beta*2*a'*b*t
%                           - 2*beta*t* a'*a*t*t  - 2*beta*t*b'*b   -  2*beta*t* 2*a'*b*t

cof_4 = aa;
cof_3 = 2*ab - 2*beta* aa;
cof_2 = bb + beta*beta*aa -  2*beta*2*ab -c*c;
cof_1 = beta*beta*2*ab - 2*beta*bb - 2*c*d;
cof_0 = beta*beta*bb - d*d;
ts = roots([cof_4;cof_3;cof_2;cof_1;cof_0]);
% ts = real(ts);
% ts1 = [];
% for i=1:length(ts)
%     if(isreal(ts(i)))
%         ts1 = [ts1;ts(i)];
%     end
% end

ts1 = ts(~imag(ts));

