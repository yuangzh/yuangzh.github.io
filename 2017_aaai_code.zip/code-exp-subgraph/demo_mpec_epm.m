clc;clear all;clear all;randn('seed',0); rand('seed',0);warning off;
addpath('util','solver','PROPACK',genpath('bvgraph'));

read_dataset_and_k;
result= [];

for i=1:length(datasets),
    
    namedata = datasets{i};
    fprintf('data: %s, #:%d\n',namedata,i);
    W = sparse(bvgraph(sprintf('data\\%s',namedata)));

    for j=1:length(ks),
        
        randn('seed',0); rand('seed',0); k = ks(j);
        
        t1=clock;[x,obj,his] = dsf_mpec_epm(W,k);t2 = clock; cpu = etime(t2,t1);
        fprintf('method:%s. k: %d, cpu: %f, fobj: %f\n',mfilename,k,cpu,obj);
        
        one=[];  one.cpu = cpu; one.obj = obj; one.his = his; result{i,j} =  one;
        save(sprintf('result_%s',mfilename),'result')
        
    end
    
end



