function [f] = mnorm(x)
f = max(max(abs(x)));
