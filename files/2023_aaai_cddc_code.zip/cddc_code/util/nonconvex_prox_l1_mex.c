#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <mex.h>
#include <math.h>
#include "matrix.h"

#define  abs1(a)         ((a) < 0.0 ? -(a) : (a))
#define  sign1(a)        ((a)==0) ? 0 : (((a)>0.0)?1:(-1))
#define  max1(a,b)       ((a) > (b) ? (a) : (b))
#define  min1(a,b)       ((a) < (b) ? (a) : (b))

void sort(double *a,int n)
{
    int i,j;
    double m;
    for(i=0;i<n-1;i++)
    for(j=i+1;j<n;j++)
        if (a[i]>a[j])
        {
            m=a[i];a[i]=a[j];a[j]=m;
        }
}


void CreatHeap(double a[], int i, int  n) 
{
    for (; i >= 0; --i)
    {
        int left = i * 2 + 1; int right = i * 2 + 2; int j = 0;
        if (right < n) 
        {
            if(a[left] > a[right])
                j = left;
            else
                j = right;
        }
        else
            j = left;
        if (a[j] > a[i]) 
        {
            double tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
        }
    }
}

void HeapSort(double a[], int n) 
{
    CreatHeap(a, n/2-1, n);
    for (int j = n-1; j >= 0; j--) 
    {
        
        double tmp = a[0];
        a[0] = a[j];
        a[j] = tmp;

        int i = j / 2 - 1;
        CreatHeap(a, i, j);
    }
}






void swap(double *x, double *y) {
    double tmp = *x;
    *x = *y;
    *y = tmp;
}


int patition(double *a, int left,int right) {
    int j = left;   
    int i = j - 1;    
    double key = a[right];    

    for (; j < right; ++j) {
        if (a[j] <= key)
            swap(&a[j], &a[++i]);
    }

    swap(&a[right], &a[++i]);

    return i;
}

void quickSort(double *a,int left,int right) {
    if (left>=right)
        return;
    int mid = patition(a,left,right);
    quickSort(a, left, mid - 1);
    quickSort(a, mid + 1, right);
}


void solve(double *x_out,double beta,double lambda, const double*a, const double*b, int m)
{
double minval = 1e100;
double opt_t = 100000000;
int i;
int j;
double temp = 0;
int lenc = 0;
int lenc_nz = 0;
double *c = (double *)malloc(sizeof(double)*(2*m+2));
double *c_temp = (double *)malloc(sizeof(double)*(m));

for(i=0;i<m;i++)
{
    //   printf("%f \n",a[i]);
  if(a[i] >1e-10 || a[i]<-1e-10)
//  if(a[i]!=0)
 {
      double aaaa = b[i]/a[i];
     // printf("aaaa %f \n",aaaa);
      if(aaaa>0)
    c_temp[lenc_nz++] = aaaa;
      else
    c_temp[lenc_nz++] = -aaaa;
  }

}

//printf("dddddd: %d\n",lenc_nz);
if(lenc_nz==0)
{
    opt_t = beta;
}
      
else
{

//sort(c_temp,lenc_nz);
HeapSort(c_temp,lenc_nz); 
//quickSort(c_temp,0,lenc_nz-1);

c[lenc] = -1e10; lenc ++;

for(i=0;i<lenc_nz;i++)
{
c[lenc++] = -c_temp[lenc_nz-i-1];
}

for(i=0;i<lenc_nz;i++)
{
c[lenc++] = c_temp[i];
}

c[lenc] = 1e10; lenc ++;

//for(i=0;i<lenc;i++)
//printf("%f ",c[i]);


for(i=1;i<=(lenc-1);i++)
{
    double tt = 0.5*(c[i-1]+c[i]);
    double t = 0;
    temp=0;
    for (j=0;j<m;j++) 
    {
        if(tt*a[j] + b[j]>=0)
        temp = temp + a[j];
        else
        temp = temp - a[j];
            
    }
    t = temp*lambda + beta;
    
    temp=0;
    double ft=0;
    for (j=0;j<m;j++) 
    {
        double hhh = t*a[j] + b[j];
        if(hhh>=0)
        temp = temp + hhh;
        else
        temp = temp - hhh;
    }
    
    ft = 0.5*(t-beta)*(t-beta) -lambda*temp ; 
    if(ft<minval)
    {
        minval = ft;
        opt_t = t;
    }
}
}
x_out[0] = opt_t;


free(c);
free(c_temp);
}


void mexFunction (int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
    /*set up input arguments */
    double beta   = mxGetScalar(prhs[0]);
    double lambda = mxGetScalar(prhs[1]);
    double *a     = mxGetPr(prhs[2]);
    double *b     = mxGetPr(prhs[3]);
    int m         = mxGetScalar(prhs[4]);

    double *out_x;
    plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
    out_x = mxGetPr(plhs[0]);
    solve(out_x,beta, lambda, a, b, m);
}

