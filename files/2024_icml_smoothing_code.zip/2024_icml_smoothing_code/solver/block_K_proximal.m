function [x,his] = block_K_proximal(C,f,k)
% min_{x} ||Cx-f||_1, s.t. ||x||_0 <= k 
[A,b,w] = GetAbw(C,f);
HandleObjMeasureOpt = @(x) norm(C*x-f,1);
% function [x] = solve_by_proximal(A,b,w,HandleObjMeasureOpt,optimal)
% min_x <x,w>, s.t. Ax<=b
[m,n]=size(A);
x = randn(n,1);
n1 = n-m/2;
x(1:n1) = randn(n1,1);
x(n1+1:end) = 100;
theta = 1e-8;
for iter = 1:120
    xt = x;
    % min_x f(x) + theta [ -<1, log(b-Ax)>  - <x, sum_i  Ai / (b-Axt)_i > ]
    o =A'*(1./b-A*xt);
    % min_x f(x) + theta [-<1,log(b-Ax)> - <x,o> ]
    HandleObj = @(x)ComputeObj(x,w,theta,A,b,o);
    L = 100;
    [fobj,grad,hess] = HandleObj(x);
    
    [next_point] = BlockDecAlgQuadratic_c(x+eps,hess,grad-hess*x,k,[4;4]);
    dir = next_point - x;
norm(max(0,A*next_point-b))
ddd
    for isearch = 1:100
        x1 = proj_l0(x-dir/L,k);
        if(norm(max(0,A*x1-b))==0)
            break;
        end
        L = L*2;
    end

    x = x1;
    dddd = HandleObjMeasureOpt(x(1:n1));
    fprintf('iter:%d, fobj:%e. vio:%.1f, currobj:%f\n',iter,x'*w,norm(max(0,A*x-b)),dddd);
end
