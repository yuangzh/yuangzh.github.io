function [fobj,proj_grad_norm] = computeOptimality(X,A,B)
% 0.5 ||X-AB||_F^2, A>=0, B>=0
% grad_A = (AB-X)B'
% grad_B = A'(AB-X)

% X: m x n
% A: m x r
% B: r x n
A = max(A,0); B = max(B,0);
XBt = X*B'; AtA = A'*A; BBt = B*B'; AtX = A'*X;
fobj = 0.5 * norm(X,'fro')^2 - mdot(A,XBt) + 0.5 * mdot(AtA,BBt);
% fobj = 0.5 * norm(X-A*B,'fro')^2;
gradA = A*BBt-XBt;
gradB = AtA*B - AtX;
proj_grad_norm = norm([gradA(gradA<0|A>0);gradB(gradB<0|B>0)],'fro');


function [r] = mdot(A,B)
r = sum(sum(A.*B));


