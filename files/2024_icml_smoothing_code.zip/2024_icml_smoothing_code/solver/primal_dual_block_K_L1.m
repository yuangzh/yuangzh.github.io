% iter:99, dist:0.014049, fobj:1286.186421
% iter:100, dist:0.012772, fobj:1286.185518
function [x,his] = primal_dual_block_K(A,b,k)
% min_x ||Ax-b||_1, s.t. ||x||_0 <= k
% max_y min_x <y,Ax-b>, s.t. -1<=y<=1, ||x||_0 <= k
% max_y min_x <y,Ax-b> - 0.5 theta ||y-y^t||^2 + 0.5 beta ||x-xt||_^2, s.t. -1<=y<=1, ||x||_0 <= k

[m,n]=size(A);
x = randn(n,1)*0.0;
y = randn(m,1)*0.0;
%
HandleObj = @(x)norm(A*proj_l0(x,k)-b,1);
beta = 1;

tau = 1;

sigma = 0.010;

for iter =1:100000,
    % y_old = y;
    % y = arg may_y tau <Ax-b,y> - 0.5 ||y-y_old||_2^2, s.t. -1 <= y <= 1
    % y_bar = y + theta (y - y_old);
    % x_old = x
    % x = arg min_x sigma <Ax-b,y_bar> + 0.5 ||x-x_old||_2^2, s.t. 0 <= x <= 1
    
    % y = arg min_y - tau <Ax-b,y> + 0.5 ||y-y_old||_2^2, s.t. -1 <= y <= 1
    % y = arg min_y 0.5 ||y-y_old - tau (Ax-b) ||_2^2, s.t. -1 <= y <= 1
    % y = arg min_y 0.5 ||y-(y_old + tau (Ax-b)) ||_2^2, s.t. -1 <= y <= 1
    y = y + tau * (A*x-b);
    y(y<-1)=-1;
    y(y>1) = 1;
    
    y_bar = y ;
    
    x_old = x;
    % x = arg min_x sigma <Ax-b,y_bar> + 0.5 ||x-x_old||_2^2, s.t. 0 <= x <= 1
    % x = arg min_x sigma <Ax,y_bar> + 0.5 ||x-x_old||_2^2, s.t. 0 <= x <= 1
    % x = arg min_x 0.5 ||x-x_old + sigma A' y_bar||_2^2 + 0.5 ||Ax-Axt||_2^2, s.t. ||x||_0<=k
    o = x_old - sigma * A'*y_bar;
    % x = arg min_x 0.5 ||x-o||_2^2 + 0.5 beta ||Ax-Axt||_2^2, s.t. ||x||_0<=k
    % x = arg min_x 0.5 x'x - <o,x> + 0.5 beta  x'A'Ax - beta <x,A'Axt>
    % x = arg min_x 0.5 x'x - <o,x> + 0.5 beta x'A'Ax - beta <x,A'Axt>
    Q = beta*A'*A + eye(n);
    p = -o - beta * A'*A*x;
    % x = arg min_x 0.5 x'Qx  + <p,x>
    %     x  = - inv(Q)*p;
    x = BlockDecAlgQuadratic_c(proj_l0(x+eps,k),Q,p,k,[10;2]);
    
    
    sigma = sigma / 1.01;
    fobj = HandleObj(x);
    his(iter) = fobj;
    fprintf('iter:%d, fobj:%f\n',iter,fobj);
end

ddd


