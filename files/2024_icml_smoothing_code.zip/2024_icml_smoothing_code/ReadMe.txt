README File
=================================================
1. Running the Code
To reproduce the experiments in [1], you need to perform two steps: (i) run mexC.m (ii) run demo_*.m


2. REFERENCES:
[1] Smoothing Proximal Gradient Methods for Nonsmooth Sparsity Constrained Optimization: Optimality Conditions and Global Convergence. Submitted for publication.

