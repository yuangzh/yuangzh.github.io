function [data,ks] = ReadParameters
data = [1:10];
ks = [4:4:40];
