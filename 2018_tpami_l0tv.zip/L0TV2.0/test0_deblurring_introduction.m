clc;clear all;close all;
randn('seed',0);rand('seed',0);
addpath('cimg','dimg','util','scratched','solvers')

lambda = 2;
noiselevel = 30;
B_Clean = double(imread(sprintf('barbara.png')));
P = GenBlurOper;
Amap = @(X)functionAX(P,X,'deblurring');
Atmap = @(X)functionAX(P',X,'deblurring');
B_Corrupted = impulsenoise(Amap(B_Clean),noiselevel/100,1);

% Generate the mask matrix O
O = ones(size(B_Clean));
O(B_Corrupted==255)=0;
O(B_Corrupted==0)=0;

B_Clean = B_Clean/255;
B_Corrupted = B_Corrupted/255;

p = 2;
P = GenBlurOper;
LargestEig = min(sqrt(sum(abs(P(:))>0)*sum(P(:).*P(:))), sum(abs(P(:))));% Largest Eigenvalue of A'A

acc = 0.001/255;
penalty_ratio = 10;
tic;
[U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,penalty_ratio,B_Clean);
toc;

S=ones(size(U)) - abs(B_Corrupted-U);

figure;
subplot(1,4,1); imshow(B_Clean,[]);title('Original','fontsize',13);
subplot(1,4,2); imshow(B_Corrupted,[]); title('Corrupted','fontsize',13);
subplot(1,4,3); imshow(U,[]); title('Recovered','fontsize',13);
subplot(1,4,4); imshow(S,[]); title('Complement','fontsize',13);


imwrite(B_Corrupted,sprintf('test0_deblurring_introduction0.png'));
imwrite(U,sprintf('test0_deblurring_introduction1.png'));
imwrite(S,sprintf('test0_deblurring_introduction2.png'));




