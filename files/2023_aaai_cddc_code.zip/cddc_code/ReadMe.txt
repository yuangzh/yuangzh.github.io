README File
=================================================
1. Running the Code
To reproduce the experiments in [1], you need to perform two steps: (i) run mexC.m (ii) run demo_*.m


2. REFERENCES:
[1] Coordinate Descent Methods for DC Minimization. Submitted for publication.

