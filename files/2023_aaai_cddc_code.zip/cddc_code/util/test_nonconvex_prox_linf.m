function test_nonconvex_prox_linf
clc;clear all;close all;
% 0.5 (t-beta)^2 - lambda || t a + b||_inf
for iter = 1:100000000
    m = 10;
    beta = randn(1)*100*rand(1);
    a = randn(m,1)*100*rand(1);
    b = randn(m,1)*100*rand(1);
    lambda = rand(1)*100*rand(1);
    HandleObj = @(t) ComputeObj(t,beta,lambda,a,b);
    x1 = fminsearch(HandleObj,0);
    x2 = nonconvex_prox_linf(beta,lambda,a,b);
    f1 = HandleObj(x1);
    f2 = HandleObj(x2);
    
    fprintf('iter:%f, fobj:%.5e %.5e\n',iter,f1,f2);
    
    if(f2>f1 + 1e-6*abs(mean([f1;f2])))
        x1
        x2
        dddd
    end
    
    
end


function [fobj,grad] = ComputeObj(t,beta,lambda,a,b)
% 0.5 (t-beta)^2 - lambda || t a + b||_inf
e = t*a+b;
[val,index]= max(abs(e));
fobj = 0.5*(t-beta)^2 - lambda*val;
grad = t  - beta  - lambda*a(index)*sign(e(index));





function [t] = nonconvex_prox_linf(beta,lambda,a,b)
% 0.5 (t-beta)^2 - lambda || t a + b||_inf
% e = t*a+b;
% [val,index]= max(abs(e));
% fobj = 0.5*(t-beta)^2 - lambda*val;
% grad = t  - beta  - lambda*a(index)*sign(e(index)) = 0

ts = [beta + lambda*a; beta-lambda*a];
for i = 1:length(ts)
    t  = ts(i);
    e = t*a+b;
    his(i) = 0.5*(t-beta)^2 - lambda*max(abs(e));
end
plot(his)
 pause
[val,ind] = min(his);
t = ts(ind);
[inds] = find(his==val);
t = ts(inds);
t = find_small_roots(t);

function [t] = find_small_roots(t)
[~,ind]=min(abs(t));
t = t(ind);



