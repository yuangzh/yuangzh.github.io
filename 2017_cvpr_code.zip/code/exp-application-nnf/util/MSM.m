function [x,his] = MSM(A,b,x,max_iter,timelimit,initt,omega)
% 0.5*trace(X'*A*X) + <B,X>, X>=0;
% X: n x d
% A: n x n
% B: n x d

[n,d] = size(b);
theta = 0.01;
L = tril(A,-1); 
diagA = (diag(A))';
diagind = [1:(n+1):(n*n)];
B = L; B(diagind) = B(diagind) + (diagA+theta)/omega;
C = L';C(diagind) = C(diagind) + ((omega-1)*diagA-theta)/omega;
his = [];

for iter = 1:max_iter,
    x  = linf_triangle_subproblem(B,C*x+b,0,n,d);
    if etime(clock,initt) > timelimit,
    break;
    end
end

