function [v,val]=rank1Approximation_eigs(M)
 n=length(M);
warning off;
opts.tol=1e-300;
opts.maxit=1e300;
opts.p=n;
solver=1;
if(solver==1)
       [v,val,flag] = eigs((M+M')/2,1,'la',opts);
       if(flag~=0)
           error('not converged');
       end
elseif(solver==2)
    [V,D]=eig((M+M')/2);
    val= D(end,end);
    v= V(:,end);
end
       if(val==0)
           error('df');
       end;
 
v=v(:,1);
val=val(1,1);

 
if(val<0)error('Negative');end