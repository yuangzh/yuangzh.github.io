function test_nonconvex_prox_lhalf
clc;clear all;close all;
% 0.5 (t-beta)^2 + lambda || t a + b||_0.5

for iter = 1:100000000
%     rand('seed',1111);
%     randn('seed',1111);
    m = 10;
    beta = randn(1)*100*rand(1);
    a = randn(m,1)*100*rand(1);
    b = randn(m,1)*100*rand(1);
    lambda = rand(1)*10*rand(1);
    HandleObj = @(t) ComputeObj(t,beta,lambda,a,b);
    
    x1 = fminsearch(HandleObj,0);
    x2 = nonconvex_prox_lhalf(beta,lambda,a,b);
    f1 = HandleObj(x1);
    f2 = HandleObj(x2);
    
    
    
    fprintf('iter:%f, fobj:%.5e %.5e\n',iter,f1,f2);
    
    if(f2>f1 + 1e-6*abs(mean([f1;f2])))
        x1
        x2
        dddd
    end
    
    
end





function [fobj] = ComputeObj(t,beta,lambda,c,d)
fobj =  lambda*norm(t*c+d,0.5)^0.5;

function best_t = nonconvex_prox_lhalf(beta,lambda,c,d)
% fobj = 0.5*(t-beta)^2 + lambda*norm(t*c+d,0.5)^0.5;

points = [beta;(-d./c);(d./c)];



best_fobj = inf;
his= [];

for i = 1:length(points)

    test_obj = ComputeObj(points(i),beta,lambda,c,d);
    his(i) = test_obj;

end
[~,ind]=min(his);
best_t = points(ind);


function [fobj,grad] = ComputeObj1d(t,beta,lambda,a,b)
fobj = 0.5*(t-beta)^2 - lambda*norm(t*a+b,1);
grad = t-beta - lambda*sign(t*a+b)'*a;
