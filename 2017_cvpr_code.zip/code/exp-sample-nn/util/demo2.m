function demo
clc;clear all;close all;
addpath('util');
randn('seed',0);
rand('seed',0);

% 0.5 || AX-B||_F^2 + lambda ||X||_1

n = 10; d = 100;
A1 = randn(n,d);
B1 = randn(n,1);
lambda = 0.000001;
X0 = rand(d,1);
A = A1'*A1;
b = -A1'*B1;

timelimit = 2;
HandleObj = @(x)0.5*norm(A1*x-B1,'fro')^2 + lambda * norm(x,1);

% initt=clock;
% [x1,his] = MSM_l1_plain(A1'*A1,-A1'*B1,lambda,X0,1e10,timelimit);
% etime(clock,initt)
 [x1,his] = NewProximalPoint(A,b,lambda,X0,HandleObj);
 plot(his)
 HandleObj(x1)
ddd
% tic;
% [x2] = l1_ls(A1,B1,lambda,timelimit);
% toc;


% opts.x0 = X0;
% opts.maxIter=1e12;opts.mFlag=1;opts.lFlag=1;opts.tFlag=2;opts.tol= 0;
% initt=clock;
% [x3, funVal3, ValueL3]= LeastR(A1, B1, lambda, opts,timelimit);
% etime(clock,initt)

% HandleObj(x2)

% classical proximal algorithm


x = X0;
L = max(eig(A));
his2=[];
for iter = 1:20000,
   fobj = HandleObj(x);
    grad = A*x + b;
     his2=[his2;fobj];
    [x] = prox_l1(x-grad/L,lambda/L);
end
semilogy(his2)


% HandleObj(x1)
% HandleObj(x3)
min(his2)
min(his)
% min(his)
% min(funVal3)




function [x,his] = NewProximalPoint(A,b,lambda,x0,HandleObj)
% new proximal algorithm
% Ref: Sect 3.5 in "Error Bounds and convergence analysis of feasiable descent methods: a general approach"
x = x0;
alpha = 1;
n = length(b);
% HandleObj = @(x) 0.5*x'*A*x + b'*x + lambda*sum(abs(x));
I  = eye(n);
L = tril(A,-1);
D = diag(diag(A));
B = 1/alpha*D +L;
C = (1-1/alpha)*D +L';

his=[];
for iter = 1:4000,
    % solve x <= P[(I-B)x-Cx'-b]
    [x,flag] = solveprox(I - B,-C*x-b,lambda);
    fobj = HandleObj(x);
    his=[his;fobj];
 
end



function [x,flag] = solveprox(P,y,lambda)
% This program solves the following proximal equation:
% x = prox_f(Px+y)
% where P is a lower triangular matrix and f = lambda|x|_1
% where P is a lower triangular matrix, b is vector n x 1
% P = [A11  0   0   0   0   ; 
%      A21 A22  0   0   0   ;
%      A31 A32 A33  0   0   ;
%      A41 A42 A43 A44  0   ;
%      A51 A52 A53 A54 A55  ];
%
n = length(y);
x = zeros(n,1);
for i=1:n,
    tot=0;
    for j=1:(i-1),
        tot = tot + P(i,j)*x(j);
    end
    b1 = tot + y(i);
    x(i) = l1_fixpoint(P(i,i),b1,lambda);
end
 flag=0;
if(norm(x-prox_l1(P*x+y,lambda))<1e-12),flag=1;end



 
function [x] = l1_fixpoint(b,c,lambda)
% It solves the following one dimensional fixed point problem:
% x = P(bx+c), where P(a) = arg min_x 0.5 (x-a)^2 + lambda ||x||_1
% x = sign(b*x+c) max(0,|bx+c|-lambda)
% fun = @(x)sign(b*x+c)*max(0,abs(b*x+c)-lambda)-x;
% x_matlab = fsolve(fun,0);
x1 = 0; x2 = (-c-lambda)/(b-1); x3 = (lambda-c)/(b-1);
if(abs(b*x1+c)<=lambda),x=x1;return;end
if(b*x2+c<=-lambda),x=x2;return;end
if(b*x3+c>=lambda),x=x3;return;end
error('No solution!');







