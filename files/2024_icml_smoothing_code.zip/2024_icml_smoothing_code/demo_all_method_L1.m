
clc;clear all;close all;
addpath('G:\cvx','solver','dat','util');
randn('seed',1);
rand('seed',1);
warning off;




ks   = [5 10 20 30 40 50 60 70 80 90];
data_id = [1 2 3 4 11 12 13 14];

n_ks = length(ks);
n_data_id = length(data_id); 

ks   = repmat(ks,1,n_data_id);data_id   = repmat(data_id,n_ks,1); data_id = data_id(:)';


for iii = 1:length(ks)

    data_id(iii)
    
    [A,b] = getdata(data_id(iii));
    k = ks(iii);
    [dat_m,dat_n] = size(A);
    lambda = 0.01/dat_m;
    
    x0 = 0.001*proj_l0(randn(size(A,2),1),k);
    
    HandleObj = @(x)norm(A*proj_l0(x,k)-b,1);
    

    tic;
    [x1,his1] = L1Reg_PADM_BCD(A,b,lambda,k,x0);
    toc;
    
    tic;
    [x2,his2] = L1Reg_ADMM_IHT(A,b,lambda,k,x0);
    toc;
    
    tic;
    [x3,his3] = L1Reg_ProjSubGrad_IHT(A,b,lambda,k,x0);
    toc;

    tic;
    [x4,his4] = L1Reg_ADMM_IHT(A,b,lambda,k,x0);
    toc;

    tic;
    [x5,his5] = L1Reg_DIHT(A,b,lambda,k,x0);
    toc;

    tic;
    [x6,his6] = L1Reg_CVX_L1(A,b,lambda,k,x0);
    toc;

    tic;
    [x7,his7] = L1Reg_NCVX_Lp(A,b,lambda,k,x0);
    toc;
    
    fprintf('index:%d, data:%d, k:%f, (m,d) = (%d %d)\n',iii,data_id(iii),k,size(A,1),size(A,2));
    
    fprintf('M1: %f\n',HandleObj(x1));
    fprintf('M2: %f\n',HandleObj(x2));
    fprintf('M3: %f\n',HandleObj(x3));
    fprintf('M4: %f\n',HandleObj(x4));
    fprintf('M5: %f\n',HandleObj(x5));
    fprintf('M6: %f\n',HandleObj(x6));
    fprintf('M7: %f\n',HandleObj(x7));

    One = [];
    One.data_id = data_id(iii);
    One.k = ks(iii);
    One.x1 = x1; One.x2 = x2; One.x3 = x3; One.x4 = x4; One.x5 = x5;One.x6 = x6;One.x7 = x7;
    One.his1 = his1; One.his2 = his2; One.his3 = his3; One.his4 = his4; One.his5 = his5;One.his6 = his6;One.his7 = his7;
    One.fobj1 = HandleObj(x1); One.fobj2 = HandleObj(x2); One.fobj3 = HandleObj(x3);One.fobj4 = HandleObj(x4);One.fobj5 = HandleObj(x5);One.fobj6 = HandleObj(x6);One.fobj7 = HandleObj(x7);
    result{iii} = One;
    save('result1','result')
    '*************************************************'
end




















