
 function w = proj_l1(v, b)
%    min   ||w - v||_2
%    s.t.  ||w||_1 <= b.
try
u = sort(abs(v),'descend');
sv = cumsum(u);
rho = find(u > (sv - b) ./ (1:length(u))', 1, 'last');
theta = max(0, (sv(rho) - b) / rho);
w = sign(v) .* max(abs(v) - theta,0);
catch exception
w = zeros(size(v));
end