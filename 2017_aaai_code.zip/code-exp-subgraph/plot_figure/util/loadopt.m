function [options] = loadopt
options=[];

options.colors = loadcolor;
options.lineStyles=loadlinestyples;
options.markers=loadmarkers;
options.errorColors=loaderrorcolor;
options.markerSize=12;
options.markerSpacing=loadmarkerSpacing;
options.labelLines = 1;
options.labelRotate = 1;
end


function lineStyles = loadlinestyples
lineStyles{1}='-';
lineStyles{2}='-';
lineStyles{3}='-';
lineStyles{4}='-'; % solid
lineStyles{5}='-';
lineStyles{6}='-';
lineStyles{7}='-'; % dashdot
% lineStyles{8}='-.'; % dashdot
% lineStyles{9}=':'; % dotted
end

function markers = loadmarkers
markers{1}='s';
markers{2}='x';
markers{3}='^';
markers{4}='v';
markers{5}='d';
markers{6}='o';

markers{7}='o';
markers{8}='.';
markers{9}='+';
markers{10}='*';
markers{11}='<';
markers{12}='>';
markers{13}='h';
end



function [colors] = loaderrorcolor
colors = [
    0.75 0.75 1
    0.75 1 0.75
    1 0.75 0.75
    0.75 0.75 1
    0.75 1 0.75
    1 0.75 0.75
    0.30 0.5 0.75
    0.5 0.5 0.15
    0.6 0.5 0.05
    ];
end

 

function [markerSpacing] = loadmarkerSpacing
markerSpacing = [...
    5 1;
    5 4;
    5 6;
    5 8;
    5 10;
    5 12;
    5 12;
    5 12;
    5 12;
    5 12;
    ];

markerSpacing = [...
    1 1;
    1 1;
    1 1;
    1 1;
    1 1;
    1 1;
    1 1;
    1 1;
    1 1;
    1 1;
    ];

end
