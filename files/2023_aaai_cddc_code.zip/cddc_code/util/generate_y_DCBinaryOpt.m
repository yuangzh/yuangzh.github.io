function [y] = generate_y_DCBinaryOpt(G)
[m,n] = size(G);
x = sign(randn(n,1));
b = G*x;
y = b + 0.05*norm(b)*randn(m,1);
