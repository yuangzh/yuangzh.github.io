clc;clear all;close all;
randn('seed',0);
rand('seed',0);

% delete *.png
addpath('cimg','util')
ns=[10:10:70];


images = {'walkbridge','pepper','mandrill','lenna','lake','jetplane','blonde','cameraman','barbara','boat','pirate','livingroom','house'};
dirty_image_direetory = 'dimg';

fprintf('denoising Salt-and-Pepper begin\n');
for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        B_Corrupted = impulsenoise(B_Clean,ns(i)/100,0);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s\\denoising_%s_%s_%d.png',dirty_image_direetory,images{j},'Salt-and-Pepper',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end
fprintf('\ndenoising Salt-and-Pepper end\n\n');

fprintf('denoising Random-Valued begin\n');
for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        B_Corrupted = impulsenoise(B_Clean,ns(i)/100,1);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s\\denoising_%s_%s_%d.png',dirty_image_direetory,images{j},'Random-Valued',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end
fprintf('\ndenoising Random-Valued end\n\n');






fprintf('deblurring Salt-and-Pepper begin\n');

for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        P = GenBlurOper;
        Amap = @(X)functionAX(P,X,'deblurring');
        B_Corrupted = impulsenoise(Amap(B_Clean),ns(i)/100,0);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s\\deblurring_%s_%s_%d.png',dirty_image_direetory,images{j},'Salt-and-Pepper',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end
fprintf('\ndeblurring Salt-and-Pepper end\n\n');

fprintf('deblurring Random-Valued begin\n');
for i=1:length(ns),
    for j=1:length(images),
        image_name_clean = sprintf('%s.png',images{j});
        B_Clean = double(imread(image_name_clean));
        P = GenBlurOper;
        Amap = @(X)functionAX(P,X,'deblurring');
        B_Corrupted = impulsenoise(Amap(B_Clean),ns(i)/100,1);
        B_Corrupted = B_Corrupted / 255;
        image_name_corrupted = sprintf('%s\\deblurring_%s_%s_%d.png',dirty_image_direetory,images{j},'Random-Valued',ns(i));
        imwrite(B_Corrupted,image_name_corrupted);
        fprintf('.');
    end
end

fprintf('\ndeblurring Random-Valued end\n\n');