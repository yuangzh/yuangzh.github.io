function test_nonconvex_prox_l1
clc;clear all;close all;
rand('seed',0);
randn('seed',0);
% 0.5 (t-beta)^2 - lambda || t a + b||_1

for iter = 1:100000000
    m = 15;
    beta = randn(1)*100*rand(1);
    a = randn(m,1)*100*rand(1).*max(0,randn(m,1)); %

    b = randn(m,1)*100*rand(1); %.*max(0,randn(m,1))
    lambda = rand(1)*100*rand(1);
    

    load ooooo;
    beta = ccc1;
    lambda = ccc2;
    a = full(ccc3);
    b = full(ccc4);
    m = ccc5;
 
    HandleObj = @(t) ComputeObj(t,beta,lambda,a,b);
    x1 = fminsearch(HandleObj,0);
    x2 = nonconvex_prox_l1(beta,lambda,a,b,m );
    x3 = nonconvex_prox_l1_mex(beta,lambda,a,b,m);


 
    f1 = HandleObj(x1);
    f2 = HandleObj(x2);
    f3 = HandleObj(x3);
    
    
    
    fprintf('iter:%f, fobj:%.5e %.5e %.5e\n',iter,f1,f2,f3);
 
    scale = abs(mean([f1;f2]));
    if(f2>f1 + 1e-6* scale  ) || (abs(f2-f3) > 1e-5*scale)
        x1
        x2
        x3
        nonono
    end

 
end

 






function [fobj,grad] = ComputeObj(t,beta,lambda,a,b)
fobj = 0.5*(t-beta)^2 - lambda*norm(t*a+b,1);
grad = t-beta - lambda*sign(t*a+b)'*a;
% grad = t-beta - lambda*sign(t*sign(a)+b/norm(a))'*a;


