function [u] = Yan_AOP(B_Corrupted,P,Amap,lambda,noiselevel,B_Clean)
f = B_Corrupted;
MaxIter=7;
[y nois_ma2] = amf(f*255,39,0,0);
E = y(:)/255 - f(:);
[~, index] = sort(abs(E), 'descend');
thres = max(abs(E(index(floor(1*noiselevel/100*512*512)))),1e-5);
D = (abs(y/255-f)>thres);
D = double(D);
D1 = D;

for i=1:MaxIter
    u = tvinpaint(f,lambda,D,P);
    Au = Amap(u);
    E = Au(:) - f(:);
    [~, index] = sort(abs(E), 'descend');
    thres = abs(E(index(floor(1*noiselevel/100*512*512))));
    D = (abs(Au-f)>thres);
    D = double(D);
    PSNR  =   snr_l1(u, B_Clean);
    fprintf('iter: %d, PSNR:%f\n',i,PSNR);
end