function demo
clear all; close all;clc;
randn('state',  0);   
rand('state',  0);   
 
ns=[5000 4000 3000 2000 1000 500];
rs=[1 10 40 80 -1];
times=1;
 ns = 1500;
% rs = 20;

for i=1:length(ns),
n=ns(i); A = randn(n); A = (A + A')/2;

for j=1:length(rs),
d=rs(j);if(d==-1),d=floor(sqrt(n));end

A = randn(n,floor(d/2)); A = A*A';

t1s=[]; t2s=[]; t3s=[];c1s=[]; c2s=[]; c3s=[]; orths = [];
for t=1:times,
verb=0;
tic;[R1]=lro(A,d,1e-6,1,verb);
orthogonality = norm(R1'*R1-eye(d),'fro');
t1=toc; t1s=[t1s;t1]; 
tic;[R2,none]=eigs(A,d,'la');t2=toc; t2s=[t2s;t2];
tic;[R3,none]=jdqr(A,d,'LR'); t3=toc; t3s=[t3s;t3];
orths = [orths;orthogonality];
[c1,c2,c3]=checkerror (A,R1,R2,R3);
c1s=[c1s;c1];c2s=[c2s;c2];c3s=[c3s;c3];
clear x R1 R2 R3 R4;
end
printResult(t1s,t2s,t3s,c1s,c2s,c3s,n,d,orths);
clear t1s t2s t3s c1s c2s c3s;
end
 clear A;
end

function printResult(t1s,t2s,t3s,c1s,c2s,c3s,n,d,orths)
fprintf('********************** begin round **************************\n');
fprintf('patters:%d, rank:%d\n',n,d);
fprintf('solver:conj, time:%.2f, acc:%.6f, orth:%e\n',mean(t1s), mean(c1s), mean(orths));
fprintf('solver:eigs, time:%.2f, acc:%.6f\n',mean(t2s), mean(c2s) );
fprintf('solver:jdqr, time:%.2f, acc:%.6f\n',mean(t3s), mean(c3s) );
fprintf('result paste:\n')
% fprintf('%d & %d & %.2f & %.6f & %.2f & %.6f & %.2f & %.6f & %.2e \\\\\n',n,d,mean(t3s),mean(c3s),mean(t2s),mean(c2s),mean(t1s),mean(c1s),mean(orths));
fprintf('**********************  end round  **************************\n');
 
function [r1,r2,r3 ]=checkerror (A,R1,R2,R3)
 [n]=size(A,1);
 r1 =  trace(R1'*A*R1) / n;
 r2 =  trace(R2'*A*R2) / n;
 r3 =  trace(R3'*A*R3) / n;
 clear A R1 R2 R3;
 
 