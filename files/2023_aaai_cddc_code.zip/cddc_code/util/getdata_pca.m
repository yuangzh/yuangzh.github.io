function [A] = getdata_pca(iwhich)


switch iwhich
    
    case 11
        m = 256; n = 1024; A = randn(m,n);
    case 12
        m = 256; n = 2048; A = randn(m,n);
    case 13
        m = 1024; n = 256; A = randn(m,n);
    case 14
        m = 2048; n = 256; A = randn(m,n);

    case 21
        m = 256; n = 1024; A = get_real_data(m,n);
    case 22
        m = 256; n = 2048; A = get_real_data(m,n);
    case 23
        m = 1024; n = 256; A = get_real_data(m,n);
    case 24
        m = 2048; n = 256; A = get_real_data(m,n);

    case 31
        m = 256; n = 1024; A = randn(m,n); A = scaleA(A);
    case 32
        m = 256; n = 2048; A = randn(m,n); A = scaleA(A);
    case 33
        m = 1024; n = 256; A = randn(m,n); A = scaleA(A);
    case 34
        m = 2048; n = 256; A = randn(m,n); A = scaleA(A);

    case 41
        m = 256; n = 1024; A = get_real_data(m,n); A = scaleA(A);
    case 42
        m = 256; n = 2048; A = get_real_data(m,n); A = scaleA(A);
    case 43
        m = 1024;  n = 256; A = get_real_data(m,n); A = scaleA(A);
    case 44
        m = 2048; n = 256; A = get_real_data(m,n); A = scaleA(A);

      
end



A = full(A);
A = A./norm(A,'fro');
function [X] = get_real_data(m,n)
load E2006_5000_10000;
[data_m,data_n]=size(x);
sub_set_m = randperm(data_m,m);
sub_set_n = randperm(data_n,n);
X = x(sub_set_m,sub_set_n);

        

function [A] = scaleA(A)
[m,n] = size(A);
seq = randperm(m*n,round(0.2*m*n));
A(seq) = A(seq)*100;
