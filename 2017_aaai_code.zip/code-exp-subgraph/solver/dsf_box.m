function [x,fobj,his] = dsf_box(W,k)
% min -1 x'*W*x, s.t. 0<=x<=1, sum(x) = k

W = (W+W')/2;
n = size(W,1);
[~,val] = largest(W,0.1);
lambda = abs(val)*1.1;
L = speye(n)*lambda - W;
[~,Lip] = largest((L+L')/2,0.1);

x = zeros(n,1);
y = zeros(n,1);
e = ones(n,1);
t=1;his = [];
for in=1:100,
    grad = L*y;
    xp = x; tp = t;
    x = BreakPointSearch(e,-(y-grad/Lip),k,'==');
    t = 0.5*(1+sqrt(1+4*t*t));
    y = x + ((tp-1)/t)*(x-xp);
    f_cur = computeobj(x,W,k);
    his = [his;f_cur];
end
x=proj_01k(x,k);
fobj = computeobj(x,W,k);







