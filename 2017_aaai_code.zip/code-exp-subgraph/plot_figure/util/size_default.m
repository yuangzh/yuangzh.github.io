function optsize=size_default
optsize=[];
optsize.legend_font_size = 17;
optsize.figure_line_width = 4;
optsize.marker_size=12;
optsize.scale_font_size = 15;
optsize.axis_font_size = 20;
