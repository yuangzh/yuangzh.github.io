function B = nesterov(B,grad,prox,Lip,max_iter)
% min_{x} f(x) + lambda g(x)
alpha=1;
By=B;

for iter = 1:max_iter,
    Bp = B;
    B = prox(By-grad(By)/Lip);
    alphap=alpha; alpha= (1+ sqrt(4*alpha*alpha +1))/2;
    By = B + (alphap-1)/alpha*(B-Bp);
end

