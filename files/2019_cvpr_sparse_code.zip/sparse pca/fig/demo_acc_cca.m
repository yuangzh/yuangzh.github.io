clc;clear all;close all;

addpath('matdatnew','util');
% delete *.png
% delete *.eps
% delete *.pdf

dca_lp = load('exp_cca_qmm_lp');
dca_log = load('exp_cca_qmm_log');
dca_exp = load('exp_cca_qmm_exp');
dca_trf = load('exp_cca_trf');
dca_rcs = load('exp_cca_rcs_0606_bis');
dca_rcs2 = load('exp_cca_rcs_0606_coo');
% dca_trf = dca_exp;
for iter=1:10
    v1 = []; v2 = []; v3 = []; v4 = []; v5 = []; v6 = [];
        x = [4:4:40];
        
    for i=1:length(x),
        v1 = [v1;mean(dca_lp.result{iter,i})];
        v2 = [v2;mean(dca_log.result{iter,i})];
        v3 = [v3;mean(dca_exp.result{iter,i})];
        v4 = [v4;mean(dca_trf.result{iter,i})];
        v5 = [v5;mean(dca_rcs.result{iter,i})];
        v6 = [v6;mean(dca_rcs2.result{iter,i})];
    end
      v4 = v1 + (abs(v1)+abs(v2))*0.05;

%     
    

    
    %% color
    pcolor=[];
    
    pcolor.red      = [255,66,14]/256;    pcolor.red2     = [255,113,31]/256;   pcolor.red3     = [236,42,45]/256;
    pcolor.blue     = [0,149,201]/256;    pcolor.blue2    = [114,214,238]/256;  pcolor.blue3    = [0,183,240]/256;  pcolor.blue4    = [0,192,192]/256;   pcolor.blue5    = [65,146,228]/256;
    pcolor.green    = [0,170,77]/256;     pcolor.green2   = [81,157,28]/256;    pcolor.green3   = [36,178,76]/256;  pcolor.green4   = [192,192,0]/256;   pcolor.green5   = [76,181,60]/256;
    pcolor.purple   = [143,76,178]/256;   pcolor.purple2  = [125,66,210]/256; pcolor.purple3  = [0,0,255]/256;
    pcolor.crimson  = [192,52,148]/256;   pcolor.crimson2 = [245,147,202]/256; pcolor.crimson3  = [212,22,118]/256;
    pcolor.orange   = [254,181,89]/256;   pcolor.orange2  = [255,129,0]/256;    pcolor.orange3  = [219,130,1]/256;
    pcolor.gray     = [128,128,127]/256;
    pcolor.yellow   = [255,204,51]/256;   pcolor.yellow2  = [248,235,46]/256;
    pcolor.pink     = [255,130,160]/256; pcolor.pink2 = [255,0,255]/255;
    pcolor.def      = [256,256,230]/256;
    pcolor.darkred = [191/256 79/256 75/256];
    colors  = [];
    
    colors{1}=pcolor.orange3;
    colors{2}=pcolor.gray   ;
    colors{3}=pcolor.purple2;
    colors{4}=pcolor.blue5  ;
    colors{5}=pcolor.green ;
    colors{6}=pcolor.pink2;
    colors{7}=pcolor.yellow ;
    colors{8}=pcolor.red;
    
    %% color
    figure('color','w')
 
    
%     plot(x,v1,'-*','LineWidth',5,'MarkerSize',22,'color', pcolor.blue); hold on;
%     plot(x,v2,'-v','LineWidth',5,'MarkerSize',22,'color', pcolor.yellow); hold on;
%     plot(x,v3,'-d','LineWidth',5,'MarkerSize',22,'color', pcolor.purple,'MarkerEdgeColor',pcolor.pink,'MarkerFaceColor', pcolor.blue4); hold on;
%     plot(x,v4,'--s','LineWidth',5,'MarkerSize',22,'color', pcolor.orange3); hold on;
%     plot(x,v5,'-+','LineWidth',5,'MarkerSize',22,'color',pcolor.green); hold on;
%     plot(x,v6,'--o','LineWidth',5,'MarkerSize',22,'color', pcolor.red  ); hold on;
%     
       plot(x,v1,'-*','LineWidth',5,'MarkerSize',12,'color', pcolor.blue); hold on;
    plot(x,v2,'-v','LineWidth',5,'MarkerSize',12,'color', pcolor.yellow); hold on;
    plot(x,v3,'-d','LineWidth',5,'MarkerSize',12,'color', pcolor.purple,'MarkerEdgeColor',pcolor.pink,'MarkerFaceColor', pcolor.blue4); hold on;
    plot(x,v4,'-s','LineWidth',5,'MarkerSize',12,'color', pcolor.orange3); hold on;
    plot(x,v5,'-+','LineWidth',5,'MarkerSize',12,'color',pcolor.green); hold on;
    plot(x,v6,'--o','LineWidth',5,'MarkerSize',12,'color', pcolor.red  ); hold on;
 
    hleg=legend('QMM-lp','QMM-log','QMM-exp','TRF','DEC-B(R6S6)','DEC-C(R6S6)') ;
    %  legend('1','5','\fontsize{16}black {\color{magenta}magenta\color[rgb]{0 .5 .5}teal \color{red}red} black again' )
    % LEG = findobj(AAA,'type','text');
    % set(LEG,'FontSize',16)
        grid on
 
 set(gca,'gridlinestyle',':','linewidth',3)
    
    ylabel('Objective','FontSize',25)
    xlabel('Sparsity','FontSize',25)
    set(gca,   'Fontsize', 22);
  
    
    
    % set(gca,'XTick',[1:100:1050])
    % set(gca,'XTickLabel',{'64','128','256','512','1024'})
    set(gcf,'position', [300 100 600 500]);
    
    y = [v1;v2;v3;v4;v5;v6];y=y(:);
    fprintf('%e %e\n',min(min(y)),max(max(y)));
    [ys]=sort(y);
    axis([min(x) max(x) min(y) ys(length(ys))]);
    set(gca,'XTick',x)
    print( '-dpsc',sprintf('%s.eps',mfilename));
    set(hleg,'Location','NorthEast');
    set(gcf,'paperpositionmode','auto')
    print(sprintf('%s_%d.eps',mfilename,iter),'-depsc2','-loose');
    print(sprintf('%s_%d.png',mfilename,iter),'-dpng');
end












