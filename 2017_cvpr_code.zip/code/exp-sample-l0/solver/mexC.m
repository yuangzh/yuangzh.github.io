clc;clear all;close all;


mex -largeArrayDims -O l0_triangle_subproblem.c;
