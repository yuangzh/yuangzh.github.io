function test_nonconvex_prox_linfl2
clc;clear all;close all;
% min_t 0.5 t^2 - beta t - lambda || x+tei ||_2
% s.t. lb <= t <= ub


for iter = 1:100000000
    iter
    rand('seed',iter);
    randn('seed',iter);
    m = 10;
    beta = randn(1)*100*rand(1);
    x = randn(m,1)*100*rand(1);
    lambda = rand(1)*100*rand(1);
    i = randperm(m,1);
    lbub = sort(randn(2,1));
    lb = lbub(1);
    ub = lbub(2);


    HandleObj = @(t)ComputeObj(t,beta,lambda,x,i,lb,ub);
    x1 = fminbnd(HandleObj,lb,ub);x1 = max(lb,min(x1,ub));
    x2 = nonconvex_prox_linfl2(beta,lambda,x,i,lb,ub);x2 = max(lb,min(x2,ub));

    f1 = HandleObj(x1);
    f2 = HandleObj(x2);
    fprintf('iter:%f, fobj:%.5e %.5e\n',iter,f1,f2);

    if(f2>f1 + 1e-7*abs(mean([f1;f2])))
        f1
        f2
        f1 - f2
        x1
        x2
        dddd
    end
    
    
end



function [f] = ComputeObj(t,beta,lambda,x,i,lb,ub)
% min_t 0.5 t^2 - beta t - lambda || x+tei ||_2
% s.t. lb <= t <= ub
t = max(lb,min(t,ub));
x1 = x;
x1(i) = x1(i) + t;
f = 0.5*t^2 - beta*t - lambda*norm(x1);
