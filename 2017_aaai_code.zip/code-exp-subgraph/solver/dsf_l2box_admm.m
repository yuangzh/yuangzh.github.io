function [x,fobj,his] = dsf_l2box_admm(W,k,initalpha)
% min -x'*W*x, s.t. x \in {0,1}^n, sum(x) = k
t1 = clock;
W = (W+W')/2;
n = size(W,1);
[~,val] = largest(W,0.01);
lambda = abs(val)*1.1;
L = speye(n)*lambda - W;
L = (L+L')/2;
[~,max_mm] = largest(L,0.01);
t2 = clock;
fprintf('time spent in lipschitz computation: %f\n',etime(t2,t1));

% min x'*(lambda I-W)*x, s.t. x \in {0,1}^n, sum(x) <= k
% min 0.5x'*L*x, s.t. x \in {0,1}^n, sum(x) <= k
% min 0.5x'*L*x, s.t. 0<=x<=1, ||2x-1||_2^2, sum(x) <= k
% min 0.5x'*L*x, s.t. 0<=x<=1, x=y, ||2y-1||_2^2, sum(x) <= k
% J(x,y,pi) = 0.5x'*L*x + <x-y,pi> + 0.5 alpha ||x-y||^2, s.t. 0<=x<=1, ||2y-1||_2^2=n, sum(x) <= k

x = zeros(n,1);
y = zeros(n,1);
pi = zeros(n,1);
alpha = initalpha;
x_best = x;
f_min = inf;
his = [];
e = ones(n,1);
for iter = 1:100,
    % 0.5x'*L*x + <x-y,pi> + 0.5 alpha ||x-y||^2, s.t. 0<=x<=1, sum(x) <= k
    Lip = max_mm + alpha;
    t1 = clock;
    for in=1:50,
        grad = L*x +pi + alpha *(x-y);
        xt = x;
        x = BreakPointSearch(e,-(x - grad/Lip),k,'==');
        if(in>5 && norm(x-xt)/norm(x)<1e-5),break;end
    end
    t2 = clock;

    % <x-y,pi> + 0.5 alpha ||x-y||^2, s.t. ||2y-1||_2^2=n
    % 0.5 alpha ||x-y+pi/alpha||^2, s.t. ||2y-1||_2^2=n
    y = projection_shift(x+pi/alpha);
    
    diff = x-y;
    dist = norm(diff);
    pi = pi + alpha * diff;
    
    f_cur = computeobj(x,W,k);
    his = [his;f_cur];
    
    if(f_min>f_cur)
        f_min = f_cur;
        x_best = x;
    end
    error = norm(diff);
    fprintf('iter:%d, cpu:%f, error:%f(%f), fobj:%f, best:%f, alpha:%f\n',iter,etime(t2,t1),error,dist,f_cur,f_min,alpha);
    
    if(~mod(iter,10))
        alpha = alpha * sqrt(10);
    end
    if(iter>30 && error<0.01),break;end
    
end
x=proj_01k(x_best,k);
fobj =computeobj(x,W,k);






