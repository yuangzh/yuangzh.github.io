function best_t = nonconvex_prox_relu(beta,lambda,a,b,m)
% 0.5 t^2 - beta t - lambda || max(0,t a + b)||_1
% max(0,x) = (x + |x|)/2
% 0.5 t^2 - beta t - 0.5*lambda (|| t a + b||_1 + <1,t a + b>)
% 0.5 t^2 - beta t - 0.5*lambda <1,t a>       - 0.5*lambda (|| t a + b||_1 + <1,t a + b>)

best_t = nonconvex_prox_l1_mex(beta + 0.5*lambda*sum(a),0.5*lambda,a,b,m);
 
% best_t2 = nonconvex_prox_l1(beta + 0.5*lambda*sum(a),0.5*lambda,a,b,m);
% 
% if(abs(best_t2-best_t) > 1e-4*max(1,abs(best_t2)))
%     best_t2
%     best_t
%     ddd
% end
