clc;clear all;close all;
randn('seed',0);rand('seed',0);

lambdas = [0.1:0.5:10];

B_Clean = double(imread('pirate.png'));
B_Corrupted =  double(imread('denoising_pirate_Random-Valued_10.png'));
O = ones(size(B_Clean));
O(B_Corrupted==255)=0;
O(B_Corrupted==0)=0;
B_Clean = B_Clean/255;
B_Corrupted = B_Corrupted/255;
p = 2;
LargestEig = 1;
Amap = @(X)X;
Atmap = @(X)X;
acc = .1/255;
penalty_ratio = 10;
fast_init;
parfor i=1:length(lambdas),
lambda = lambdas(i);
[U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,penalty_ratio,B_Clean);
fprintf('snr0:%f, snr1:%f, snr2:%f\n',snr_l0(U, B_Clean),snr_l1(U, B_Clean),snr_l2(U, B_Clean));
end



B_Clean = double(imread('pirate.png'));
B_Corrupted =  double(imread('denoising_pirate_Salt-and-Pepper_10.png'));
O = ones(size(B_Clean));
O(B_Corrupted==255)=0;
O(B_Corrupted==0)=0;
B_Clean = B_Clean/255;
B_Corrupted = B_Corrupted/255;
p = 2;
LargestEig = 1;
Amap = @(X)X;
Atmap = @(X)X;
acc = .1/255;
penalty_ratio = 10;
fast_init;
parfor i=1:length(lambdas),
lambda = lambdas(i);
[U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,penalty_ratio,B_Clean);
fprintf('snr0:%f, snr1:%f, snr2:%f\n',snr_l0(U, B_Clean),snr_l1(U, B_Clean),snr_l2(U, B_Clean));
end





B_Clean = double(imread('pirate.png'));
B_Corrupted =  double(imread('denoising_pirate_Mixed_10.png'));
O = ones(size(B_Clean));
O(B_Corrupted==255)=0;
O(B_Corrupted==0)=0;
B_Clean = B_Clean/255;
B_Corrupted = B_Corrupted/255;
p = 2;
LargestEig = 1;
Amap = @(X)X;
Atmap = @(X)X;
acc = .1/255;
penalty_ratio = 10;
fast_init;
parfor i=1:length(lambdas),
lambda = lambdas(i);
[U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,penalty_ratio,B_Clean);
fprintf('snr0:%f, snr1:%f, snr2:%f\n',snr_l0(U, B_Clean),snr_l1(U, B_Clean),snr_l2(U, B_Clean));
end

