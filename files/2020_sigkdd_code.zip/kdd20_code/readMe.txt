Run demo.m
