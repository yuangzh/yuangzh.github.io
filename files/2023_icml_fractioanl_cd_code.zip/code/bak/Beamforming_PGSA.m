function [x,his,ts] = Beamforming_PGSA(A,lambda,x,speak,accuracy,MaxTime)
% min_x x'x / ( lambda x'x + min(|Ax|)^2  )

initt = clock;
his = []; ts =[];
fobj =  (x'*x + 1) / ( lambda*x'*x + min(abs(A*x))^2 );

his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = accuracy;
changes = ones(last_k,1)*inf;
fobj_old = fobj;


for iter = 1:50000
    [fobj1,grad] = ComputeObjBeamforming_gx(x,A,lambda);

    fobj = (x'*x + 1) / fobj1;

    % solve the following problem:
    % min_x x'x - fobj*g(x)
    % min_x x'x - fobj*<grad,x>
    % min_x ||x - 0.5*fobj*grad||_2^2
    x = 0.5*fobj*grad;
    if(speak)
    fprintf('iter:%d, fobj:%f\n',iter,fobj);
    end

    his(iter) = fobj;
    ts(iter) = etime(clock,initt);
    
    if etime(clock,initt) > MaxTime,
        break;
    end

    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
    
   
end
