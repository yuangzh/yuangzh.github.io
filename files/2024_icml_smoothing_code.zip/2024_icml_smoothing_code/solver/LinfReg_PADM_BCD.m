function [x,his] = LinfReg_PADM_BCD(A,b,lambda,k,x0)
% min_x 0.5 lambda ||x||_2^2 + ||Ax-b||_1, s.t. ||x||_0 <= k
% min_{x,y} 0.5 lambda ||x||_2^2 + ||y||_1, s.t. Ax-b = y, ||x||_0 <= k
% L(x,y;pi) 0.5 lambda ||x||_2^2 + ||y||_1 + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k


[m,n]=size(A);
x = x0;

y = randn(m,1)*0.01;

beta = 0.001;


HandleObj = @(x)0.5*lambda*x'*x + norm(A*proj_l0(x,k)-b,inf);

HandleObj1 = @(x,y,beta)0.5*lambda*x'*x + norm(y,inf) + 0.5*beta*norm(A*x-b-y)^2;




last_k_out = 30;
changes = ones(last_k_out,1);
fobj_old = 1e10;
stop_accuracy_out = 1e-5;

last_k_tobj = 30;
changes_tobj = ones(last_k_tobj,1);
fobj_old_tobj = 1e10;
stop_accuracy_tobj = 1e-5;

for iter = 1:1000
    % update y
    % ||y||_1 + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
    y = prox_linf(A*x-b,1/beta);
    
    % update x
    % L(x,y;pi) 0.5 lambda ||x||_2^2 + ||y||_1 + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k
    % L(x,y;pi) 0.5 lambda/beta ||x||_2^2 + 0.5||Ax-b-y||_2^2, s.t. ||x||_0 <= k
    max_iter = 300;stop_accuracy = 1e-5; last_k = 50;
    [x] = BlockDecAlg_c(x+1e-20,A,b+y,lambda/beta,k,[8;2],0,max_iter,stop_accuracy,last_k);
    
    
    fobj = HandleObj1(x,y,beta);
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    
    
    diff = A*x - b - y;
    % pi = pi + beta * diff;
    dist = norm(diff);
    
    tfobj = HandleObj(x);
    his(iter) = tfobj;
    
    
    
    rel_change = abs((tfobj - fobj_old_tobj)/max(1,fobj_old_tobj));
    changes_tobj = [changes_tobj(2:end);rel_change];
    fobj_old_tobj = tfobj;
    
    % HandleObj1(x,y,pi,beta)-HandleObj1(x,y,pi,beta/1.1)
    %    beta = (iter)^0.5;
    
    %  if(mean(changes)<stop_accuracy_out),
    if(~mod(iter,10))
      beta = beta*2;
        %  changes = ones(last_k_out,1);
        %  fobj_old = 1e10;
    end
    
    if(mean(changes_tobj)<stop_accuracy_tobj && dist < 0.01),
        break;
    end
    
    
    
    
    
    %    if (~mod(iter,30))
   %        fprintf('iter:%d, dist:%f, fobj:%f, beta:%f, pen fobj:%f\n',iter,dist,HandleObj(x),beta,fobj);
    %     end
    
    
end
