function [x] = projection_shift(a)
% min_{x} ||x-a||_2^2, s.t. ||2x-1||_2^2 = n
% y = 2x-1
% x = (y+1)/2
% min_{y} ||(y+1)/2-a||_2^2, s.t. ||y||_2^2 = n
% min_{y} ||y+1-2a||_2^2, s.t. ||y||_2^2 = n
n = length(a);
y = 2*a-1;
y = sqrt(n)*y/norm(y);
x = (y+1)/2;


