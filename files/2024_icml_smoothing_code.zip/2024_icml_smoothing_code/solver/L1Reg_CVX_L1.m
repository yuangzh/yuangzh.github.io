function [x,fs] = L1Reg_CVX_L1(A,b,lambda,k,x0)
% min_x 0.5 lambda ||x||_2^2 + ||Ax-b||_1, s.t. ||x||_0 <= k 
% min_x 0.5 lambda ||x||_2^2 + ||Ax-b||_1 + sigma ||x||_1

sigmas = 2.^[-10:3:10];

HandleObj = @(x)0.5*lambda*x'*x + norm(A*proj_l0(x,k)-b,1);
n = length(x0);
x = x0;
for is = 1:length(sigmas)

sigma = sigmas(is);


% cvx_precision low
%   cvx_begin quiet
%    variable x(n)
%    minimize(0.5*lambda*x'*x + norm(A*x-b,1) + sigma*norm(x,1))
%    cvx_end
   Index = [];

   [x] = ADMM_subproblem(A,b,lambda,sigma,x0,Index);

   x = proj_l0(x,k);
   fs(is) = HandleObj(x);
   I{is} = find(x==0);
end

[~,ind]=min(fs);
Ibest = I{ind};

%   cvx_begin quiet
%    variable x(n)
%    minimize(0.5*lambda*x'*x + norm(A*x-b,inf) )
%    subject to
%    x(Ibest) == 0;
%    cvx_end
[x] = ADMM_subproblem(A,b,lambda,0,x0,Ibest);

function [x] = ADMM_subproblem(A,b,lambda,sigma,x0,I)
% min_x 0.5*lambda*x'*x + norm(A*x-b,1) + sigma*||x||_1
% min_{x,y} 0.5*lambda*x'*x + norm(y,1) + sigma*||x||_1, s.t. A*x-b = y
% L(x,y,pi) = 0.5*lambda*x'*x + norm(y,1) + sigma*||x||_1 + <Ax-b-y,pi> + 0.5 * beta *||Ax-b-y||_2^2
[m,n] = size(A);
x = x0;
y = 0*randn(m,1);
pi = 0*randn(m,1);
A2 = ComputeLagEigFromA(A);
beta = 0.010;
for iter = 1:300,
% L(x,y,pi) = sigma*||x||_1 + 0.5*lambda*x'*x + <Ax-b-y,pi> + 0.5 * beta *||Ax-b-y||_2^2
grad = lambda*x + A'*pi + beta * A'*(A*x-b-y);
L = lambda + A2*beta;
[x] = prox_l1(x - grad / L,sigma/L);
 x(I) = 0;
% L(x,y,pi) = norm(y,inf) + <Ax-b-y,pi> + 0.5 * beta *||Ax-b-y||_2^2
% L(x,y,pi) = norm(y,inf) + 0.5 * beta *||Ax-b-y + pi/beta||_2^2
y = prox_l1(A*x-b+pi/beta,1/beta);

err = A*x-b-y;
pi = pi + 1.6 *beta *err;
% fobj = 0.5*lambda*x'*x + norm(A*x-b,inf) + sigma*norm(x,1);
% fprintf('iter:%d, err:%f, fobj:%f\n',iter,norm(err),fobj);

if(~mod(iter,30))
    beta = beta*2;
end

if(norm(err)<1e-5),break;end
end


        
