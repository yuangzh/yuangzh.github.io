clc;clear all;close all;
randn('seed',0);rand('seed',0);
addpath('cimg','util','scratched','solvers')

lambda = 0.8;

B_Clean = double(imread(sprintf('barbara.png')));
corrupted_image_name = sprintf('demo_barbara.png');
B_Corrupted =  double(imread(corrupted_image_name));

% Generate the mask matrix O
O = ones(size(B_Clean));
O(B_Corrupted==max(abs(B_Corrupted(:))))=0;
O(B_Corrupted==min(abs(B_Corrupted(:))))=0;

B_Clean = B_Clean/255;
B_Corrupted = B_Corrupted/255;

p = 2;
% denoising problem, identity mapping
Amap = @(X)X;
Atmap = @(X)X;
LargestEig = 1;
acc = 1/255;
penalty_ratio = 10;
[U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,penalty_ratio,B_Clean);
S=ones(size(U))-abs(B_Corrupted-U);
 
figure;
subplot(1,4,1); imshow(B_Clean,[]);title('Original','fontsize',13);
subplot(1,4,2); imshow(B_Corrupted,[]); title('Corrupted','fontsize',13);
subplot(1,4,3); imshow(U,[]); title('Recovered','fontsize',13);
subplot(1,4,4); imshow(S,[]); title('Complement','fontsize',13);

fprintf('(1) SNR of corrupted image. ')
fprintf('SNR0:%.2f, ',snr_l0(B_Corrupted, B_Clean));
fprintf('SNR1:%.2f, ',snr_l1(B_Corrupted, B_Clean));
fprintf('SNR2:%.2f. ',snr_l2(B_Corrupted, B_Clean));
fprintf('\n');
                                             
fprintf('(2) SNR of recovered image. ')
fprintf('SNR0:%.2f, ',snr_l0(U, B_Clean));
fprintf('SNR1:%.2f, ',snr_l1(U, B_Clean));
fprintf('SNR2:%.2f. ',snr_l2(U, B_Clean));
fprintf('\n');



