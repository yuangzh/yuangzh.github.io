README File
=================================================

1. Quick-start
To test the code, we have provided demo Matlab scripts "demo_*.m"

2. Using the code
To reproduce all the experiments in [1], you need to perform the following two steps: (i) run mexC.m (ii) run all the scripts: exp_*.m

3. REFERENCES:
[1] Ganzhao Yuan, Li Shen, Wei-Shi Zheng. A Decomposition Algorithm for the Sparse Generalized Eigenvalue Problem. CVPR 2019.



	 
