clc;clear all;close all;
Q = randn(2); Q=Q*Q';
p = randn(2,1);
u = rand(2,1) ;

% Solve the following two variables box-constrained 
% quadratic programming problem
% min 0.5 x'Qx + p'x
% s.t. 0 <= x <= u, x \in R^{2 x 1}

[x]=quadratic_two_variables (Q,p,u)
quadprog(Q,p,[],[],[],[],[0;0],u) - x