% Lets generate lots of data and plot it
y=[0:0.1:3.0]'*sin(-pi:0.1:pi);
hdlY=plot(y');



% to use some options the standard legend function needs a key
for i=1:8,
    key{i}=sprintf('trace %d',i);
end

% here we place legend on the lefthand side and reduce the fontsize
hdlY=plot(y');


gridLegend(hdlY,2,key,'location','northoutside','Fontsize',8,'Box','off');



