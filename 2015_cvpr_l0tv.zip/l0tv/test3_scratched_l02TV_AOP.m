clc;clear all;close all;
randn('seed',0);rand('seed',0);


addpath('cimg','dimg','util','scratched','solvers')

images = {'cameraman'};
lambda = 15000;
noiselevel = 80;
     
     
% images = {'lenna'};
% lambda = 15000;
% noiselevel = 90;

% images = {'pirate'};
% lambda = 15000;
% noiselevel = 85;


B_Clean = double(imread(sprintf('%s.png',images{1})));

corrupted_image_name = sprintf('%s2.png',images{1});
B_Corrupted =  double(imread(corrupted_image_name));
B_Clean - B_Corrupted
dd

B_Clean = B_Clean/max(B_Clean(:));
B_Corrupted = B_Corrupted/max(B_Corrupted(:));

P = [];
Amap = @(X)functionAX(P,X,'denoising');
Atmap = @(X)functionAX(P',X,'denoising');

%% Yan's Code
uexact = B_Clean;
f = B_Corrupted;
MaxIter=7;
tic
[y nois_ma2] = amf(f*255,39,0,0);

PSNR  =   snr_l0(y, uexact);
str = ['PSNR = ', num2str(PSNR)];
disp(str)

E = y(:)/255 - f(:);
[~, index] = sort(abs(E), 'descend');
thres = max(abs(E(index(floor(1*noiselevel/100*512*512)))),1e-5);
D = (abs(y/255-f)>thres);
D = double(D);
D1 = D;

for i=1:MaxIter
    u = tvinpaint(f,lambda,D,P);
    Au = Amap(u);
    E = Au(:) - f(:);
    [~, index] = sort(abs(E), 'descend');
    thres = abs(E(index(floor(1*noiselevel/100*512*512))));
    D = (abs(Au-f)>thres);
    D = double(D);
    PSNR  =   snr_l0(u, uexact);
    str = ['Iter = ',num2str(i), ', PSNR = ', num2str(PSNR)];
    disp(str)
end
toc

PSNR  =   snr_l0(u, uexact);
PSNR


S=ones(size(u)) - abs(B_Corrupted-u);

close all;
figure;
subplot(1,4,1); imshow(B_Clean,[]);title('Original','fontsize',13);
subplot(1,4,2); imshow(B_Corrupted,[]); title('Corrupted','fontsize',13);
subplot(1,4,3); imshow(u,[]); title('Recovered','fontsize',13);
subplot(1,4,4); imshow(S,[]); title('Recovered2','fontsize',13);



imwrite(u,sprintf('show_recover1_%s_l02tv_aop.png',images{1}));
imwrite(S,sprintf('show_recover2_%s_l02tv_aop.png',images{1}));



% fprintf('SNR0:%.2f, SNR1:%.2f, SNR2:%.2f\n',snr_l0(B_Corrupted, B_Clean),snr_l1(B_Corrupted, B_Clean),snr_l2(B_Corrupted, B_Clean));
% fprintf('SNR0:%.2f, SNR1:%.2f, SNR2:%.2f\n',snr_l0(u, B_Clean),snr_l1(u, B_Clean),snr_l2(u, B_Clean));




