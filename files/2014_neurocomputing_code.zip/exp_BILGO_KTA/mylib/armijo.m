function [t,xn,fn,iter]=armijo(x,dir,grad,fobj,f0 )
%
% Jean-Philippe Vert
% June 4, 2006
%
% function [t,xn,fn]=armijo(x0,d,dtg,fct,t0,f0,alpha,beta)
%
% Input:    x0      current point
%           d       search direction (xn=x0+t*d)
%           dtg     dtg=d'*graf(f)(x0)
%           fct     name of a matlab function [f]=fct(x)
%           t0      initial stepsize (usually t0=1)
%           f0      initial objective funtion f0=fct(x0)
%           alpha   constant 0<alpha<0.5 in Armijo condition fn<=f0+alpha*t*dtg
%           beta    constant 0<beta<1 in update rule t=t*beta
%
% Output:   t       stepsize satisfying the Armijo condition
%           xn      new point xn=x0-t*d
%           fn      objective at the new point fn=fct(xn)

dtg=trace(dir'*grad);
dtd=trace(dir'*dir);

c=0.1;
rho=0.5;
L=1;
alpha_hat=1;
% t=sk;
t=1;
xn=x  + t*dir;
[fn] = feval(fobj,xn);
% Backtracking loop
iter=0;
 
while (fn>f0 + c * t * dtg)
    iter=iter+1;
%      fprintf('+')
    t=alpha_hat*rho^iter;
    xn=x +t*dir;
    [fn]=feval(fobj,xn);
end
%  fprintf('%d ',iter)
