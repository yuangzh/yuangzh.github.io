clc;clear all;close all;

randn('seed',0);rand('seed',0);
addpath('cimg','dimg','util','scratched','solvers')

lambda = 0.8;

B_Clean = double(imread(sprintf('barbara.png')));

corrupted_image_name = sprintf('test0_denoising_introduction0.png');
B_Corrupted =  double(imread(corrupted_image_name));

% Generate the mask matrix O
O = ones(size(B_Clean));

O(B_Corrupted==max(abs(B_Corrupted(:))))=0;
O(B_Corrupted==min(abs(B_Corrupted(:))))=0;

B_Clean = B_Clean/max(abs(B_Clean(:)));
B_Corrupted = B_Corrupted/max(abs(B_Corrupted(:)));

p = 2;
P = GenBlurOper;
LargestEig = min(sqrt(sum(abs(P(:))>0)*sum(P(:).*P(:))), sum(abs(P(:))));% Largest Eigenvalue of A'A

Amap = @(X)functionAX(P,X,'denoising');
Atmap = @(X)functionAX(P',X,'denoising');

acc = 1/255;
[U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,B_Clean);
S=ones(size(U)) - abs(B_Corrupted-U);

imwrite(U,sprintf('test0_denoising_introduction1.png'));
imwrite(S,sprintf('test0_denoising_introduction2.png'));



figure;
subplot(1,4,1); imshow(B_Clean,[]);title('Original','fontsize',13);
subplot(1,4,2); imshow(B_Corrupted,[]); title('Corrupted','fontsize',13);
subplot(1,4,3); imshow(U,[]); title('Recovered','fontsize',13);
subplot(1,4,4); imshow(S,[]); title('Complement','fontsize',13);


