function [fobj] = computeobj(x,W,k)
x=proj_01k(x,k);
fobj = - x'*W*x/k;