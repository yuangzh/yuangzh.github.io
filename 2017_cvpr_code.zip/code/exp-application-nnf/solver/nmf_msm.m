function [W,H] = nmf_msm(V,W,H,timelimit,maxiter,omega)
initt = clock;
for iter=1:maxiter,
    W = MSM(H*H',-H*V',W',3,timelimit,initt,omega)';
    H = MSM(W'*W,-W'*V,H,3,timelimit,initt,omega);
    if etime(clock,initt) > timelimit,
        break;
    end
end


% plot(his)
