X = 0:pi/100:0.25*pi;
Y1 = sin(X);
Y2 = cos(X);
Y3 = tan(X);
Y4 = 0.5;
fh = figure('toolbar','none','menubar','none','Units','characters');
Pan1 = uipanel(fh,'Units','normalized','Position',[0 0 0.5 1],'title',...
    'Panel1');
Pan2 = uipanel(fh,'Units','normalized','Position',[0.5 0 0.5 1],'title',...
    'Panel2');
haxes = axes('Parent',Pan2,'Units', 'normalized','Position',...
[0.125 0.1 0.75 0.75]);
hplot = plot(haxes,X,Y1,X,Y2,X,Y3,X,Y4);
xlabel(haxes,'Time (second)');
ylabel(haxes,'Amplitude (meter)');
title(haxes,'Trigonometric functions');
Ley = {'Sine function','Cosine function','Tangent function','Constant'};
legend(haxes,Ley,'Location','SouthOutside');