clc;clear all;close all;

randn('seed',0);rand('seed',0);
addpath('cimg','dimg','util','solvers')


lambdas =  [0.5:0.5:10];

lambdas =  [0.1 0.3 0.5 0.7 0.9 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15];

lambdas = 8;

%   13.3949
noiselevels=[30];
images = {'cameraman'};
noisetypes = {'Random-Valued'};
restorationtypes = {'denoising','deblurring'};
restorationtypes = {'denoising'};


for mmm = 1:length(restorationtypes),
    for kkk = 1:length(images),
        for lll = 1:length(noisetypes),
            noisetype =noisetypes{lll};
            dlmwrite(sprintf('%s.txt',mfilename),datestr(now),'-append','delimiter','%s\t');
            mystr = sprintf('restorationtype:%s, noisetype:%s, image:%s',restorationtypes{mmm},noisetypes{lll},images{kkk});
            dlmwrite(sprintf('%s.txt',mfilename),mystr,'-append','delimiter','%s\t');
            psnrs = zeros(length(lambdas),length(noiselevels));
            psnrs1 = zeros(length(lambdas),length(noiselevels));
            psnrs2 = zeros(length(lambdas),length(noiselevels));
            times1 = zeros(length(lambdas),length(noiselevels));
            for jjj = 1:length(noiselevels),
                for iii = 1:length(lambdas),
                    lambda = lambdas(iii);
                    noiselevel = noiselevels(jjj);
                    B_Clean = double(imread(sprintf('%s.png',images{kkk})));
                    
                    corrupted_image_name = sprintf('%s_%s_%s_%d.png',restorationtypes{mmm},images{kkk},noisetype,noiselevel);
                    B_Corrupted =  double(imread(corrupted_image_name));
                    
                    % Generate the mask matrix O
                    O = ones(size(B_Clean));
                    
                    if(strcmp(noisetype,'Salt-and-Pepper'))
                        O(B_Corrupted==max(abs(B_Corrupted(:))))=0;
                        O(B_Corrupted==min(abs(B_Corrupted(:))))=0;
                    end
                    
                    B_Clean = B_Clean/max(abs(B_Clean(:)));
                    B_Corrupted = B_Corrupted/max(abs(B_Corrupted(:)));
                    
                    p = 2;
                    P = GenBlurOper;
                    LargestEig = min(sqrt(sum(abs(P(:))>0)*sum(P(:).*P(:))), sum(abs(P(:))));% Largest Eigenvalue of A'A
                    
                    Amap = @(X)functionAX(P,X,restorationtypes{mmm});
                    Atmap = @(X)functionAX(P',X,restorationtypes{mmm});
                    
                    acc = 1/255;
                    pen_ratio = 10;
                    tic;
                    [U] = l0tv_padmm_color_for_plot_fobj(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,B_Clean,pen_ratio);
                    psnrs(iii,jjj)  = snr_l0(U, B_Clean);
                    psnrs1(iii,jjj) = snr_l1(U, B_Clean);
                    psnrs2(iii,jjj) = snr_l2(U, B_Clean);
                    time111 = toc;
                    time111
                    times1(iii,jjj) = time111;
                    psnrs
                    psnrs1
                    psnrs2
                    imwrite(U,sprintf('lenna_recover_l02tv.png'));
                    
%                     figure;
%                     subplot(1,3,1); imshow(B_Clean,[]);title('Original','fontsize',13);
%                     subplot(1,3,2); imshow(B_Corrupted,[]); title('Corrupted','fontsize',13);
%                     subplot(1,3,3); imshow(U,[]); title('Recovered','fontsize',13);
                end
            end
            
            
            
        end
    end
end


