function [y_test] = knnclassify(x_test, x_train, y_train,K,L)
% KNNCLASS k-Nearest Neighbours classifier.
% Description:
%  The input feature vectors X are classified using the K-NN
%  rule defined by the input model.
% 
% Input:
%  x_test: N x dim
% x_train: M x dim
% y_train: M x 1
% Output:
%  y_test: N x 1
%

% K=1;

[ntest,dim]=size(x_test);
[ntrain,dim]=size(x_train);
 
y_test=zeros(ntest,1);
for i=1:ntest,

    %�����i������������ÿһ��ѵ������֮��ľ���
    for j=1:ntrain,
     dist(j) = user_def_dist (x_test(i,:),x_train(j,:),L);
    end

  
    %�������K����ı�ǩ���洢��max_labels������
   for l=1:K,
      max_dist=inf;
      for j=1:ntrain,
        if( max_dist > dist(j)) 
          max_inx = j;
          max_dist = dist(j);
        end   
      end
      
      dist(max_inx) = inf;
      max_labels(l) = y_train(max_inx);
   end
 

    best_count=0;
    for l=1:K,
      count = 0;
      for j=1:K,if( max_labels(l) == max_labels(j)), count=count+1;end ,end      
      if( count > best_count ),best_count = count;best_label = max_labels(l);end
    end    

    y_test(i) = best_label;
    
end
 
function y = user_def_dist(x1,x2,L)
y= norm((x1-x2)*L);
if(abs(y)<0.00000001),y=1e10; end

