clc;clear all;close all;
addpath('util');

load('result_demo_box.mat');   box = result;
load('result_demo_feige.mat'); feige = result;
load('result_demo_ravi.mat');  ravi = result;
load('result_demo_tpm.mat');   tpm = result;
load('result_demo_mpec_epm.mat');   epm = result;
load('result_demo_mpec_adm.mat');   adm = result;
load('result_demo_l2box_admm.mat');  diadm = result;



xData = [100 1000:1000:5000];
for idata=1:8,

for i=1:length(xData)
    yData{1}(i) = -box{idata,i}.obj;
    yData{2}(i) = -feige{idata,i}.obj;
    yData{3}(i) = -ravi{idata,i}.obj;
    yData{4}(i) = -tpm{idata,i}.obj;
    yData{5}(i) = -diadm{idata,i}.obj;
    yData{6}(i) = -epm{idata,i}.obj;
%     yData{7}(i) = -adm{idata,i}.obj;
end


options=loadopt;
options.logScale = 0;
options.xlabel = 'cardinality';
options.ylabel = 'density';
options.legend = {'LP','FEIGE','RAVI','TPM','L2box-ADMM','MPEC-EPM'};

% legendLoc
options.labelRotate = 1;
options.labelLines=0;
h=figure;
h2=prettyPlot(xData,yData,options);
 

min_x = min(xData)*0.9;
max_x = max(xData)*1.05;
min_y = min(getalldata(yData))*0.9;
max_y = max(getalldata(yData))*1.05;
axis([min_x,max_x,min_y,max_y]);
set(gca,'XTick',xData)
print( '-dpsc',sprintf('%s_%d.eps',mfilename,idata));
% print( '-dpng',sprintf('%s_%d.png',mfilename,idata));

set(h, 'Position', [0 0 1000 500])
h1 = legend(h2,options.legend);
set(h1,'Location','northoutside','Orientation','horizontal'); %Best
axis off
h2 = findobj(gca,'Type','line');
set(h2, 'visible', 'off');
namestr = sprintf('%s_legend.png',mfilename);
print( '-dpng',namestr);

close all;

end