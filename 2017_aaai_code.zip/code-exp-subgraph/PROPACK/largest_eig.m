function [value] = largest_eig(A,acc)
if(nargin<2)
    acc = 0.01;
end
options=[];
options.tol = acc;
[vector,value] = laneig(A,1,'AL',options);
