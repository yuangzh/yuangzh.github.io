function best_t = nonconvex_prox_l1(beta,lambda,a,b,m)
% 0.5 t^2 - beta t - lambda || t a + b||_1
% 0.5 (t-beta)^2 - lambda || t a + b||_1
% HandleObj = @(t)ComputeObj1d(t,beta,lambda,a,b);
% best_t = fminsearch(HandleObj,0);


I = (a==0);
a(I)=[];b(I)=[];
m = length(a);

c = abs(b)./abs(a);
c = sort(c);
c = [-1e10;-flip(c);c;1e10];
lenc = length(c);


his= [];
ts = [];
for i = 1:(lenc-1)
    tt = (c(i)+c(i+1)) / 2;
    t  = beta + lambda * sign(tt*a+b)'*a;
    ft = 0.5*(t-beta)^2 - lambda*norm(t*a+b,1);
    his(i) = ft;
    ts(i) = t;
end
% figure;plot(his)
[~,ind]=min(his);
best_t = ts(ind);

