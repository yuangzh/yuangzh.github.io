function [r] = trim_(a)
% a = 'abc_defg';
% trim_1(a)
% output: defg

pos=findstr(a,'_');
r = a((pos+1):end);