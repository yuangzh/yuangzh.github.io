function test_nonconvex_prox_l1_c
clc;clear all;close all;
% 0.5 (t-beta)^2 - lambda || t a + b||_1

for iter = 1:100000000
    m = 10;
    beta = randn(1)*100*rand(1) ;
    a = randn(m,1)*100*rand(1)  + 1i * randn(m,1)*100*rand(1);
    b = randn(m,1)*100*rand(1) + 1i *randn(m,1)*100*rand(1);
    lambda = rand(1)*100*rand(1);
    HandleObj = @(t) ComputeObj(t,beta,lambda,a,b);
    x1 = fminsearch(HandleObj,0);


[fff,ggg]=HandleObj(x1)
ddd
    x2 = nonconvex_prox_l1_c(beta,lambda,a,b);
    x2
    ddd
    f1 = HandleObj(x1);
    f2 = HandleObj(x2);
    
    
    
    fprintf('iter:%f, fobj:%.5e %.5e\n',iter,f1,f2);
    
    if(f2>f1 + 1e-6*abs(mean([f1;f2])))
        x1
        x2
        dddd
    end
    
    
end



function [x] = solve_by_grid(beta,lambda,a,b)
HandleObj = @(t) ComputeObj(t,beta,lambda,a,b);
xs = [-200:0.001:201];
for i = 1:length(xs)
    [fs(i)] = HandleObj(xs(i));
end
[~,ind]=min(fs);
x=xs(ind);


function [fobj,grad] = ComputeObj(t,beta,lambda,a,b)
fobj = 0.5*(t-beta)^2 - lambda*norm(t*a+b,1);
t*a+b
sign(t*a+b)
dd
grad = t-beta - lambda*sign(t*a+b)'*a;
% grad = t-beta - lambda*sign(t*sign(a)+b/norm(a))'*a;


function best_t = nonconvex_prox_l1_c(beta,lambda,a,b)
% 0.5 t^2 - beta t - lambda || t a + b||_1
% 0.5 (t-beta)^2 - lambda || t a + b||_1
% HandleObj = @(t)ComputeObj1d(t,beta,lambda,a,b);
% best_t = fminsearch(HandleObj,0);
% return;
n = length(a);
c = b./abs(a);

[c,ind]=sort([c;-c]);
c = [-inf;c;inf];

best_fobj = inf;
his= [];
for i = 1:(length(c)-1)
    tt = (c(i)+c(i+1)) / 2;
    t  = beta + lambda * sign(tt*a+b)'*a;
    test_obj = ComputeObj1d(t,beta,lambda,a,b);
    his(i) = test_obj;
    if(test_obj<best_fobj)
        best_fobj = test_obj;
        best_t = t;
    end
end
% best_t
% plot(his)
% pause
% grad = best_t-beta - lambda*sign(best_t*a+b)'*a;
% grad

function [fobj,grad] = ComputeObj1d(t,beta,lambda,a,b)
fobj = 0.5*(t-beta)^2 - lambda*norm(t*a+b,1);
grad = t-beta - lambda*sign(t*a+b)'*a;
