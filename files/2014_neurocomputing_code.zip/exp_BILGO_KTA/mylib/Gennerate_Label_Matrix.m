function [label_mat]= Gennerate_Label_Matrix(y)
mysets=unique(y);
n=length(y);
class_count=length(mysets);
label_mat=zeros(n,class_count);
for i=1:n,
    for j=1:class_count,
    if(y(i)==mysets(j)),label_mat(i,j)=1;end;
    end;    
end;