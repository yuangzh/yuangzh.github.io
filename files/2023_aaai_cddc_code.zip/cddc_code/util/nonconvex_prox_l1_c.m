function best_t = nonconvex_prox_l1(beta,lambda,a,b)
% 0.5 t^2 - beta t - lambda || t a + b||_1
% 0.5 (t-beta)^2 - lambda || t a + b||_1
% HandleObj = @(t)ComputeObj1d(t,beta,lambda,a,b);
% best_t = fminsearch(HandleObj,0);
% return;
n = length(a);
c = b./abs(a);
[c,ind]=sort([c;-c]);
c = [-inf;c;inf];

best_fobj = inf;
his= [];
for i = 1:(length(c)-1)
    tt = (c(i)+c(i+1)) / 2;
    t  = beta + lambda * sign(tt*a+b)'*a;
    test_obj = ComputeObj1d(t,beta,lambda,a,b);
    his(i) = test_obj;
    if(test_obj<best_fobj)
        best_fobj = test_obj;
        best_t = t;
    end
end
% best_t
% plot(his)
% pause
% grad = best_t-beta - lambda*sign(best_t*a+b)'*a;
% grad

function [fobj,grad] = ComputeObj1d(t,beta,lambda,a,b)
fobj = 0.5*(t-beta)^2 - lambda*norm(t*a+b,1);
grad = t-beta - lambda*sign(t*a+b)'*a;
