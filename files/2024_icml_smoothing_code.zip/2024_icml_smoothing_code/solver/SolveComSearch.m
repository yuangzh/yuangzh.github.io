function [x_best,xs,fs] = SolveComSearch(A,b,k)
% Solve the following optimization problem:
% min_x ||Ax-b||_1, s.t. ||x||_0 = k
[m,n]=size(A);
P = combs([1:n],k);

HandleObj = @(x)norm(A*x-b,1);

if(k==0)
    x_best = zeros(n,1);
    
    return;
end

for iter=1:size(P,1)
%    fprintf('%d %d\n',iter,size(P,1));
   p = P(iter,:);
   p1 = setdiff([1:n],p);
   cvx_begin quiet
   variable x(n)
   minimize( norm(A*x-b,1) )
   subject to
   x(p1) == 0
   cvx_end
   x_cur = x;
   curr_obj = HandleObj(x_cur);
      fs(iter) = curr_obj;
      xs{iter} = x_cur;
   if(iter==1)
       x_best = x_cur;
       best_obj = curr_obj;
   end
   if(curr_obj<best_obj)
       x_best = x_cur;
       best_obj = curr_obj;
   end
end

