function [fobj,grad] = ComputeObjBeamforming_gx(x,A,lambda)
% g(x) = lambda x'x + min(|Ax|)^2 
abs_Ax = abs(A*x);
[min_abs_Ax,index] = min(abs_Ax);
a = A(index,:);
fobj  = lambda*x'*x + min_abs_Ax*min_abs_Ax;
grad = lambda*2*x + 2*a*a'*x;
