function [x,his] = LinfReg_ProjSubGrad_IHT(A,b,lambda,k,x0)
% min_x ||Ax-b||_inf, s.t. ||x||_0 <= k 
% min_{x,y} ||y||_inf, s.t. Ax-b = y, ||x||_0 <= k 
% L(x,y;pi) ||y||_inf + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k


[m,n]=size(A);
x = x0;

HandleObj = @(x)0.5*lambda*x'*x + norm(A*proj_l0(x,k)-b,inf);

for iter = 1:3000


err = A*x - b;
[~,ind]=max(abs(err));
diff = zeros(size(err));
diff(ind) = err(ind);
subgrad = lambda * x + A'*diff;
x = x - subgrad * 0.01 / iter;
x = proj_l0(x,k);
if(norm(x)>1e10),
    x = x./norm(x);
end
tfobj = HandleObj(x);
his(iter) = tfobj;

% fprintf('%f\n',tfobj);
 
%     rel_change = abs((tfobj - fobj_old_tobj)/max(1,fobj_old_tobj));
%     changes_tobj = [changes_tobj(2:end);rel_change];
%     fobj_old_tobj = tfobj;
    
% HandleObj1(x,y,pi,beta)-HandleObj1(x,y,pi,beta/1.1)
%    beta = (iter)^0.5;

%  if(mean(changes)<stop_accuracy_out),


% if(mean(changes_tobj)<stop_accuracy_tobj && dist < 0.01),
% break;
% end


end


% plot(his)