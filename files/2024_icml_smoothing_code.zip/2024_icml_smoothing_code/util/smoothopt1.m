function [x]=smoothopt1(x,HandleObj)
for iter = 1:10,
    [fobj_cur,grad_cur]=HandleObj(x);
    fprintf('it:%d obj:%f norm:%e \n',iter,fobj_cur,norm(grad_cur,'fro'))
    if(iter==1)
        direction= - grad_cur ;
    else
        beta=  trace(grad_cur'*(grad_cur-grad_old)) / trace(grad_old'*grad_old);            % PRP
        beta(beta<0)=0;
        direction= - grad_cur + beta *   direction;
    end
    gtd = trace(direction'*grad_cur);
    if(gtd>1e-12),
        gtd
        error('NonDesc')
    end
    grad_old = grad_cur;
    HandleObjLineSearch = @(t)HandleObj(x+t*direction);
    [stepsize] = gss(HandleObjLineSearch,0,1,1e-12,1e10,0);
    x=x+stepsize*direction;
end;










function [a,b] = gss(HandleObjLineSearch,a,b,eps,N,verb)
%
% Performs golden section search on the function f.
% Assumptions: f is continuous on [a,b]; and
% f has only one minimum in [a,b].
% No more than N function evaluations are done.
% When b-a < eps, the iteration stops.
%
% Example: [a,b] = gss('myfun',0,1,0.01,20)
%
c = (-1+sqrt(5))/2;
x1 = c*a + (1-c)*b;
fx1 = HandleObjLineSearch(x1);
x2 = (1-c)*a + c*b;
fx2 = HandleObjLineSearch(x2);

if(verb)
    fprintf('------------------------------------------------------\n');
    fprintf(' x1 x2 f(x1) f(x2) b - a\n');
    fprintf('------------------------------------------------------\n');
    fprintf('%.4e %.4e %.4e %.4e %.4e\n', x1, x2, fx1, fx2, b-a);
end
for i = 1:N-2
    if fx1 < fx2
        b = x2;
        x2 = x1;
        fx2 = fx1;
        x1 = c*a + (1-c)*b;
        fx1 = HandleObjLineSearch(x1);
    else
        a = x1;
        x1 = x2;
        fx1 = fx2;
        x2 = (1-c)*a + c*b;
        fx2 = HandleObjLineSearch(x2);
    end;if(verb)
        fprintf('%.4e %.4e %.4e %.4e %.4e\n', x1, x2, fx1, fx2, b-a);end
    if (abs(b-a) < eps)
        if(verb)
            fprintf('succeeded after %d steps\n', i);
        end
        return;
    end;
end;
if(verb)
    fprintf('failed requirements after %d steps\n', N);
end