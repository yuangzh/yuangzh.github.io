function test_global_opt
clc;clear all;close all;
% 0.5 (t-beta)^2 - lambda || t a + b||_2
for iter = 1:100000000
    m = 10;
    beta = randn(1)*100*rand(1);
    a = randn(m,1)*100*rand(1);
    b = randn(m,1)*100*rand(1);
    lambda = rand(1)*100*rand(1);
    HandleObj = @(t) ComputeObj(t,beta,lambda,a,b);
    x1 = fminsearch(HandleObj,0);

    x2 = concave_prox_l2(beta,lambda,a,b);
    f1 = HandleObj(x1);
    f2 = HandleObj(x2);
    
    
    
    fprintf('iter:%f, fobj:%.5e %.5e\n',iter,f1,f2);
    
    if(f2>f1 + 1e-6*abs(mean([f1;f2])))
        x1
        x2
        dddd
    end
    
    
end


function [fobj,grad] = ComputeObj(t,beta,lambda,a,b)
fobj = 0.5*(t-beta)^2 - lambda*norm(t*a+b,2);
grad = t-beta - lambda*( (t*a+b) / norm(t*a+b) )'*a;
% grad = t-beta - lambda*sign(t*sign(a)+b/norm(a))'*a;


