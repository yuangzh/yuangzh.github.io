function demo_acc_DCSparseOpt
% min_x 0.5 ||Ax-b||_2^2  + lambda (||x||_1 - ||x||_{top_k})
% min_x min_v 0.5 ||Ax-b||_2^2  + lambda ||x||_1 - lambda <x,v>, v \in {-1,+1}, ||v'||_1 \leq k
clc;clear all;close all;
addpath('util');
rand('seed',0);
randn('seed',0);

id_data = [11 12 13 14 21 22 23 24 31 32 33 34 41 42 43 44];

times = 10;
result = [];
for idat = 1:length(id_data)
    
    avg_his1 = [];
    avg_his2 = [];
    avg_his3 = [];
    avg_his4 = [];
    avg_his5 = [];
    for it = 1:times,
        % Main Algorithms
        G = getdata_pca(id_data(idat));
        y = generate_y_DCSparseOpt(G);
        x0 = 0.001*randn(size(G,2),1);
        lambda = 1;
        k  = 100;
        MaxTime = 100;
        [x1,his1,ts1] = MSCR(G,y,x0,lambda,k,MaxTime);
        [x2,his2,ts2] = Linearized_MSCR(G,y,x0,lambda,k,MaxTime);
        [x3,his3,ts3] = SubGradient(G,y,x0,lambda,k,MaxTime);
        [x4,his4,ts4] = CD_SCA(G,y,x0,lambda,k,MaxTime);
        [x5,his5,ts5] = CD_SNCA(G,y,x0,lambda,k,MaxTime);
        
        % Scale the objectives if they are negative
%         CCC = min([his1(:);his2(:);his3(:);his4(:);his5(:)])+eps;
%         CCC = min(0,CCC); his1=his1+CCC; his2=his2+CCC; his3=his3+CCC; his4=his4+CCC; his5=his5+CCC;
        
        avg_his1(it) = min(his1); avg_his2(it) = min(his2); avg_his3(it) = min(his3); avg_his4(it) = min(his4); avg_his5(it) = min(his5);
        
    end
    
    One = [];
    One.his1 = [mean(avg_his1);std(avg_his1)];
    One.his2 = [mean(avg_his2);std(avg_his2)];
    One.his3 = [mean(avg_his3);std(avg_his3)];
    One.his4 = [mean(avg_his4);std(avg_his4)];
    One.his5 = [mean(avg_his5);std(avg_his5)];
    result{idat} = One; save(mfilename,'result')
    
    
    
    % Print
%     fprintf('result:\n');
%     fprintf('Alg 1: %f %f\n',mean(avg_his1),std(avg_his1));
%     fprintf('Alg 2: %f %f\n',mean(avg_his2),std(avg_his2));
%     fprintf('Alg 3: %f %f\n',mean(avg_his3),std(avg_his3));
%     fprintf('Alg 4: %f %f\n',mean(avg_his4),std(avg_his4));
%     fprintf('Alg 5: %f %f\n',mean(avg_his5),std(avg_his5));
%     fprintf('\n');

    fprintf('%s & ',GetDataStr(idat));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his1),std(avg_his1));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his2),std(avg_his2));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his3),std(avg_his3));
    fprintf('%.3f $\\pm$ %.3f & ',mean(avg_his4),std(avg_his4));
    fprintf('%.3f $\\pm$ %.3f  ',mean(avg_his5),std(avg_his5));
    fprintf('\\\\');
    fprintf('\n');
     
end

function [x,his,ts] = SubGradient(G,y,x0,lambda,k,MaxTime)
% min_x 0.5 ||Gx-y||_2^2  + lambda (||x||_1 - ||x||_{top_k})

initt = clock;
[m,n] = size(G);
x = x0;
his = [];
ts = [];

fobj = ComputeObj(x,G,y,lambda,k);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter = 1:10000
    
    [~,ind]=topksum(x,k);
    w = zeros(n,1);
    w(ind) = 1;
    subgrad = mysign(x).*w;
    
    grad = G'*(G*x-y) + lambda * sign(x) - lambda*subgrad;
    step = 1/sqrt(iter);
    x = x - step*grad;
    
    fobj = ComputeObj(x,G,y,lambda,k);
%     fprintf('iter:%d, fobj:%f, normG:%f\n',iter,fobj,0);
    
    
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
    
end



function [x,his,ts] = CD_SCA(G,y,x0,lambda,k,MaxTime)
% min_x 0.5 ||Gx-y||_2^2  + lambda (||x||_1 - ||x||_{top_k})
% min_x 0.5 ||Gx-y||_2^2  + lambda (||x||_1 - ||x||_{top_k})
% 0.5 x'Qx - <x,G'y> + lambda (||x||_1 - ||x||_{top_k})

initt = clock;

x = x0;
his = []; ts=[];
n = length(x0);

gg = sum(G.*G,1)'+1e-10;
Gy = G'*y;
Gx = G*x;
const = 0.5*y'*y;
fobj = Gx'*(0.5*Gx-y) + const + lambda * norm(x,1) - lambda*topksum(x,k);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter = 1:1e10
    %     i = randperm(n,1);
    i = mod(iter,n)+1;
    %     ei = zeros(n,1);
    %     ei(i)=1;
    
    %     grad = A'*(A*x-b);
    
    [v] = solve_v(x,k);
    subgrad_minus_g = - lambda*v;
    %   Qx = Q*x;
    Qx_i = Gx'*G(:,i);
    
    
    
    % min_t 0.5 (x+tei)'Q(x+tei) + <x+tei,p> + lambda || x+tei||_1 + <x+tei, subgrad_minus_g>
    % min_t 0.5 Q(i,i) t^2 + ((Qx)_i + p_i +subgrad_minus_g_i ) t+ lambda || x+tei||_1
    cof_b = Qx_i - Gy(i) + subgrad_minus_g(i);
    % min_t 0.5 Q(i,i) t^2 + cof_b t+ lambda | x(i) + t |_1
    % x(i) + t = theta
    % min_theta 0.5 Q(i,i) (theta-x(i))^2 + cof_b (theta-x(i)) + lambda | theta |_1
    % min_theta 0.5 (theta-x(i))^2 + cof_b/Q(i,i) theta + lambda/Q(i,i) | theta |_1
    % min_theta 0.5 theta^2 - x(i)*theta + cof_b/Q(i,i) theta + lambda/Q(i,i) | theta |_1
    
    theta = prox_l1(x(i)-cof_b/gg(i),lambda/gg(i));
    t = theta - x(i);
    
    x(i) = x(i)+t;
    Gx = Gx + t*G(:,i);
    
    %     fobj = ComputeObj(x,G,y,lambda,k);
    %     grad = A'*(A*x-b) + lambda*sign(x) - lambda*solve_v(x,k);
    fobj = Gx'*(0.5*Gx-y) + const + lambda*norm(x,1) - lambda*topksum(x,k);
    % fprintf('iter:%d, fobj:%f \n',iter,fobj);
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end

function [x,his,ts] = CD_SNCA(G,y,x0,lambda,k,MaxTime)
% min_x 0.5 ||Gx-y||_2^2  + lambda (||x||_1 - ||x||_{top_k})
% min_x 0.5x'G'Gx - <Gx,y> + lambda (||x||_1 - ||x||_{top_k})
% 0.5 t^2 + g_i/L t + lambda/L (||x+tei||_1 - ||x+tei||_{top_k})
initt = clock;
x = x0;
his = []; ts = [];
n = length(x0);



gg = sum(G.*G,1)'+1e-10;
Gy = G'*y;
Gx = G*x;
const = 0.5*y'*y;
fobj = Gx'*(0.5*Gx-y) + const + lambda * norm(x,1) - lambda*topksum(x,k);
his = [his;fobj];
ts = [ts;etime(clock,initt)];


last_k = 100;
stop_accuracy = 1e-14;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter = 1:1e10
    %     i = randperm(n,1);
    i = mod(iter,n)+1;
    %     ei = zeros(n,1);
    %     ei(i)=1;
    %     HaneleObj = @(t)ComputeObj(x+t*ei,G,y,lambda,k);
    %     t = fminsearch(HaneleObj,0);
    
    % 0.5 t^2 + g_i/L t + + lambda/L (||x+tei||_1 - ||x+tei||_{top_k})
    
    %     grad = G'*(G*x-y);
    %     grad_i = grad(i);
    
    d = G(:,i);
    grad_i = Gx'*d - Gy(i);
    
    
    t = nonconvex_prox_l1topk(-grad_i/gg(i),lambda/gg(i),x,i,k);
    % min_t 0.5 t^2 - beta t + lambda ||x+tei||_1 - lambda || x+tei ||_{top-k}
    
    
    x(i) = x(i)+t;
    Gx = Gx + t*G(:,i);
    
    fobj = Gx'*(0.5*Gx-y) + const + lambda*norm(x,1) - lambda*topksum(x,k);
    
    
    %     grad = G'*(G*x-y) + lambda*sign(x) - lambda*solve_v(x,k);
    %     ,norm(grad)
%         fprintf('iter:%d, fobj:%f\n',iter,fobj);
    
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end


function [x,his,ts] = Linearized_MSCR(G,y,x0,lambda,k,MaxTime)
% min_x 0.5 ||Gx-y||_2^2  + lambda (||x||_1 - ||x||_{top_k})
% min_x min_y 0.5 ||Gx-y||_2^2  + lambda (||x||_1 - <x,y>), s.t. -1<=y<=1, ||y||_1 \leq k

initt = clock;
x = x0;
his = [];
ts = [];

[m,n] = size(G);
L = SpectralNorm(G);

fobj = ComputeObj(x,G,y,lambda,k);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;

for iter = 1:1e10
    v = solve_v(x,k);
    c = - lambda*v;
    % x = convex_subproblem(x,A,b,lambda,c);
    % min_x 0.5 ||Ax-b||_2^2 + x'c  + lambda ||x||_1
    
    
    grad = G'*(G*x-y)+c;
    x = prox_l1(x-grad/L,lambda/L);
    
    
    fobj = ComputeObj(x,G,y,lambda,k);
%     fprintf('iter:%d, fobj:%f\n',iter,fobj);
    
    
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end


function [x,his,ts] = MSCR(G,y,x0,lambda,k,MaxTime)
% min_x 0.5 ||Ax-b||_2^2  + lambda (||x||_1 - ||x||_{top_k})
% min_x min_y 0.5 ||Ax-b||_2^2  + lambda (||x||_1 - <x,y>), s.t. -1<=y<=1, ||y||_1 \leq k

initt = clock;
x = x0;
his = [];
ts = [];

[m,n] = size(G);
L = SpectralNorm(G);

fobj = ComputeObj(x,G,y,lambda,k);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter = 1:1e10
    v = solve_v(x,k);
    subgrad_minus_g = - lambda*v;
    % x = convex_subproblem(x,A,b,lambda,c);
    % min_x 0.5 ||Gx-y||_2^2 + x'c  + lambda ||x||_1
    
    for it = 1:100
        grad = G'*(G*x-y)+subgrad_minus_g;
        x = prox_l1(x-grad/L,lambda/L);
    end
    
    fobj = ComputeObj(x,G,y,lambda,k);
%     fprintf('iter:%d, fobj:%f\n',iter,fobj);
    
    
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end
% plot(his)
% dddd
function [fobj] = ComputeObj(x,A,b,lambda,k)
fobj = 0.5*norm(A*x-b)^2 + lambda*norm(x,1) - lambda*topksum(x,k);

function [v] = solve_v(x,k)
% min_v  -<x,v>, s.t. v \in {-1,+1}, ||v'||_1 \leq k
% v = sign(x)w;
% min_w <abs(x),w>, s.t. w \in {0,1}, sum(w)=k
n = length(x);
[~,ind]=sort(abs(x),'descend');
w = zeros(n,1);
w(ind(1:k))=1;
v = mysign(x).*w;








