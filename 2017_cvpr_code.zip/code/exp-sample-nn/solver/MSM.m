function [X,his] = MSM(A,b,const,lambda,X,max_iter,timelimit,omega)
% 0.5*trace(X'*A*X) + <B,X> + g(X)
% where g(x) is an indication function on the box constraint, i.e. g(x) = I_{>=0}  (x)
% X: n x d
% A: n x n
% B: n x d
initt = clock;
[n,d] = size(b);
L = tril(A,-1); 
D = diag(diag(A)); 
I = speye(n);
theta = 0.01;


his=[]; 
HandleObj = @(X)sum(sum(X.*(A*X)))/2 + sum(sum(b.*X)) + lambda * sum(abs(X(:)))+const;

B = omega*L + D + theta*I;
C = omega*L' + (omega-1)*D - theta*I;
 
for iter = 1:max_iter,
   fobj = HandleObj(X); fprintf('iter:%d, fobj:%f\n',iter,fobj); his = [his;fobj];
   if(etime(clock,initt)>timelimit),break;end
   % Solve the following non-linear system:
   % Bx + p + sub_diff(g(x)) = 0;
   X = linf_triangle_subproblem(B,omega*b+C*X,lambda,n,d);
%  [X] = l0_triangle_subproblem_matlab(B,omega*b+C*X,lambda);
end



function [x] = l0_triangle_subproblem_matlab(B,p,lambda)
% This program solves the following proximal equation:
% Bx + p + sub_diff(g(x)) = 0;
% where B is a lower triangular matrix and f = lambda|x|_1
% where B is a lower triangular matrix, b is vector n x 1
% B = [B11  0   0   0   0   ; 
%      B21 B22  0   0   0   ;
%      B31 B32 B33  0   0   ;
%      B41 B42 B43 B44  0   ;
%      B51 B52 B53 B54 B55  ];
%
n = length(p);
x = zeros(n,1);
for i=1:n,
    tot=0;
    for j=1:(i-1),
        tot = tot + B(i,j)*x(j);
    end
    b1 = tot + p(i);
    x(i) = one_dim(B(i,i),b1,lambda);
end
 



 function [r] = one_dim(a,b,lambda)
r = max(0,-b/a);




