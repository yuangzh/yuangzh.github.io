function [noiselevels,images,noisetypes,restorationtypes,Rs] = load_parameters_deblurring_varying_radius
noiselevels = [30 50 70];
images = {'lenna','cameraman','barbara','boat','pirate'};
noisetypes = {'Random-Valued','Salt-and-Pepper','Mixed'};
restorationtypes = {'denoising','deblurring'};
restorationtypes = {'deblurring'};
% Rs = [1:2:30];


load_Rs;
images = {'lenna','cameraman','barbara','boat'};
