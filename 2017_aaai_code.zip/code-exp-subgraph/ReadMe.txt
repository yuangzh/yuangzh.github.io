README File
=================================================
1. Running the Code
To reproduce the dense subgraph finding experiments in [1], you need to run the scripts: demo*.m


2. Directory Tree
We demonstrate the directory tree of our code, including the names of some main functions and their descriptions.

------ solver
   |     |
   |     |---- dsf_box.m            : LP relaxation for dense subgraph discovery
   |     |---- dsf_tpm.m            : truncated power method for dense subgraph discovery (this is an iterative hard thresholding algorithm)
   |     |---- dsf_ravi.m           : Ravi's greedy algorithm for dense subgraph discovery
   |     |---- dsf_feige.m          : Feige's greedy algorithm for dense subgraph discovery
   |     |---- dsf_l2box_admm.m     : direct ADMM on the l2-box reformulation for dense subgraph discovery
   |     |---- dsf_mpec_adm.m       : direct ADMM on the l2-box MPEC reformulation for dense subgraph discovery
   |     |---- dsf_mpec_epm.m       : Exact Pentlaty Method on the l2-box MPEC reformulation for dense subgraph discovery
   |     |---- QP_rank1.m           : nearly closed-form solution for solving the simple rank1 QP involved in dsf_mpec_adm.m (QP: min_{x} 0.5*x'*(gamma I+b*b')*x+c'*x, s.t. ||x|| <= R)
   |     |---- BreakPointSearch.m   : break point search algorithm (see A polynomially bounded algorithm for a singly constrained quadratic program. Mathematical Programming, 1980) to solve the capped simpelx subproblem (QP: 0.5*||x-a||^2, s.t. sum(x) <= s,  0 <= x <= 1)
   |
   |
------ util
   |     |
   |     |---- proj_01k.m           : top-k binary projection step, it solves: min_{x \in {0,1}, sum(x) = k} ||x-a||_2^2
   |     |---- computeobj.m         : compute the objective value for dense subgraph discovery: f(x) = - x'*W*x/k (the smaller, the better)
   |     |---- projection_shift.m   : l2 ball projection, it solves: min_{x} ||x-a||_2^2, s.t. ||2x-1||_2^2 = n 
   |     |---- print_statistic.m    : print the statistic information of all the datasets
   |     |---- read_dataset_and_k.m : define the datasets and the range for parameter k
   |       
   |       
------ data
   |     |
   |     |---- 8 datasets used in the experiments
   |
   |
------ bvgraph
   |     |
   |     |---- a package used to read the graph file which takes two files {*.graph, *.properties}
   |
   |
------ PROPACK
   |     |
   |     |---- an efficient and robust Matlab package to find the leading eigenvalue of a symmetrix matrix (often better than 'eigs')
   |
   |   
------ plot_figure
         |
         |---- plot the figures in our paper
		 
	 
3. REFERENCES:
[1] An Exact Penalty Method for Binary Optimization Based on MPEC Formulation. Submitted to AAAI 2017. (Full version: Binary Optimization via Mathematical Programming with Equilibrium Constraints)


	 
