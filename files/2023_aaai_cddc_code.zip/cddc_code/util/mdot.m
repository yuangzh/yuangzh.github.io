function [r] = mdot(x,y)
r = sum(sum(x.*y));