function [acc1,acc2]= testAcc(L,x,y,tx,ty)
%fprintf('classify begin:.. ');
[results]=lmnnclassify (L',x',y',tx',ty',3,1);
acc1 = results(2)*100;
acc2 = results(1)*100;
if(acc1>50 || acc2>50)
    fprintf('\n***********God!*******result: train err rate:%f, test err rate:%f\n',acc2,acc1);
%     L(1:10,1:10)
else
%    fprintf('\nresult: train err rate:%f, test err rate:%f\n',acc2,acc1);
end