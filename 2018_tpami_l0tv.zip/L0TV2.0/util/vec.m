function [r] = vec(r)
r= r(:);