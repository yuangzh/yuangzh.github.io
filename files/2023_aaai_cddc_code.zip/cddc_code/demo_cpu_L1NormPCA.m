function demo_cpu_L1NormPCA
% max_x ||Ax||_1, s.t. x'x=1
clc;clear all;close all;
rand('seed',1); randn('seed',1);
addpath('util');





id_data = [11 12 13 14 21 22 23 24 31 32 33 34 41 42 43 44];



result = [];
for idat = 1:length(id_data)
    
    
    
    % Main Algorithms
    G = getdata_pca(id_data(idat));
    
    x = randn(size(G,2),1);
    MaxTime = 100;
    [x1,his1,ts1] = MSCR(G,x,MaxTime);
    [x2,his2,ts2] = TolandDual(G,x,MaxTime);
    [x3,his3,ts3] = SubGradient(G,x,MaxTime);
    [x4,his4,ts4] = CD_SCA(G,x,MaxTime);
    [x5,his5,ts5] = CD_SNCA(G,x,MaxTime);
    
    
    
    % Scale the objectives if they are negative
    CCC = min([his1(:);his2(:);his3(:);his4(:);his5(:)])+eps;
    CCC = min(0,CCC); his1=his1+CCC; his2=his2+CCC; his3=his3+CCC; his4=his4+CCC; his5=his5+CCC;
    
    
    
    One = [];
    One.his1 = his1;
    One.his2 = his2;
    One.his3 = his3;
    One.his4 = his4;
    One.his5 = his5;
    One.ts1 = ts1;
    One.ts2 = ts2;
    One.ts3 = ts3;
    One.ts4 = ts4;
    One.ts5 = ts5;
    result{idat} = One; save(mfilename,'result')
    
end


function [x,his,ts] = CD_SCA(A,x,MaxTime)
% min_x 0.5 lambda x'x - ||Ax||_1
initt = clock;
lambda = 1;
his = []; ts = [];
n = length(x);
fobj = 0.5*lambda*x'*x - norm(A*x,1);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

Ax = A*x;
xx = x'*x;

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter = 1:1000000
    fobj = 0.5*lambda*xx - norm(Ax,1);
    %     [~,i] = max(abs(grad));
    i = mod(iter,n)+1;
    %      i = randperm(n,1);
    %     if(0==mod(iter,2))
    %         i = randperm(n,1);
    %     else
    %         [~,i] = max(abs(grad));
    %     end
    
    %     subgrad = A'*sign(Ax);
    %     subgrad_i =  subgrad(i);
    subgrad_i = sign(Ax)'*A(:,i);
    
    %     ttt = \min_t 0.5 ||x+tei||_2^2 - <tei,grad>
    %     ttt = \min_t 0.5 t^2 + <x-grad,tei>
    t = subgrad_i - x(i);
    x(i) = x(i) + t;
    xx = xx + 2*t*x(i) - t*t;
    Ax = Ax + t*A(:,i);
    %     if(0==mod(iter,n))
    %         his = [his;ComputeObjTrue(x,A)];
    %     end
    
    %     if(norm(grad)<1e-10),break;end
    
    
    
    
    %      fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end
% his = [his;ComputeObjTrue(x,A)];
% CheckOptimality(x,A,lambda);
his = his(:);
ts = ts(:);


function [x,his,ts] = CD_SNCA(A,x,MaxTime)
% min_x 0.5 lambda x'x - ||Ax||_1
initt = clock;
[m,n]=size(A);
lambda = 1;
his = []; ts = [];


fobj = 0.5*lambda*x'*x - norm(A*x,1);
his = [his;fobj];
ts = [ts;etime(clock,initt)];
Ax = A*x;
xx = x'*x;

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;

for iter = 1:1000000
    %     [fobj,grad] = ComputeObjCD(x,lambda,A);
    fobj = 0.5*lambda*xx - norm(Ax,1);
    i = mod(iter,n)+1;
    %     i = randperm(n,1);
    %     if(0==mod(iter,2))
    %         i = randperm(n,1);
    %     else
    %         [~,i] = max(abs(grad));
    %     end
    %     ei = zeros(n,1);
    %     ei(i)=1;
    % f(x + tei)
    % min_t 0.5 lambda (x + tei)'(x + tei) - ||A(x + tei)||_1
    % min_t 0.5 lambda t^2 + lambda <tei, x>  - ||A(x + tei)||_1
    % min_t 0.5 t^2 + <tei, x>  - 1/lambda ||A(x + tei)||_1
    %     Aei = A * ei;
    Aei =  A(:,i);
    xi_old = x(i);
    
    %       t = nonconvex_prox_l1(-x(i),1/lambda,Aei,Ax,m);
    t = nonconvex_prox_l1_mex(-x(i),1/lambda,Aei,Ax,m);
    
    
    x(i) = xi_old + t;
    xx = xx + 2*t*xi_old + t*t;
    
    
    
    
    Ax = Ax + t*A(:,i);
    
    %     fprintf('iter:%d, fobj:%f, normG:%f\n',iter,fobj,norm(grad));
    
    %     fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end
% his = [his;ComputeObjTrue(x,A)];
% CheckOptimality(x,A,lambda);
his = his(:);
ts = ts(:);

function CheckOptimality(x,A,lambda)
n = length(x);


for iter = 1:100000
    
    y = randn(n,1);
    tau = 0.001;
    d = y-x;
    x1 = x + tau*d;
    %     ComputeObjCD(x1,lambda,A) - ComputeObjCD(x,lambda,A)
end


function [x,his,ts] = SubGradient(A,x,MaxTime)
% min_x 0.5 x'*x - ||Ax||_1
% min_x 0.5 x'*x - <x,subgrad>
initt = clock;
[m,n] = size(A);
his = []; ts = [];
fobj = 0.5*x'*x - norm(A*x,1);
his = [his;fobj];
ts  = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter =1:10000
    % update x
    subgrad = x - A'*sign(A*x);
%     step = 1/(iter);
    step = 1/sqrt(iter);
    x = x - step*subgrad;
    fobj = 0.5*x'*x - norm(A*x,1);
    
    
    %  fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his(iter) = fobj;
    ts(iter) = etime(clock,initt);
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end

his = his(:);
ts = ts(:);



function [x,his,ts] = MSCR(A,x,MaxTime)
% min_x 0.5 x'*x - ||Ax||_1
% min_x 0.5 x'*x - <x,subgrad>
initt = clock;
[m,n] = size(A);
his = []; ts = [];
fobj = 0.5*x'*x - norm(A*x,1);
his = [his;fobj];
ts  = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;
for iter =1:10000
    % update x
    subgrad = A'*sign(A*x);
    x = subgrad;
    
    fobj = 0.5*x'*x - norm(A*x,1);
    
    
    %  fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his(iter) = fobj;
    ts(iter) = etime(clock,initt);
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
end

his = his(:);
ts = ts(:);


% plot(his)
% ddd
function [fobj,grad] = ComputeObjCD(x,lambda,A)
% min_x 0.5x'Qx + p'x - ||Ax||_1
fobj = 0.5*lambda*x'*x - norm(A*x,1);
grad = lambda*x - A'*sign(A*x);
hess = lambda*eye(length(x)) - A'*diag(sign(A*x))*A;
% eig(hess+hess')


function [x,his,ts] = TolandDual(A,x,MaxTime)
% min_x 0.5 x'*x - ||Ax||_1
% min_x min_y 0.5 x'*x - <y,Ax>, s.t. -1<=y<=1
% min_y min_x 0.5 x'*x - <y,Ax>, s.t. -1<=y<=1
% grad = x - A'y = 0  => x = A'y
% min_y -0.5 y'*A*A'*y, s.t. -1<=y<=1
initt = clock;
[m,n] = size(A);
his = []; ts = [];

y = sign(A*x);
fobj = 0.5*x'*x - norm(A*x,1);
his = [his;fobj];
ts = [ts;etime(clock,initt)];

last_k = 100;
stop_accuracy = 1e-12;
changes = ones(last_k,1)*inf;
fobj_old = fobj;

for iter = 1:1000
    
    y = sign(A*A'*y);
    
    x = A'*y;
    fobj = 0.5*x'*x-norm(A*x,1);
    
    %     fprintf('iter:%d, fobj:%f\n',iter,fobj);
    his = [his;fobj];
    ts = [ts;etime(clock,initt)];
    if etime(clock,initt) > MaxTime,
        break;
    end
    
    rel_change = abs((fobj - fobj_old)/max(1,fobj_old));
    changes = [changes(2:end);rel_change];
    fobj_old = fobj;
    if(mean(changes)<stop_accuracy),break;end
    
    
end


his = his(:);
ts = ts(:);
function [x,his_true_obj] = pca_power(A,x)
% min_x - ||Ax||_1, s.t. ||x||_2 = 1
% min_x min_c  - <c, Ax>, s.t. ||x||_2 = 1, c \in {-1,+1}
% min_c min_x  - <c, Ax>, s.t. ||x||_2 = 1, c \in {-1,+1}

% update x
% min_x -<x,b>, s.t. x'x=1, b = A'c
% min_x -<x,b> + 0.5 x'x, s.t. x'x=1
% min_x 0.5||x-b||_2^2, s.t. x'x=1
% x = b / norm(b)

% update c
% min_c  - <c, Ax>, s.t. c \in {-1,+1}
% c = sign(Ax)

% max_{c}, c'Kc, s.t. c \in {-1,+1}

[m,n] = size(A);
% c = randn(m,1);
c = sign(A*x);
his = [];
his_true_obj = [];
for iter =1:100
    % update x
    b = A'*c;
    x = b / norm(b);
    c = sign(A*x);
    trueobj = norm(A*x,1);
    his_true_obj(iter) = trueobj ;
    fprintf('iter:%d, fobj:%f\n',iter,trueobj);
end

% plot(his_true_obj)
% dd








%
%
%
% function [x,his_true_obj,his] = pca_power(A,x)
% % min_x - ||Ax||_1, s.t. ||x||_2 = 1
% % min_x min_c  - <c, Ax>, s.t. ||x||_2 = 1, c \in {-1,+1}
% % min_c min_x  - <c, Ax>, s.t. ||x||_2 = 1, c \in {-1,+1}
% % update x
%
% % min_x <x, b>, s.t. x'x=1, b = -A'c
% % min_x <x, b> + 0.5 x'x, s.t. x'x=1
% % min_x 0.5||x+b||_2^2, s.t. x'x=1
% % x = -b / norm(b)
%
%
% % max_{c}, c'Kc, s.t. c \in {-1,+1}
% K = A*A';
% [m,n] = size(A);
% c = randn(m,1);
% c = sign(c);
% his = [];
% his_true_obj = [];
% for iter =1:100
%     c =  sign(K*c);
%     y = A'*c;
%     x = y / norm(A*y,1);
%     fobj = c'*K*c;
%     trueobj = norm(A*x,1);
%     his(iter) = fobj ;
%     his_true_obj(iter) = trueobj ;
%     fprintf('iter:%d, fobj:%f\n',iter,fobj);
% end
%
% plot(his)
% dd