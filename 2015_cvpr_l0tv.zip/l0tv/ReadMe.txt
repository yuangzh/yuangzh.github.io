l0TV README File
=================================================

1. Quick-start
To test the code, we have provided a demo Matlab script "demo.m", which runs l0TV_PADMM 
over the "barbara.png" image. Simply type "demo" in the Matlab command prompt. 
If everything is working properly, you will get the following results:

(1) SNR of corrupted image. SNR0:0.07, SNR1:0.19, SNR2:-0.55.
(2) SNR of recovered image. SNR0:0.09, SNR1:1.58, SNR2:4.30.


2. Using the code
To reproduce the experiments which described in [1], you need to perform the following two steps:
(1) run "demo_generate_corrupted_images.m" to generate the corrupted images.
(2) run Matlab script "test0_*.m / test1_*.m / test2_*.m / test3_*.m / test4_*.m" to obtain the experiment results.


3. Directory tree
We demonstrate the directory tree of our code, including the names of some main functions and their descriptions.

------------------- solvers
     |              |
     |              |-------- l0tv_padmm_color.m : Implementation of PADMM algorithm for solving Colored l0TV problem
     |              |-------- l0tv_proj_reg.m    : Implementation of the penalty decomposition method and Augmented Lagrangian method
     |              |-------- tvinpaint.m        : Implementation of the Split Bregman Method for l1TV and l2TV inpaint problems
     |              |-------- l1tv_admm.m        : Implementation of the proximal ADMM for solving l1TV
     |              |-------- amf.m              : Implementation of the adaptive median filter to salt-and-pepper inpulse denoising
     |              |-------- acwmf2.m           : Implementation of the adaptive center-weighted median filter to random-valued inpulse denoising
     |
     |
------------------- util
     |              |
     |              |-------- snr_l0.m           : compute the SNR0 value for images
     |              |-------- snr_l1.m           : compute the SNR1 value for images
     |              |-------- snr_l2.m           : compute the SNR2 value for images
     |              |-------- GenBlurOper.m      : Generate the blurring kernel
     |              |-------- threadholding_l0.m : proximal operator for the l0 norm
     |              |-------- functionAX.m       : specify the matrix-vector for the denoising/deblurring problem
     |              |-------- impulsenoise.m     : inject an image with (Salt-and-pepper or Random-valued) impulse noise
     |              |-------- difX.m/difY.m      : Given u, these functions compute \nabla_x u and \nabla_y u, respectively.
     |              |-------- divX.m/divY.m      : Given z, these functions compute - \nabla_x^T z and - \nabla_y^T z, respectively.
     |
     |
------------------- cimg
     |              |
     |              |-------- Clean images
     |
     |
------------------- dimg
     |              |
     |              |-------- Dirty images
     |
     |
------------------- scratched
                    |
                    |-------- Scratched images
	 
	 
4. REFERENCES:
[1] Ganzhao Yuan, Bernard Ghanem. $\ell_0$TV: A New Method for Image Restoration in the Presence of Impulse Noise. Oral Presentation, CVPR 2015.

	 
