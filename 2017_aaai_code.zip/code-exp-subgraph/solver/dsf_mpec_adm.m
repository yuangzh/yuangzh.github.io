function [x,fobj,his] = dsf_mpec_adm(W,k)
% This program solves the following optimization problem:
% min -x'*W*x, s.t. x \in {0,1}^n, sum(x) = k
% min x'*(lambda I-W)*x, s.t. x \in {0,1}^n, sum(x) <= k
% min 0.5x'*L*x, s.t. x \in {0,1}^n, sum(x) = k
t1 = clock;
W = (W+W')/2;
n = size(W,1);
lambda = abs(largest_eig(W))*1.1;
L = speye(n)*lambda - W;
L = (L+L')/2;
max_mm = largest_eig(L);
t2 = clock;

fprintf('time spent in lipschitz constant computation: %f\n',etime(t2,t1));
% min 0.5x'*L*x, s.t. <2x-1,2y-1> = n, 0<=x<=1, ||2y-1||_2^2, sum(x) <= k
% J(x,y) = 0.5x'*L*x + rho (n - <2x-1,2y-1>) + 0.5 alpha (n - <2x-1,2y-1>)^2, s.t. 0<=x<=1, ||2y-1||_2^2, sum(x) <= k
x = zeros(n,1);
y = randn(n,1)*1e-6;
rho = 0;
alpha = 0.0001;
x_best = x;
f_min = inf;
his = [];
for iter = 1:100,
    % J(x,y) = 0.5x'*L*x + rho (n - <2x-1,2y-1>)+ 0.5 alpha (n - <2x-1,2y-1>)^2, s.t. 0<=x<=1, ||2y-1||_2^2, sum(x) <= k
    % J(x) = 0.5x'*L*x - rho<2x-1,2y-1>+ 0.5 alpha (n - <2x-1,2y-1>)^2, s.t. 0<=x<=1, sum(x) == k
    % x = quadprog(L,-rho*2*(2*y-1),[],[],ones(1,n),k,zeros(n,1),ones(n,1),x);
    Lip = max_mm + alpha *4 * norm(2*x-1)^2;
    t1 = clock;
    for in=1:50,
        grad = L*x -rho*2*(2*y-1)-2*alpha*(n - mdot(2*x-1,2*y-1));
        xt = x;
        x = BreakPointSearch(ones(n,1),-(x - grad/Lip),k,'==');
        if(in>5 && norm(x-xt)/norm(x)<1e-5),break;end
    end
    t2 = clock;
    
    % J(x,y) = 0.5x'*L*x + rho (n - <2x-1,2y-1>)+ 0.5 alpha (n - <2x-1,2y-1>)^2, s.t. 0<=x<=1, ||2y-1||_2^2, sum(x) <= k
    % J(y) = (n - <2x-1,2y-1>)+ 0.5 alpha (n - <2x-1,2y-1>)^2, s.t. ||2y-1||_2^2
    % o = sqrt(n)*(2*x-1)/norm(2*x-1);
    o = QP_rank1(2*x-1,-n*(2*x-1)-rho/alpha*(2*x-1),sqrt(n),0);
    y = (o+1)/2;
    
    dist = n - mdot(2*x-1,2*y-1);
    rho = rho + alpha * dist;
    error = max(0,dist);
    
    f_cur = computeobj(x,W,k);
    his = [his;f_cur];
    
    if(f_min>f_cur)
        f_min = f_cur;
        x_best = x;
    end
    
    fprintf('iter:%d, cpu:%f, error:%f, fobj:%f, best:%f, rho:%f, alpha:%f\n',iter,etime(t2,t1),error,f_cur,f_min,rho,alpha);
    
    threshold = 50;
    if(rho<=threshold)
        if(~mod(iter,10)),alpha = alpha * sqrt(10);end
    else
        rho = threshold;
    end
        
    if(iter>30 && error<0.01),break;end
    
end

x=proj_01k(x_best,k);
fobj = computeobj(x,W,k);






