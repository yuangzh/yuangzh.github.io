function [vector,value] = largest(A,acc)
options=[];
options.tol = acc;
[vector,value] = laneig(A,1,'AL',options);
