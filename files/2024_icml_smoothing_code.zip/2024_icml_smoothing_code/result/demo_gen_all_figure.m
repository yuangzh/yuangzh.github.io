clc;clear all;close all;
addpath('..\util','..\solver');
% delete('*.png')
% delete('*.eps')
data_result = 'result2';
load(data_result);

% 0.5 || Ax-b||_F^2 + lambda ||x||_0
% clc;clear;close all;
addpath('util','solver','data');


data_id = [1 2 3 4 11 12 13 14];
ks1   = [5 10 20 30 40 50 60 70 80 90];
ks   = repmat(ks1,1,length(data_id));
data_id   = repmat(data_id,length(ks),1); data_id = data_id(:)';


  
one_len = length(ks1);
for iii = 1:8
    ibeg = (iii-1)*one_len+1;
    iend = ibeg + one_len-1;
    
    ts = ks1; 
    his1 = []; his2 = []; his3 = []; his4 = []; his5 = [];his6=[];his7= [];
    for jjj=ibeg:iend
    his1 = [his1;result{jjj}.fobj1];
    his2 = [his2;result{jjj}.fobj2];
    his3 = [his3;result{jjj}.fobj3];
    his4 = [his4;result{jjj}.fobj4];
    his5 = [his5;result{jjj}.fobj5];
    his6 = [his6;result{jjj}.fobj6];
    his7 = [his7;result{jjj}.fobj7];
    end
    iii
his1'
his7'

    yscale=1;
    [pcolor] = loadcolor;
% markers{1}='v';
% markers{2}='*';
% markers{3}='^';
% markers{4}='v';
% markers{5}='*';
% markers{6}='+';
% markers{10}='d';
% markers{11}='<';
% markers{12}='>';
% markers{13}='h';
    figure('color','w')
% yellow
    plot(ts,his1,'-ks','LineWidth',5,'MarkerSize',3,'color', pcolor.red); hold on;
    plot(ts,his2,'-ms','LineWidth',5,'MarkerSize',3,'color',  pcolor.green); hold on;
    plot(ts,his3,'-.k*','LineWidth',4,'MarkerSize',3,'color', pcolor.purple); hold on;
    plot(ts,his4,'-.b+','LineWidth',4,'MarkerSize',3,'color', pcolor.yellow); hold on;
    plot(ts,his5,'--ro','LineWidth',4,'MarkerSize',3,'color', pcolor.blue); hold on;
    plot(ts,his6,'--rv','LineWidth',4,'MarkerSize',3,'color', pcolor.pink); hold on;
    plot(ts,his7,'-.rh','LineWidth',4,'MarkerSize',3,'color', pcolor.gray); hold on;


    
    hleg=legend('PADM-BCD','PADM-IHT','PSGD-IHT','ADMM-IHT','DIHT','CVX-L1','NCVX-Lp') ;
    set(hleg,'FontSize',15,'FontWeight','normal');
    set(hleg,'Fontname','times new Roman');
    set(hleg,'Location','NorthEast');
     set(gca,'Fontsize', 17);
    ylabel('Objective','FontSize',20)
    xlabel('Sparsity','FontSize',20)
%   
    set(gca,'xtick',[5 10 20 30 40 50 60 70 80 90]);
    % set(gca,'XTickLabel',{'64','128','256','512','1024'})
    % set(gcf,'position', [300 100 600 500]);

    hiss = [his1(:);his2(:);his3(:);his4(:);his5(:);his6(:);his7(:)];
    axis([0 91 0.99*min(hiss) max(hiss)])

    fprintf('\n');
    set(gcf,'paperpositionmode','auto')
    print(sprintf('%s_%d.eps',data_result,iii),'-depsc2','-loose');
    print(sprintf('%s_%d.png',data_result,iii),'-dpng');

%     close all;
end



