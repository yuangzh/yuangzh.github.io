clc;clear all;close all;
randn('seed',0);rand('seed',0);
addpath('cimg','dimg','util','solvers')

load_L0TV_lambda;
[noiselevels,images,noisetypes,restorationtypes] = load_parameters_denoising;


delete(sprintf('%s.txt',mfilename))
result = {};
i_result= 1;
InitSol=[];
fast_init;
for mmm = 1:length(restorationtypes),
    for kkk = 1:length(images),
        for lll = 1:length(noisetypes),
            noisetype =noisetypes{lll};
            dlmwrite(sprintf('%s.txt',mfilename),datestr(now),'-append','delimiter','%s\t');
            mystr = sprintf('restorationtype:%s, noisetype:%s, image:%s',restorationtypes{mmm},noisetypes{lll},images{kkk});
            dlmwrite(sprintf('%s.txt',mfilename),mystr,'-append','delimiter','%s\t');
            psnrs = zeros(length(lambdas),length(noiselevels));
            psnrs1 = zeros(length(lambdas),length(noiselevels));
            psnrs2 = zeros(length(lambdas),length(noiselevels));
            times1 = zeros(length(lambdas),length(noiselevels));
            for jjj = 1:length(noiselevels),
                parfor iii = 1:length(lambdas),
                    lambda = lambdas(iii);
                    noiselevel = noiselevels(jjj);
                    B_Clean = double(imread(sprintf('%s.png',images{kkk})));
                    
                    corrupted_image_name = sprintf('%s_%s_%s_%d.png',restorationtypes{mmm},images{kkk},noisetype,noiselevel);
                    B_Corrupted =  double(imread(corrupted_image_name));
                    
                    % Generate the mask matrix O
                    if(strcmp(noisetype,'Salt-and-Pepper') || strcmp(noisetype,'Mixed'))
                        O = ones(size(B_Clean));
                        O(B_Corrupted==255)=0;
                        O(B_Corrupted==0)=0;
                    else
                        O = ones(size(B_Clean));
                    end
                    
                    B_Clean = B_Clean/255;
                    B_Corrupted = B_Corrupted/255;
                    
                    p = 2;
                    P = GenBlurOper;
                    LargestEig = min(sqrt(sum(abs(P(:))>0)*sum(P(:).*P(:))), sum(abs(P(:))));% Largest Eigenvalue of A'A
                    
                    Amap = @(X)functionAX(P,X,restorationtypes{mmm});
                    Atmap = @(X)functionAX(P',X,restorationtypes{mmm});
                    
                    acc = .1/255;
                    penalty_ratio = 10;
                    tic;
                    [U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,penalty_ratio,B_Clean);
                    
                    temp(iii) = snr_l0(U, B_Clean);
                    temp1(iii)= snr_l1(U, B_Clean);
                    temp2(iii) = snr_l2(U, B_Clean);
                    temp3(iii) = toc;

                end
                
                psnrs(:,jjj)  = temp;
                psnrs1(:,jjj) = temp1;
                psnrs2(:,jjj) = temp2;
                times1(:,jjj) = temp3;
                psnrs
                psnrs1
                psnrs2
                times1
            end
            
            Res = [];
            Res.psnr_l0 = psnrs;
            Res.psnr_l1 = psnrs1;
            Res.psnr_l2 = psnrs2;
            Res.times1 = times1;
            Res.noiselevels = noiselevels;
            Res.lambdas = lambdas;
            Res.noisetype = noisetypes{lll};
            Res.image = images{kkk};
            Res.restorationtype = restorationtypes{mmm};
            result{i_result} = Res;
            i_result=i_result+1;
            
            dlmwrite(sprintf('%s.txt',mfilename),psnrs,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs),'-append');
            
            dlmwrite(sprintf('%s.txt',mfilename),psnrs1,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs1),'-append');
            
            dlmwrite(sprintf('%s.txt',mfilename),psnrs2,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs2),'-append');
            
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            save(mfilename,'result');
        end
    end
end


save(mfilename,'result');
