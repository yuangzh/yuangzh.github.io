clc;clear all;close all;
  addpath('matdatnew');
% delete('*.png')
% delete('*.eps')

load result_cca

his1 = -his_exp;
his2 = -his_log;
his3 = -his_lp;
his4 = his_trf;
his5 = his_rcs_bis;
his6 = his_rcs_coo;


figure;

xData{1} =  [1:length(his1)]; xData{2} =  [1:length(his2)]; xData{3} =  [1:length(his3)]; xData{4} =  [1:length(his4)]; xData{5} =  [1:length(his5)]; xData{6} =  [1:length(his6)];
yData{1} = his1(:);    yData{2} = his2(:);    yData{3} = his3(:);    yData{4} = his4(:);    yData{5} = his5(:);    yData{6} = his6(:);


opt=loadopt;

opt.xlabel = 'Iteration';
opt.ylabel = 'Objective';
opt.LegendFontSize = 13;
opt.legend = {...
    'Classical PPA',...
    'Accerlated PPA',...
    'Triangle PPA',...
    'Greedy Pursuit',...
    'Hybrid(R3-G0)',...
    'Hybrid(R7-G0)'};
opt.legendLoc = 'NorthEast';
opt.labelLines = 0;
opt.logScale=0;
prettyPlot(xData,yData,opt);
max_iter = length(his1);
hiss = [his1(:);his2(:);his3(:);his4(:);his5(:);his6(:)];
hiss = hiss(:);
axis([1 max_iter min(hiss) 0.2*max(hiss)])

fprintf('Method1: %f\n',min(his1));
fprintf('Method2: %f\n',min(his2));
fprintf('Method3: %f\n',min(his3));
fprintf('Method4: %f\n',min(his4));
fprintf('Method5: %f\n',min(his5));
fprintf('Method6: %f\n',min(his6));

fprintf('\n');

set(gcf,'paperpositionmode','auto')
print(sprintf('%s.eps',mfilename),'-depsc2','-loose');
print(sprintf('%s.png',mfilename),'-dpng');


