function [y] = generate_y(G)
[m,n] = size(G);
totnnz = 100;
x = generate_x(n,totnnz);
b = G*x;
b = b + 0.05*norm(b)*randn(m,1);
y = max(b,0);

function x = generate_x(n,k)
p = randperm(n);
x = zeros(n,1);
x(p(1:k)) = randn(k,1);