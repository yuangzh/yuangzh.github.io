The source for libbvg is protected by the GNU GPL.  Current MathWorks 
file exchange policies do not permit me distributed the GPLed bits
in the file exchange.  Thus, this script will download the sources
after notifying you about this message.

You must have an active web connection for the following
steps to work.

