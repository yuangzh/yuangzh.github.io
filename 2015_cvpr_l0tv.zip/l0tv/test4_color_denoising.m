
clc;clear all;close all;
randn('seed',0);rand('seed',0);

addpath('cimg','dimg','util','solvers')

% image = 'lenna';lambdas =  [8];
% image = 'pepper';lambdas =  [8];
 image = 'jetplane';lambdas =  [8];

B_Clean = imread(sprintf('%s_color.png',image));



B_Corrupted = B_Clean;
B_Clean = double(B_Clean);
B_Corrupted = double(B_Corrupted);


B_Corrupted = impulsenoise(B_Corrupted,0.3,1);


B_Clean = B_Clean/max(B_Clean(:));
B_Corrupted = B_Corrupted/max(B_Corrupted(:));
%   imshow(B_Corrupted(:,:,3))
%   ddd

p = 2;
P = GenBlurOper;
LargestEig = min(sqrt(sum(abs(P(:))>0)*sum(P(:).*P(:))), sum(abs(P(:))));% Largest Eigenvalue of A'A
Amap = @(X)functionAX(P,X,'denoising');
Atmap = @(X)functionAX(P',X,'denoising');

% [y nois_ma2] = amf(B_Corrupted*255,39,0,0);
% dd
O = ones(size(B_Clean));
% if(strcmp(noisetype,'Salt-and-Pepper'))
%     max_val = max(abs(B_Corrupted(:))); min_val = min(abs(B_Corrupted(:)));
%     O(B_Corrupted==max_val)=0; O(B_Corrupted==min_val)=0;
% end




acc = 1/255;

PSNRs = [];
% imshow(B_Corrupted);
for i=1:length(lambdas),
    lambda =  lambdas(i);
    [U] = l0tv_padmm_color(B_Corrupted,O,Amap,Atmap,p,lambda,LargestEig,acc,B_Clean);
    PSNR = snr_l1(U, B_Clean);
    PSNRs = [PSNRs;PSNR];
    PSNRs
end
PSNRs
% imshow(U)
% imshow(ones(size(U)) - abs(U-B_Corrupted))

figure;
subplot(1,3,1); imshow(B_Clean,[]);title('Original','fontsize',13);
subplot(1,3,2); imshow(B_Corrupted,[]); title('Corrupted','fontsize',13);
subplot(1,3,3); imshow(U,[]); title('Recovered','fontsize',13);

imwrite(B_Corrupted,sprintf('%s_color_corrupted.png',image));
imwrite(U,sprintf('%s_color_recovered.png',image));

fprintf('%.2f %.2f %.2f\n',snr_l0(B_Corrupted, B_Clean),snr_l1(B_Corrupted, B_Clean),snr_l2(B_Corrupted, B_Clean));
fprintf('%.2f %.2f %.2f\n',snr_l0(U, B_Clean),snr_l1(U, B_Clean),snr_l2(U, B_Clean));
