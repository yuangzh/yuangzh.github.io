function [x] = vec(x)
x = x(:);