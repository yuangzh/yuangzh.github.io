clc;clear all;close all;warning off;
randn('seed',0); rand('seed',0);
addpath('data','util','solver');


round  = 1;
rs = [20;50;100;200;300];
timelits = [10;30;50;70];
datasets = {'20news','COIL100','TDT2'};

for idata = 1:length(datasets),
    cur_data = datasets{idata};
    load(cur_data);
    result = [];
    for it = 1:length(timelits),
        for ir = 1:length(rs),
            r = rs(ir);
            timelit = timelits(it);
            fprintf('r: %d, timelit:%d begin\n',r,timelit);
            [obj] = OneRunN(X,r,timelit,round);
            fprintf('r: %d, timelit:%d end\n\n',r,timelit);
            fprintf('**********************************\n');
            obj
            One = [];
            One.obj = obj;
            One.r = r;
            One.timelit = timelit;
            result{it,ir} = One;
            savefilename = sprintf('%s_%s',mfilename,cur_data);
            save(savefilename,'result');
        end
    end
end
