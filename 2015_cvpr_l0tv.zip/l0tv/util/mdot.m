function [obj] = mdot(a,b)
obj = sum(sum(sum(a.*b)));