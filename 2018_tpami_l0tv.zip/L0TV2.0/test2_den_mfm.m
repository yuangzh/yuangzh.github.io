clc;clear all;close all;
randn('seed',0);rand('seed',0);

addpath('cimg','dimg','util','solvers')
lambdas =  [1 2];
[noiselevels,images,noisetypes,restorationtypes] = load_parameters_denoising;

% Note that MFM can be only used for denoising problem
delete(sprintf('%s.txt',mfilename))

result = {};
i_result=1;

fast_init;

for mmm = 1:length(restorationtypes),
    for kkk = 1:length(images),
        for lll = 1:length(noisetypes),
            noisetype =noisetypes{lll};
            dlmwrite(sprintf('%s.txt',mfilename),datestr(now),'-append','delimiter','%s\t');
            mystr = sprintf('restorationtype:%s, noisetype:%s, image:%s',restorationtypes{mmm},noisetypes{lll},images{kkk});
            dlmwrite(sprintf('%s.txt',mfilename),mystr,'-append','delimiter','%s\t');
            psnrs = zeros(length(lambdas),length(noiselevels));
            psnrs1= zeros(length(lambdas),length(noiselevels));
            psnrs2= zeros(length(lambdas),length(noiselevels));
            times1 = zeros(length(lambdas),length(noiselevels));
            for jjj = 1:length(noiselevels),
                parfor iii = 1:length(lambdas),
                    lambda = lambdas(iii);
                    noiselevel = noiselevels(jjj);
                    B_Clean = double(imread(sprintf('%s.png',images{kkk})));
                    
                    corrupted_image_name = sprintf('%s_%s_%s_%d.png',restorationtypes{mmm},images{kkk},noisetype,noiselevel);
                    B_Corrupted =  double(imread(corrupted_image_name));
                    B_Clean = B_Clean/255;
                    B_Corrupted = B_Corrupted/255;
                    
                    if(strcmp(restorationtypes{mmm},'denoising'))
                        P = [];
                    else
                        P = GenBlurOper;
                    end
                    
                    Amap = @(X)functionAX(P,X,restorationtypes{mmm});
                    Atmap = @(X)functionAX(P',X,restorationtypes{mmm});
                    
                    
                    
  
                    
                    tic
                    if(strcmp(noisetype,'Random-Valued'))
                        f = B_Corrupted * 255;
                        [y] = acwmf2(f);
                        U = y/255;
                    elseif(strcmp(noisetype,'Salt-and-Pepper'))
                        f = B_Corrupted * 255;
                        [y] = amf(f,39,0,0);
                        U = y/255;
                     elseif(strcmp(noisetype,'Mixed'))
                        f = B_Corrupted * 255;
                        [f] = acwmf2(f);
                        [y] = amf(f,39,0,0);
                        U = y/255;
                   else
                        error('unkwnown type!');
                    end
                    

                    temp(iii) = snr_l0(U, B_Clean);
                    temp1(iii)= snr_l1(U, B_Clean);
                    temp2(iii) = snr_l2(U, B_Clean);
                    temp3(iii) = toc;
                                     
                end
                
                psnrs(:,jjj)  = temp;
                psnrs1(:,jjj) = temp1;
                psnrs2(:,jjj) = temp2;
                times1(:,jjj) = temp3;
                psnrs
                psnrs1
                psnrs2
                times1
            end
            
            
            Res = [];
            Res.psnr_l0 = psnrs;
            Res.psnr_l1 = psnrs1;
            Res.psnr_l2 = psnrs2;
            Res.times1 = times1;
            Res.noiselevels = noiselevels;
            Res.lambdas = lambdas;
            Res.noisetype = noisetypes{lll};
            Res.image = images{kkk};
            Res.restorationtype = restorationtypes{mmm};
            result{i_result} = Res;
            i_result=i_result+1;
            
            dlmwrite(sprintf('%s.txt',mfilename),psnrs,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs),'-append');
            
            dlmwrite(sprintf('%s.txt',mfilename),psnrs1,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs1),'-append');
            
            
            dlmwrite(sprintf('%s.txt',mfilename),psnrs2,'-append');
            dlmwrite(sprintf('%s.txt',mfilename),'optimal values','-append','delimiter','%s\t');
            dlmwrite(sprintf('%s.txt',mfilename),max(psnrs2),'-append');
            
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            dlmwrite (sprintf('%s.txt',mfilename),' ','-append','delimiter','%s\t')
            save(mfilename,'result');
        end
    end
end


save(mfilename,'result');