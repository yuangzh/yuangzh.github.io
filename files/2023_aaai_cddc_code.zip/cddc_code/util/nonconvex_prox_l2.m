function [t] = nonconvex_prox_l2(beta,lambda,a,b)
% 0.5 t^2 - beta t - lambda || t a + b||_2
% 0.5 (t-beta)^2 - lambda || t a + b||_2
% grad = t-beta - lambda * <a, (t*a+b) / norm(t*a+b)>
% letting grad = 0, we have:
% lambda* <a,t*a+b> = (t-beta) norm(t*a+b)
aa = a'*a;
ab = a'*b;
bb = b'*b;
c = lambda*aa;
d = lambda*ab;
% lambda* <a,t*a+b> = (t-beta) norm(t*a+b)
% c t + d = (t-beta) norm(t*a+b)
% c*c*t*t + d*d + 2*c*d*t = (t-beta)^2 norm(t*a+b)^2
% c*c*t*t + d*d + 2*c*d*t = (t*t + beta*beta - 2*beta*t) ( a'*a*t*t + b'*b + 2*a'*b*t )  
% c*c*t*t + d*d + 2*c*d*t =   t*t*a'*a*t*t + t*t*b'*b + 2*t*t*a'*b*t
%                           + beta*beta*a'*a*t*t  + beta*beta*b'*b  +  beta*beta*2*a'*b*t
%                           - 2*beta*t* a'*a*t*t  - 2*beta*t*b'*b   -  2*beta*t* 2*a'*b*t

cof_4 = aa;
cof_3 = 2*ab - 2*beta* aa;
cof_2 = bb + beta*beta*aa -  2*beta*2*ab -c*c;
cof_1 = beta*beta*2*ab - 2*beta*bb - 2*c*d;
cof_0 = beta*beta*bb - d*d;
ts = roots([cof_4;cof_3;cof_2;cof_1;cof_0]);
for i=1:length(ts)
ts(i) = real(ts(i));
t_test = ts(i);
[fobj,grad] = ComputeObj(t_test,beta,lambda,a,b);
his(i) = fobj;
end

% [~,ind]=min(fs);
% t = ts(ind);
% https://en.wikipedia.org/wiki/Quartic_function




[val,ind] = min(his);
% t = ts(ind);
[inds] = find(his==val);
t = ts(inds);
t = find_small_roots(t);

function [t] = find_small_roots(t)
[~,ind]=min(abs(t));
t = t(ind);



function [fobj,grad] = ComputeObj(t,beta,lambda,a,b)
fobj = 0.5*(t-beta)^2 - lambda*norm(t*a+b,2);
grad = t-beta - lambda*( (t*a+b) / norm(t*a+b) )'*a;
% grad = t-beta - lambda*sign(t*sign(a)+b/norm(a))'*a;


