function [x,his] = L1Reg_ProjSubGrad_IHT(A,b,lambda,k,x0)
% min_x 0.5*lambda*x'*x +||Ax-b||_1, s.t. ||x||_0 <= k 
% min_{x,y} 0.5*lambda*x'*x +||y||_1, s.t. Ax-b = y, ||x||_0 <= k 
% L(x,y;pi) 0.5*lambda*x'*x + ||y||_1 + <Ax-b-y,pi> + 0.5 beta ||Ax-b-y||_2^2, s.t. ||x||_0 <= k


[m,n]=size(A);
x = x0;

HandleObj = @(x)0.5*lambda*x'*x + norm(A*proj_l0(x,k)-b,1);

diff = zeros(m,1);

for iter = 1:3000


err = A*x - b;
% diff = sign(err);

for iii=1:length(diff),
    if(abs(diff(iii))<1e-5)
        diff(iii) = 2*rand(1)-1;
    else
        diff(iii) = sign(err(iii));
    end
end
subgrad = lambda * x + A'*diff;
   

x = x - subgrad * 0.01 / iter;

x = proj_l0(x,k);


tfobj = HandleObj(x);
tfobj

his(iter) = tfobj;


 
%     rel_change = abs((tfobj - fobj_old_tobj)/max(1,fobj_old_tobj));
%     changes_tobj = [changes_tobj(2:end);rel_change];
%     fobj_old_tobj = tfobj;
    
% HandleObj1(x,y,pi,beta)-HandleObj1(x,y,pi,beta/1.1)
%    beta = (iter)^0.5;

%  if(mean(changes)<stop_accuracy_out),


% if(mean(changes_tobj)<stop_accuracy_tobj && dist < 0.01),
% break;
% end


end


% plot(his)