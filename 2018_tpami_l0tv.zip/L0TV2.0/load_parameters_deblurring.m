function [noiselevels,images,noisetypes,restorationtypes] = load_parameters_deblurring
noiselevels = [10:20:90];
noisetypes = {'Random-Valued','Salt-and-Pepper','Mixed'};
restorationtypes = {'denoising','deblurring'};
restorationtypes = {'deblurring'};


images = {'walkbridge','pepper','mandrill','jetplane','lenna','cameraman'};
images = {'walkbridge','pepper','mandrill','lenna','lake','jetplane','blonde','cameraman','barbara','boat','pirate','livingroom','house'};
