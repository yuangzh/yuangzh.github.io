function [L,ts]=kta(dat)
% Kernal Targe Alignment Metric Learning
% Implemented by Ganzhao Yuan
% South China Univ. of Technology
% email: yuanganzhao@gmail.com
% Ref:
% Zhifeng Hao, Ganzhao Yuan��Zhenjie Zhang, Bernard Ghanem. 
% BILGO: Bilateral Greedy Optimization for Large Scale Semidefinite Programming
% Submitted to Machine Learning Jounal
% This programme solves the following optimization problem:
% min_M = |M-I|_F^2 + lambda * |XMX'-Y'*Y|_F^2 
% M = LL'

    
    
[dat.n,dat.d]=size(dat.x);
if ~isfield(dat,'rank'),
    dat.rank=ceil(min( min(60,max(40,sqrt( dat.d))) ,dat.d));
end
%  if ~isfield(dat,'maxiter'),dat.maxiter= 100 + ceil(sqrt(dat.rank*dat.n)); end
if ~isfield(dat,'maxiter'),dat.maxiter=  ceil(dat.rank*dat.n ); end
if ~isfield(dat,'robj'),dat.robj=1e-4; end
if ~isfield(dat,'rnorm'),dat.rnorm=1e-3; end
if ~isfield(dat,'vcount'),dat.vcount=100; end
if ~isfield(dat,'alg'),dat.alg='BILGO'; end
if ~isfield(dat,'vset'),dat.vset=0.3*dat.n; end
if ~isfield(dat,'speak'),dat.speak=1; end
if ~isfield(dat,'vt'),dat.vt=0; end
if ~isfield(dat,'loss'),dat.loss='inf'; end
if ~isfield(dat,'lineSearch'),dat.lineSearch=1; end
if ~isfield(dat,'local_search'),dat.local_search=1; end
if ~isfield(dat,'plot'),dat.plot=0; end

fprintf('example: %d, dimension:%d, rank:%d, lambda:%f, alg:%s \n',dat.n,dat.d,dat.rank,dat.lambda,dat.alg );
dat.K_Y=Gennerate_Label_Matrix(dat.y); % n x c
dat.xy= dat.x' * dat.K_Y; % d x c

 
t1=clock;
if(strcmp(dat.alg,'BILGO')==1)
    L=BILGO(dat);
elseif(strcmp(dat.alg,'conj')==1)
    L=randn(dat.d,dat.rank);
    [L]=ConjMethod(L,dat);
elseif(strcmp(dat.alg,'lbfgs')==1)
    L=randn(dat.d,dat.rank);
    [L]= LbfgsMethod(L,dat);
else
    error('error alg');
end;
 
t2=clock;
ts=etime(t2,t1);
 
function [lambda,beta]=mylinesearch(L,b,dat)
if(isempty(L)),
    L=zeros(length(b),1);
end
A_q=zeros(2,2); b_q=zeros(2,1);
x_L=dat.x*L;          % n x r
x_b=dat.x*b;          % n x 1
Lt_xt_x_L = x_L'*x_L; % r x r
bt_xt_x_b = x_b'*x_b; % 1 x 1
bt_xt_x_L = x_b'*x_L; % 1 x r
Lt_L= L'*L;           % r x r
Lt_L_Lt_L= Lt_L*Lt_L; % r x r
bt_b= b'*b;           % 1 x 1
bt_b_bt_b= bt_b*bt_b; % 1 x 1
bt_L=b'*L;            % 1 x r
Lt_xt_y = x_L'*dat.K_Y; % r x c
bt_xt_y = x_b'*dat.K_Y; % 1 x c
A_q(1,1)=2*dat.lambda*trace(Lt_xt_x_L*Lt_xt_x_L)+2*trace(Lt_L_Lt_L);
A_q(1,2)=2*dat.lambda*trace(bt_xt_x_L*bt_xt_x_L')+2*trace(bt_L*bt_L');
A_q(2,2)=2*dat.lambda*trace(bt_xt_x_b*bt_xt_x_b)+2*trace(bt_b_bt_b);
A_q(2,1)=A_q(1,2);
b_q(1)=-2 * (trace(Lt_L)+ dat.lambda*trace(Lt_xt_y*Lt_xt_y'));
b_q(2)=-2 * (trace(bt_b)+ dat.lambda*trace(bt_xt_y*bt_xt_y'));
%[x]=nonnegative_quadratic_two_variables_analytically(A_q,b_q);
[x]=quadratic_two_variables(A_q,b_q,[1;inf]);

lambda=x(1);
beta=x(2);

 

function [L, fs]=LbfgsMethod(L,dat)
fs=[];
flast=1e100;
x_old=L;x_old(1,1)=9999;

lam=dat.lambda;[n,d]=size(L);
for it=1:dat.maxiter,
    %%%%%%%%%%%%%%%% compute f and g %%%%%%%%%%%%%%%%%
    ll=L'*L;           % r x r
    llll=ll*ll;        % r x r
    xl=dat.x*L;        % n x r
    xlxl= xl'* xl;     % r x r
    xlxy=xl'* dat.K_Y; % r x c
    % dat.xy  d x c
    
    f= trace(dat.lambda * xlxl*xlxl)...
        +trace(llll)...
        -2*trace(ll)...
        -dat.lambda*2*trace(xlxy * xlxy');
    
    g= dat.lambda * dat.x'*xl*xlxl...
        - dat.lambda*dat.x'*dat.K_Y * xlxy'...
        +L*ll...
        -L;
    g= g * 4;
    %%%%%%%%%%%%%%%% compute f and g %%%%%%%%%%%%%%%%%
    %     g=truncate(g,0.5);
    
    fs=[fs;f];
    
    diff=abs(f-flast)/abs(flast);flast=f;
    diff2=norm(x_old-L,'fro')/norm(x_old,'fro');
    fprintf('it: %d, obj: %f, norm_diff: %f, diff:%f\n',it,f,diff2,diff);
    if(diff<dat.robj  ),fprintf('exit reason: obj change %f too small(<%f)! \n', diff,dat.robj);break;end;
    if(diff2<dat.rnorm  ),fprintf('exit reason: norm change %f too small(<%f)! \n', diff2,dat.rnorm);break;end;
    
    if(it==1)
        dir = -g;
        old_dirs = zeros(n,d,0);
        old_stps = zeros(n,d,0);
        Hdiag = 1;
        
    else
        [old_dirs,old_stps,Hdiag] = lbfgsUpdate(g-g_old,L-x_old,old_dirs,old_stps,Hdiag);
        dir= lbfgs(-g,old_dirs,old_stps,Hdiag);
    end;
    g_old = g;
    x_old=L;
    
    %%%%%%%%%%%%%%%%% line search %%%%%%%%%%%%%%%%%
    xd= dat.x*dir; % n x r
    %        xl= dat.x * L; % n x r
    % dat.xy  d x c
    
    dxxd=xd'*xd;   % r x n , n x r = r x r
    lxxl=xl'*xl;   % r x n , n x r = r x r
    dxxl=xd'*xl;   % r x n , n x r = r x r
    lxxd=xl'*xd;   % r x n , n x r = r x r
    yxl=dat.K_Y'*xl; % c x n, x x r = c x r
    yxd=dat.K_Y'*xd; % c x n, x x r = c x r
    
    %         ll=L'*L;
    dd=dir'*dir; dl=dir'*L;ld=dl';ddll=dd*ll; dldl=dl*dl;
    drd=yxd'*yxd;lrd=yxl'*yxd; drl=yxd'*yxl;
    
    t4=trace ( lam * dxxd * dxxd + dd * dd );
    t3a=lam*trace (dxxd * dxxl+dxxd * lxxd+ dxxl * dxxd+lxxd * dxxd);
    t3b=2* trace (dd*dl)+ 2* trace (dd*ld) ;
    t3=t3a+t3b;
    t2a= lam * ( 2*trace( dxxd*lxxl) +  trace(dxxl*dxxl) + 2* trace(dxxl*lxxd)  +  trace(lxxd*lxxd)  );
    t2b=2* trace(ddll) + 2* trace(dldl) + 2* trace( ld*dl)   ;
    
    t2c= -2*trace(lam*drd+dd);
    t2=t2a+t2b+t2c;
    t1a= 2*lam * ( trace(dxxl*lxxl) +  trace(lxxl*lxxd) );
    t1b= 4* trace( dl*ll);
    t1c= -2* trace(lam*lrd+lam*drl+ld+dl);
    t1=t1a+t1b+t1c;
    
    steps =roots([4*t4 3*t3 2*t2 1*t1]);
    steps_candidates=[];for i=1:length(steps),if(isreal(steps(i))),if(steps(i)> 0)  steps_candidates=[steps_candidates;steps(i)];end;end;end;
    if(isempty(steps_candidates))
        error('no good step');
        step=armijo(L,dir,g,obj,f);
    else
        step=min(steps_candidates);
    end;
    %%%%%%%%%%%%%%%%% line search %%%%%%%%%%%%%%%%%
    
    L=L+step *dir;
    
    if(dat.vt==1 && mod(it,dat.vcount)==0)
        testAcc(L,dat.x,dat.y,dat.tx,dat.ty);
    end;
end;
if(it==dat.maxiter),
    fprintf('exit reason: max iter reach\n');
end;

clear x_old ll llll xl xlxl xlxy dir old_dirs old_stps Hdiag g_old xd dxxd lxxl dxxl lxxd yxl yxd dd dl ld ddll dldl drd lrd drl steps_candidates;


function [acc1]= testSubsetAcc(L,x,y,tx,ty)
fprintf('classify begin:.. ');
[results]=KnnClassifySubSet (L',x',y',tx',ty',3,0);
acc1 = results *100;
if(acc1>50)
    fprintf('\n***********God!*******result:  test err rate:%f\n',acc1);
    L(1:10,1:10)
else
    fprintf('\nresult:  test err rate:%f\n',acc1);
end;




function [L,f, fs]=ConjMethod(L,dat)
fs=[];
flast=1e100;
lam=dat.lambda;
% [n,d]=size(L);
x_old=L;
x_old(1,1)=9999;
last_howmany_step=2;
IsTestSearch=dat.lineSearch;
for it=1:dat.maxiter,
    %%%%%%%%%%%%%%%% compute f and g %%%%%%%%%%%%%%%%%
    ll=L'*L;           % r x r
    llll=ll*ll;        % r x r
    xl=dat.x*L;        % n x r
    xlxl= xl'* xl;     % r x r
    xlxy=xl'* dat.K_Y; % r x c
    % dat.xy  d x c
    
    f= trace(dat.lambda * xlxl*xlxl)...
        +trace(llll)...
        -2*trace(ll)...
        -dat.lambda*2*trace(xlxy * xlxy');
%     f = f - size(L,1) - norm(dat.K_Y *dat.K_Y','fro')^2;
    % A=sqrt(dat.lambda)*dat.x'*dat.x;
    % B=diag(ones(1,length(A)));
    % C=-2*dat.lambda*dat.x'*dat.K_Y*dat.K_Y'*dat.x-2*B;
    % X=L*L';
    % G=2*A*X*A+B*X+X*B+2*C;
    % ev=eig(G);
    % ev
%     M = L*L';
%     Id = eye(size(M,1));
%     f1 =  norm(M-Id,'fro')^2 + dat.lambda * norm(dat.x*M*dat.x' - dat.K_Y *dat.K_Y','fro')^2;
%     f1 = f1 - size(M,1) - norm(dat.K_Y *dat.K_Y','fro')^2 
%     f1 ===f
    
   
    
    g= dat.lambda * dat.x'*xl*xlxl...
        - dat.lambda*dat.x'*dat.K_Y * xlxy'...
        +L*ll...
        -L;
    g= g * 4;
    %%%%%%%%%%%%%%%% compute f and g %%%%%%%%%%%%%%%%%
    fs=[fs;f];
    
    if(f>flast)
        fprintf('%f %f',f,flast);
        %                error('non des');
    end;
    diff=abs(f-flast)/abs(flast);flast=f;
    
    diff2=norm(x_old-L,'inf')/norm(x_old,'inf');
    if(dat.speak==1)
        fprintf('it: %d, obj: %f, norm_diff: %f, diff:%f\n',it,f,diff2,diff);
    end
    if(it>10 &&last_howmany_step==1&& diff<dat.robj  ),if(dat.speak==1),fprintf('exit reason: obj change %f too small(<%f)! \n', diff,dat.robj);end;break;end;
    if(it>10 && last_howmany_step==1&&diff2<dat.rnorm  ),if(dat.speak==1),fprintf('exit reason: norm change %f too small(<%f)! \n', diff2,dat.rnorm);end;break;end;
    
    x_old=L;
    if(it==1)
        dir=-g;
    else
        %          beta= trace(g'*g)/trace(last_g'*last_g);
        beta= trace(g'*(g-last_g))/trace(last_g'*last_g);
        beta(beta<0)=0;
        dir=-g+beta*dir;
    end;
    
    last_g=g;
    
    %%%%%%%%%%%%%%%%% line search %%%%%%%%%%%%%%%%%
    xd= dat.x*dir; % n x r
    %        xl= dat.x * L; % n x r
    % dat.xy  d x c
    
    dxxd=xd'*xd;   % r x n , n x r = r x r
    lxxl=xl'*xl;   % r x n , n x r = r x r
    dxxl=xd'*xl;   % r x n , n x r = r x r
    lxxd=xl'*xd;   % r x n , n x r = r x r
    yxl=dat.K_Y'*xl; % c x n, x x r = c x r
    yxd=dat.K_Y'*xd; % c x n, x x r = c x r
    
    %         ll=L'*L;
    dd=dir'*dir; dl=dir'*L;ld=dl';ddll=dd*ll; dldl=dl*dl;
    drd=yxd'*yxd;lrd=yxl'*yxd; drl=yxd'*yxl;
    
    t4=trace ( lam * dxxd * dxxd + dd * dd );
    t3a=lam*trace (dxxd * dxxl+dxxd * lxxd+ dxxl * dxxd+lxxd * dxxd);
    t3b=2* trace (dd*dl)+ 2* trace (dd*ld) ;
    t3=t3a+t3b;
    t2a= lam * ( 2*trace( dxxd*lxxl) +  trace(dxxl*dxxl) + 2* trace(dxxl*lxxd)  +  trace(lxxd*lxxd)  );
    t2b=2* trace(ddll) + 2* trace(dldl) + 2* trace( ld*dl)   ;
    
    t2c= -2*trace(lam*drd+dd);
    t2=t2a+t2b+t2c;
    t1a= 2*lam * ( trace(dxxl*lxxl) +  trace(lxxl*lxxd) );
    t1b= 4* trace( dl*ll);
    t1c= -2* trace(lam*lrd+lam*drl+ld+dl);
    t1=t1a+t1b+t1c;
    
    steps =roots([4*t4 3*t3 2*t2 1*t1]);
    steps_candidates=[];for i=1:length(steps),if(isreal(steps(i))),if(steps(i)> 0)  steps_candidates=[steps_candidates;steps(i)];end;end;end;
    Len=length(steps_candidates);
    if(Len==0)
        fprintf('****************************no good step\n');
        %            step=0.0000001;
        %            pause;
        break;
        %        error('no good step');
        %        step=armijo(L,dir,g,obj,f);
    elseif(Len==1)
        last_howmany_step=1;
        step=steps_candidates(1);
    else
        last_howmany_step=2;
        %            steps_candidates
        %            fprintf('****************************multiple steps\n');
        
        if(IsTestSearch==1)
            step=min(steps_candidates);
        else
            fprintf('****************************testing...\n');
            opti=inf;
            sel=-1;
            for iii=1:length(steps_candidates),
                if(steps_candidates(iii)>1),continue;end;
                L_test=L+steps_candidates(iii)*dir;% n x r
                ll_test=L_test'*L_test;            % r x r
                llll_test=ll_test*ll_test;         % r x r
                xl_test=dat.x*L_test;              % n x r
                xlxl_test= xl_test'* xl_test;      % r x r
                xlxy_test=xl_test'* dat.K_Y;       % r x c
                val= trace(dat.lambda * xlxl_test*xlxl_test)+trace(llll_test)-2*trace(ll_test)-dat.lambda*2*trace(xlxy_test * xlxy_test');
                if(val<opti)
                    sel=iii;
                    opti=val;
                end;
                
            end;
            
            step=steps_candidates(sel);
        end
    end;
    %%%%%%%%%%%%%%%%% line search %%%%%%%%%%%%%%%%%
    
    L=L+step *dir;
    
    if(dat.vt==1 && mod(it,dat.vcount)==0)
        testAcc(L,dat.x,dat.y,dat.tx,dat.ty);
    elseif(dat.vt==2 && mod(it,dat.vcount)==0)
        total_arr=randperm(dat.n); sub_set_index=total_arr(1:dat.vset);
        x_val=dat.x(sub_set_index,:);
        y_val=dat.y(sub_set_index,:);
        testSubsetAcc(L,dat.x,dat.y,x_val,y_val);
        
    end;
    
end;
if(it==dat.maxiter),
    if(dat.speak==1),
        fprintf('exit reason: max iter reach\n');
    end
end;

clear x_old ll llll xl xlxl xlxy g dir last_g xd dxxd lxxl dxxl lxxd yxl yxd dd dl ld ddll dldl drd lrd drl steps steps_candidates;


function [L]=BILGO(dat)

LS=dat.local_search;
L=[];

% statistic
alphas=[];
betas=[];
objs=[];
maxes=[];
kkts=[];

last_e=1e10;
last_kkt=1e10;
last_obj=1e10;

subproblem_opt = dat;
subproblem_opt.speak = 0;
subproblem_opt.maxiter = 100;

rank=dat.rank;
for it=1:rank,
    [obj,b,evalue,kkt]=ComputeObjGradHessFree(L,dat);
    diff=abs(obj-last_obj)/abs(last_obj);
    diff2=abs(evalue-last_e)/last_e;
    diff3=abs(kkt-last_kkt)/last_kkt;
    
    % Check Convergence
    if(obj>last_obj),fprintf('%f %f',obj,last_obj);error('non des');end;
    if(diff<dat.robj),fprintf('Exit Reason: Change Too Small:%e(%d)\n',diff,it);break;end
    %     if(diff2<1e-2 && diff3<1e-2),fprintf('Exit Reason: Optimal(%d)!\n',it);break;end
    
    [lambda,beta] = mylinesearch(L,b,dat);
    L=[sqrt(lambda)*L sqrt(beta)*b];
    
    % Save information
    objs=[objs;obj];
    maxes=[maxes;evalue];
    kkts=[kkts;kkt];
    alphas=[alphas lambda];
    betas=[betas beta];
    
    % Improve L
    if(LS > 0 && ~mod(it,LS))
        [L]=ConjMethod(L,subproblem_opt);
    elseif( LS>0 && it>50 && ~mod(it,2))
        [L]=ConjMethod(L,subproblem_opt);
    end
    
    %     if(dat.speak_main==1)
    fprintf('it:%d obj:%f evalue:%f, KKT:%e, diff:%e, diff2:%e, diff3:%e\n',...
        it, obj,evalue,kkt,diff,diff2,diff3);
    %     end
    
    % Save Last
    last_obj=obj;
    last_e=evalue;
    last_kkt=kkt;
    
end;

if(LS > 0),
    [L]=ConjMethod(L,subproblem_opt);
end

if(it==dat.rank),
    fprintf('Exit Reason: Rank Reach\n');
end

if(dat.plot)
    %   figure;plot(maxes)
    %   figure;plot(kkts)
    %   figure;plot(objs)
    figure;
    x = [1:length(objs)];
    linesize=2;
    h(1)=subplot(3,1,1); hold on; semilogy(x,objs,'-b>','LineWidth',linesize,'color', [255/256 66/256 14/256]);
    h(2)=subplot(3,1,2); hold on; semilogy(x,maxes,'-b>','LineWidth',linesize,'color', [0 149/256 201/256]);
    h(3)=subplot(3,1,3); hold on; semilogy(x,kkts,'-b>','LineWidth',linesize,'color', [81/256 157/256 28/256]);

    set(h(1),'Xcolor','w','YColor','k','XTick',[], 'YTickMode','auto','Fontsize', 15); box off
    set(h(2),'Xcolor','w','YColor','k','XTick',[], 'YTickMode','auto','Fontsize', 15); box off
    set(h(3),'Xaxislocation','bottom','YColor','k', 'YTickMode','auto','Fontsize', 15 )

    set(gcf,'position', [300 100 600 600],'color','w' );
    ylabel(h(1),'$F_{KTA}(M)$','FontSize',30,'interpreter','latex');
    ylabel(h(2),'$\lambda_{\max}$','FontSize',38,'interpreter','latex');
    ylabel(h(3),'$\gamma_{slack}$','FontSize',38,'interpreter','latex');
    xlabel('$Iterations$','FontSize',30,'interpreter','latex')
    
    up=0.06;
    HandleAdjustWhich=h(3); PPP=get(HandleAdjustWhich,'pos'); PPP(3)=PPP(3)+0.00; PPP(4)=PPP(4)+up; set(HandleAdjustWhich,'pos',PPP)
    HandleAdjustWhich=h(2); PPP=get(HandleAdjustWhich,'pos'); PPP(3)=PPP(3)+0.00; PPP(4)=PPP(4)+up; set(HandleAdjustWhich,'pos',PPP)
    HandleAdjustWhich=h(1); PPP=get(HandleAdjustWhich,'pos'); PPP(3)=PPP(3)+0.00; PPP(4)=PPP(4)+up; set(HandleAdjustWhich,'pos',PPP)
end

% function [fobjM,b,evalue,kkt] = ComputeObjGradHess (L,dat)
% M=L*L';
% D=dat.x'*dat.x;
% I=diag(ones(length(M),1));
% A=sqrt(dat.lambda)*D;
% B=I;
% C=-2*I-2*dat.lambda*dat.x'*dat.K_Y*dat.K_Y'*dat.x;
% fobjM = trace(A*M*A*M+B*M*M+C*M);
% grad = 2*A*M*A + B*M + M*B + C;
% grad=(grad+grad')/2;
% [b,evalue]=rank1Approximation_eigs(-grad);
% kkt = norm(grad*L*L','fro');


function [fobjM,b,evalue,kkt] = ComputeObjGradHessFree(L,dat)
if(isempty(L)),
    L=zeros(size(dat.x,2),1);
end
[d]=size(L,1);
ll=L'*L;           % r x r
llll=ll*ll;        % r x r   L'*L*L'*L
xl=dat.x*L;        % n x r   dat.x*L
xlxl= xl'* xl;     % r x r   L'*dat.x'* dat.x*L
xlxy=xl'* dat.K_Y; % r x c   L'*dat.x'* dat.K_Y

% fobjM = dat.lambda*trace(dat.x'*dat.x*L*L'*dat.x'*dat.x*L*L')+trace(ll*ll)...
%     +trace(-2*L*L')-trace(2*dat.lambda*dat.x'*dat.K_Y*dat.K_Y'*dat.x*L*L');

fobjM= trace(dat.lambda * xlxl*xlxl)...
    +trace(llll)...
    -2*trace(ll)...
    -dat.lambda*2*trace(xlxy * xlxy');

IsEig1=1;
if(IsEig1)
    Handle=@(x)funAX(x,L,xl,dat);
    opt=[];
    opt.MaxIter=5;
    opt.LanMaxIter=5;
    opt.ObjCha = 0.5;
    [b,evalue] = eig_newton_lanczos(Handle,d,opt);
else
    Handle=@(x)funAX(x,L,xl,dat);
    opts=[]; opts.issym = 1;
    %opts.maxit=30;   opts.tol=0.1; opts.p= min(d,10);
    opts.maxit=50;
    opts.p=min(10,d);
    [b,evalue,flag] = eigs(Handle,d,1,'la',opts);
    if(flag~=0),
        Handle=@(x)funAX(x,L,xl,dat);
        opts=[]; opts.issym = 1;
        [b,evalue,flag] = eigs(Handle,d,1,'la',opts);
        fprintf('not converged ');
    end
end

GL  = -Handle(L);
kkt = sqrt(trace(GL'*GL*ll));




function AX = funAX(x,L,xl,dat)
% xl=dat.x*L;        % n x r   dat.x*L
datxx=dat.x*x; % n x 1
LTx= L' * x; % r x 1
AX = - 2*dat.lambda*dat.x'*(xl * (xl' * datxx)) ...
    - 2*L*LTx + 2*x + 2*dat.lambda*dat.x'*(dat.K_Y*(dat.K_Y'*datxx));

