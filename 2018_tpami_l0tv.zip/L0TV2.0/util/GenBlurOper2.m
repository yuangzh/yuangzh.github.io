function [P] = GenBlurOper2
P = double(fspecial('gaussian',[9,9],4));
P = P/sum(P(:));