function [x] = boxproj(x)
x=max(x,0); x=min(x,1);

