function [noiselevels,images,noisetypes,restorationtypes] = load_parameters_denoising
noiselevels = [10:20:90];
noisetypes = {'Random-Valued','Salt-and-Pepper','Mixed'};
restorationtypes = {'denoising','deblurring'};
restorationtypes = {'denoising'};
images = {'walkbridge','pepper','mandrill','lenna','lake','jetplane','blonde','cameraman','barbara','boat','pirate','livingroom','house'};
