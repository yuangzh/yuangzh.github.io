function [X,his] = MSM(A,b,lambda,const,X0,max_iter,omega)
% 0.5*trace(X'*A*X) + <B,X> + const + lambda * nnz(X);
% X: n x d
% A: n x n
% B: n x d

[n,d] = size(b);
X = X0;

L = tril(A,-1);
D = diag(diag(A));
I = speye(n);
theta= 0.01;

B = L + (D + theta * I)/omega;
C = A - B;

his=[]; HandleObj = @(X)sum(sum(X.*(A*X)))/2 + sum(sum(b.*X)) +  lambda * nnz(X(:)) + const;
for iter = 1:max_iter,
    fobj = HandleObj(X); fprintf('iter:%d, fobj:%f\n',iter,fobj); his = [his;fobj];
    
    % Solve the triangle subproblem
    % Bx + p + sub_diff(g(x))=0
    % p = C*X+b
    X  = l0_triangle_subproblem(B,C*X+b,lambda,n,d);
end


